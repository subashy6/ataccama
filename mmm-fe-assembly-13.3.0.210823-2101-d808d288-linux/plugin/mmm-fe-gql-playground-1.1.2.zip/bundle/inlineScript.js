var cfg = {{bootstrapConfig}}

window.addEventListener('load', function (event) {
  GraphQLPlayground.init(document.getElementById('root'), {
    endpoint: cfg.mmm.apiUrl,
    subscriptionEndpoint: cfg.mmm.subscriptionUrl,
    settings: {
      'editor.cursorShape': 'line',
    }
  })
})