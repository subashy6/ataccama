(self["webpackChunkataccama_fe"]=self["webpackChunkataccama_fe"]||[]).push([[1807],{43539:(e,t,r)=>{"use strict";r.d(t,{X:()=>u});var a=r(67294);var n=r(70655);var i=r(16583);var o=r(29323);var s=r(12706);var l=r(33031);var c=r(80880);var d=r(81012);const p=d.ZP.div`
  color: ${e=>e.theme.palette.display[3]};
  display: inline-flex;

  ${e=>e.isForeign&&d.iv`
      color: ${e.theme.palette.secondary[6]};
    `}

  ${e=>e.isPrimary&&d.iv`
      color: ${e=>e.theme.palette.warning[5]};
    `}
`;let m=class DataTypeIndicator extends a.Component{render(){const{dataType:e,isPrimaryKey:t,isForeignKey:r,isPartitioning:n,className:o,showTooltip:d}=this.props;if(!e){return null}let m=(0,s.J)(e);let u=e.valueOf();if(n){m=l.iQl.partitionAttribute;u=`PARTITION, ${u}`}else if(t){m=l.iQl.key;u=`PRIMARY KEY, ${u}`}else if(r){m=l.iQl.foreignKey;u=`FOREIGN KEY, ${u}`}return a.createElement(p,{isPrimary:t,isForeign:r,className:o},d?a.createElement(c.u,{delay:0,placement:i.Iw.top,tooltip:u},m):m)}};m=(0,n.gn)([o.Pi],m);const u=({attribute:e,className:t,showTooltip:r})=>a.createElement(m,{dataType:e.dataType,isPrimaryKey:e.primaryKey,isForeignKey:e.foreignKey,isPartitioning:e.partition,className:t,showTooltip:r})},39127:(e,t,r)=>{"use strict";r.d(t,{h:()=>l});var a=r(67294);var n=r(33031);var i=r(80880);var o=r(81012);const s=o.ZP.div`
  display: flex;
`;const l=({catalogItem:e,showTooltip:t,className:r})=>{let o;let l="";if(e.partitions){o=n.iQl.partitionTable;l=i18n({id:"catalog.catalogItemType.partition",defaults:"Partitioned Table"})}else{switch(e._.metadata.getEffectiveEntity().name){case"tableCatalogItem":if(e.tableType==="TABLE"){o=n.iQl.table;l=i18n({id:"catalog.catalogItemType.table",defaults:"Table"})}else if(e.tableType==="VIEW"){o=n.iQl.tableView;l=i18n({id:"catalog.catalogItemType.view",defaults:"View"})}break;case"fileCatalogItem":o=n.iQl.csv;l=i18n({id:"catalog.catalogItemType.file",defaults:"File"});break;default:o=n.iQl.book;l=i18n({id:"catalog.catalogItemType.other",defaults:"Other"})}}const c=a.createElement(s,{className:r},o);return t?a.createElement(i.u,{tooltip:l},c):a.createElement(a.Fragment,null,c)}},4583:(e,t,r)=>{"use strict";r.d(t,{t:()=>N});var a=r(67294);var n=r(80880);var i=r(81012);const o=(0,i.ZP)(n.QE)``;const s=i.ZP.div`
  ${e=>e.theme.padding("L")}
  display: flex;
  align-items: center;
`;const l=i.ZP.div`
  width: 50%;
  &:first-child {
    border-right: 2px solid ${e=>e.theme.palette.separate[2]};
  }

  & > * {
    &:not(:first-child):not(:last-child) {
      box-shadow: inset 0 -1px 0 0 ${e=>e.theme.palette.separate[2]};
    }
  }
`;const c=i.ZP.div`
  display: flex;
`;const d=i.ZP.div`
  transform: translateX(-${e=>e.order*4}px);
`;const p=i.ZP.div`
  display: flex;
`;const m=i.ZP.div`
  ${e=>e.theme.font.regular()}
  ${e=>e.theme.margin(0,"XS",0,"S")}
`;var u=r(99934);var h=r(33948);var g=r(53536);var y=r(54061);var v=r.n(y);var f=r(97358);const E=({diffMode:e,compareInfo:t})=>{const r=b(e);const{statuses:n,changesCount:i}=v()(t,((e,t,a)=>{if(r(a)&&t){e.changesCount+=t;let r;switch(a){case"onlyOnLeft":r=g.u.LeftOnly;break;case"onlyOnRight":r=g.u.RightOnly;break;default:r=g.u.Changed;break}e.statuses.add(r)}return e}),{changesCount:0,statuses:new Set});return i>0?a.createElement(a.Fragment,null,a.createElement(m,null,i),a.createElement(p,null,Array.from(n,((e,t)=>a.createElement(d,{order:t,key:e},a.createElement(f.$,{compareType:e})))))):null};function b(e){if(e===u.T.All||e===u.T.OnlyDifferent){return e=>e!=="unchanged"}if(e===u.T.OnlySame){return e=>e==="unchanged"}if(e===u.T.OnlyOnLeft){return e=>e==="onlyOnLeft"}return e=>e==="onlyOnRight"}const N=({compareInfo:e,diffMode:t,titles:r,rows:n,testId:i})=>a.createElement(c,null,a.createElement(l,{"data-testid":`${i}_left`},a.createElement(s,null,a.createElement(o,null,r.left),e&&t&&t!==u.T.OnlySame&&a.createElement(E,{diffMode:t,compareInfo:e})),n.map((e=>e["left"]))),a.createElement(l,{"data-testid":`${i}_right`},a.createElement(s,null,a.createElement(o,null,r.right)),n.map((e=>e["right"]))))},19681:(e,t,r)=>{"use strict";r.d(t,{o:()=>x});var a=r(51584);var n=r.n(a);var i=r(67294);var o=r(33031);var s=r(92156);var l=r(31289);var c=r(60678);var d=r(53536);var p=r(97358);var m=r(58924);var u=r(259);var h=r(80880);var g=r(16583);var y=r(81012);const v=y.ZP.div`
  white-space: nowrap;
  ${e=>e.theme.padding.left("L")}
  ${e=>e.theme.padding.right("M")}
  align-items: center;
`;const f=y.ZP.div`
  word-break: break-word;
  width: 99%;
  color: ${e=>e.theme.palette.display[7]};
  ${e=>e.theme.padding.right("L")}
`;const E=(0,y.ZP)(f)`
  color: ${e=>e.theme.palette.display[3]};
`;const b=y.ZP.div`
  ${e=>e.theme.padding.right("L")}
`;const N=y.ZP.div`
  display: table-row;
  ${e=>e.theme.font.regular()};
  margin: 0;

  background-color: ${e=>e.dark?e.theme.palette.tertiary[1]:"inherit"};
  height: 44px;

  ${v},
  ${f},
  ${b} {
    vertical-align: middle;
    margin: 0;
    display: table-cell;
  }

  ${v} {
    color: ${e=>e.dark?e.theme.palette.display[3]:e.theme.palette.display.base};
  }
`;const P=y.ZP.div`
  ${e=>e.theme.margin.right("L")}
  color: ${e=>e.theme.palette.display[3]};
  display: inline-block;
`;const C=i18n({id:"compare.table.missingItem",defaults:"Does not exist at this version"});const $=({dataType:e,value:t,doesNotExist:r})=>{if(!r&&t==null){return i.createElement(E,null,i18n({id:"compare.emptyValue",defaults:"Empty"}))}if(e instanceof c.j){return i.createElement(f,null,"••••••••")}if((e===null||e===void 0?void 0:e.name)==="richtext"&&typeof t==="string"){return i.createElement(f,null,i.createElement(s.a,{value:(0,l.nP)(t)}))}if(n()(t)){return i.createElement(f,null,i.createElement(u.x,{value:t}))}return i.createElement(f,null,t)};const x=({label:e,value:t,dark:r,compareType:a,iconName:n,showStatus:s,doesNotExist:l,tooltipItemName:c,dataType:u})=>i.createElement(N,{dark:r},i.createElement(v,null,n!=null&&!l&&i.createElement(P,null,o.iQl[n]),i.createElement("span",null,l?C:e)),i.createElement($,{value:t,dataType:u,doesNotExist:l}),i.createElement(b,null,s&&i.createElement(h.u,{delay:0,disabled:a===d.u.Same,placement:g.Iw.left,tooltip:(0,m.s)(a,c)},i.createElement(p.$,{compareType:a}))))},30503:(e,t,r)=>{"use strict";r.r(t);r.d(t,{ArrayCompare:()=>w});var a=r(70655);var n=r(29323);var i=r(67294);var o=r(27295);var s=r(33948);var l=r(86359);var c=r(22188);var d=r(83812);var p=r(80880);var m=r(82142);var u=r(22930);var h=r(76851);var g=r(88686);class ArrayCompareNodePagination{constructor(e,t,r){this.node=e;this.session=t;this.view=r;this.pageSize=g.I;this.pageNumber=1}get isLoading(){return this.node.isLoading&&this.node.children.length<Math.min(this.pageNumber*this.pageSize,this.node.expectedNumChildren)}get items(){return this.node.children.slice((this.pageNumber-1)*this.pageSize,this.pageNumber*this.pageSize)}get totalCount(){return this.node.expectedNumChildren}get hasPreviousPage(){return this.pageNumber>1}get hasNextPage(){return this.pageNumber*this.pageSize<this.node.expectedNumChildren}get lastPageNumber(){return Math.ceil(this.node.expectedNumChildren/this.pageSize)}prevPage(){if(this.hasPreviousPage){this.pageNumber--}}nextPage(){if(this.hasNextPage&&!this.node.isLoading){this.pageNumber++;if(this.node.children.length<Math.min(this.pageNumber*this.pageSize,this.node.expectedNumChildren)){this.node.loadChildren(this.session,this.view,new u.wk(this.apiClient))}}}setPage(e){if(e*this.pageSize<this.node.expectedNumChildren){this.pageNumber=e}else{this.pageNumber=this.lastPageNumber}}setPageSize(e){this.pageSize=e;this.setPage(1)}}(0,a.gn)([(0,h.Q)((()=>m.l))],ArrayCompareNodePagination.prototype,"apiClient",void 0);(0,a.gn)([c.LO],ArrayCompareNodePagination.prototype,"pageNumber",void 0);(0,a.gn)([c.Fl],ArrayCompareNodePagination.prototype,"isLoading",null);(0,a.gn)([c.Fl],ArrayCompareNodePagination.prototype,"items",null);(0,a.gn)([c.Fl],ArrayCompareNodePagination.prototype,"hasPreviousPage",null);(0,a.gn)([c.Fl],ArrayCompareNodePagination.prototype,"hasNextPage",null);(0,a.gn)([c.Fl],ArrayCompareNodePagination.prototype,"lastPageNumber",null);(0,a.gn)([c.aD.bound],ArrayCompareNodePagination.prototype,"prevPage",null);(0,a.gn)([c.aD.bound],ArrayCompareNodePagination.prototype,"nextPage",null);(0,a.gn)([c.aD.bound],ArrayCompareNodePagination.prototype,"setPage",null);(0,a.gn)([c.aD.bound],ArrayCompareNodePagination.prototype,"setPageSize",null);var y=r(81012);const v=y.ZP.div`
  ${e=>e.theme.margin("XS",0,"XS","L")}
`;var f=r(4583);var E=r(19681);var b=r(53536);var N=r(99360);var P=r(77924);const C=({item:e,side:t})=>{var r,a;const n=e.compareType===b.u.RightOnly&&t==="left"||e.compareType===b.u.LeftOnly&&t==="right";return i.createElement(E.o,{doesNotExist:n,showStatus:t==="right",dark:n,iconName:e.iconName,compareType:e.compareType,label:$(t,e),value:"",tooltipItemName:t==="left"?(r=e.leftDisplayName)!==null&&r!==void 0?r:e.displayName:(a=e.displayName)!==null&&a!==void 0?a:e.leftDisplayName})};function $(e,t){var r;let a=e==="left"?t.leftDisplayName:t.displayName;const n=(r=t.entityVersionPair.left)!==null&&r!==void 0?r:t.entityVersionPair.right;if(n._.metadata.property.match(N.MM.property("termInstances").desc)){var o;const e=(o=n._.versions.draft)===null||o===void 0?void 0:o.target;a=i.createElement(P.O,{onClick:e=>e===null||e===void 0?void 0:e.preventDefault(),term:e})}return a}class ArrayCompare_ArrayCompare extends i.Component{constructor(){super(...arguments);this.pagination=new ArrayCompareNodePagination(this.props.compareNode,this.props.compareSession,this.props.compareView)}get rows(){return this.pagination.items.map((e=>{const{ItemComponent:t}=this.props;const r=e;return{left:i.createElement(t,{key:r.key,item:r,side:"left"}),right:i.createElement(t,{key:r.key,item:r,side:"right"})}}))}render(){const{compareNode:e,compareView:t}=this.props;const r=e&&this.rows.length>0;const a=e.displayName;const n=`${e.property.testId}_generalInfo`;return e?i.createElement(p.Zb,{title:r?undefined:a,fullWidthContent:r,fullHeightContent:r,testId:n},i.createElement(p.Xu,{isLoading:this.pagination.isLoading},r?i.createElement(i.Fragment,null,i.createElement(f.t,{rows:this.rows,titles:{left:a,right:a},compareInfo:this.props.compareNode.compareInfo,diffMode:t.diffMode,testId:n}),this.pagination.totalCount>this.pagination.pageSize&&i.createElement(v,null,i.createElement(d.D,{pagination:this.pagination}))):i.createElement(p.b5,null,i.createElement(l.Trans,{id:"entityCompare.array.noChanges",defaults:"Nothing changed."})))):null}}ArrayCompare_ArrayCompare.defaultProps={ItemComponent:C};(0,a.gn)([c.Fl],ArrayCompare_ArrayCompare.prototype,"rows",null);var x=r(48843);let w=class ArrayCompare extends((0,o.Bq)({compareView:o.T.instanceOf(x.u),compareSession:o.T.any()},{compareNode:o.T.instanceOf(g.u)})){render(){return i.createElement(ArrayCompare_ArrayCompare,this.props)}};w=(0,a.gn)([n.Pi],w)},66803:(e,t,r)=>{"use strict";r.r(t);r.d(t,{CompareError:()=>CompareError});var a=r(86359);var n=r(67294);var i=r(27295);var o=r(80880);class CompareError extends((0,i.Bq)({title:i.T.str(undefined)})){render(){var e;return n.createElement(o.Zb,{title:(e=this.props.title)!==null&&e!==void 0?e:i18n({id:"entityCompare.error.title",defaults:"Error"})},n.createElement(o.b5,null,n.createElement(a.Trans,{id:"entityCompare.error.description",defaults:"Error occurred during comparison"})))}}},1564:(e,t,r)=>{"use strict";r.r(t);r.d(t,{EntityCompare:()=>m});var a=r(86359);var n=r(70655);var i=r(29323);var o=r(67294);var s=r(27295);var l=r(80880);var c=r(36017);var d=r(48843);var p=r(92739);let m=class EntityCompare extends((0,s.Bq)({compareView:s.T.instanceOf(d.u),sections:s.T.dict(s.T.widget({compareNode:s.T.instanceOf(c.G)}))},{compareNode:s.T.instanceOf(p.L)})){render(){const{compareNode:e,compareView:t,sections:r}=this.props;const n=e.children.filter((e=>e.shouldShow(t)&&r[e.key]));return e.children.length>0?n.map((e=>o.createElement(o.Fragment,{key:e.key},r[e.key]({compareNode:e})))):o.createElement(l.Zb,{testId:`${e.property.testId}_entityCompare`,title:e.property.displayName},o.createElement(l.b5,null,o.createElement(a.Trans,{id:"entityCompare.content.nothingToCompare",defaults:"Entity has nothing to compare."})))}};m=(0,n.gn)([i.Pi],m)},81397:(e,t,r)=>{"use strict";r.r(t);r.d(t,{GeneralInfoCompare:()=>C});var a=r(86359);var n=r(70655);var i=r(22188);var o=r(29323);var s=r(67294);var l=r(27295);var c=r(4583);var d=r(19681);var p=r(80880);var m=r(48843);var u=r(99934);var h=r(70360);var g=r(84571);var y=r(35161);var v=r.n(y);var f=r(78236);var E=r(47969);function b(e){return e.property instanceof E.D}function N(e){return e.property instanceof SingleTypedReferenceProperty}function P(e,t){return v()(t,((t,r)=>{const a=e.getPropertyByName(r);if(a){if(a instanceof E.D){const e=t;const r={...e,compareType:e.compareType,property:a};return r}else if(a instanceof f.c){const e=t;const r={...e,compareType:e.compareType,property:a};return r}else{throw new Error(`Unexpected property type of ${r}`)}}else{throw new Error(`Unexpected results with key ${r}`)}}))}let C=class GeneralInfoCompare extends((0,l.Bq)({compareView:l.T.instanceOf(m.u)},{compareNode:l.T.instanceOf(h.j)})){get rowsFilter(){const{compareView:e}=this.props;if(e.diffMode===u.T.All){return e=>e}else{return t=>(0,g.k)(t.compareType,e.diffMode)}}get rows(){const{compareNode:e}=this.props;const t=P(e.property.entity,e.results);return t.filter(this.rowsFilter).map((e=>({left:this.getItem(e,"left"),right:this.getItem(e,"right")})))}getItem(e,t){var r;const{displayName:a}=e.property;const n=t==="right";if(b(e)){const r=t==="right"?"left":"right";const i=e[t]==null&&e[r]!=null;return s.createElement(d.o,{showStatus:n,dark:i,key:a,compareType:e.compareType,label:a,value:e[t],doesNotExist:i,tooltipItemName:a,dataType:e.property.dataType})}const i=e[t];const o=!(i!==null&&i!==void 0&&i.gid);return s.createElement(d.o,{dark:o,showStatus:n,key:a,compareType:e.compareType,label:a,value:(i===null||i===void 0?void 0:(r=i.draftVersion)===null||r===void 0?void 0:r._displayName)||(i===null||i===void 0?void 0:i.gid),doesNotExist:o,tooltipItemName:a})}render(){const{compareNode:e}=this.props;const t=i18n({id:"entityCompare.generalInfo.title",defaults:"General information"});const r=e&&this.rows.length>0;const n=`${e.property.testId}_generalInfo`;return e?s.createElement(p.Zb,{title:r?undefined:t,fullWidthContent:r,fullHeightContent:r,testId:n},r?s.createElement(c.t,{rows:this.rows,titles:{left:t,right:t},testId:n}):s.createElement(p.b5,null,s.createElement(a.Trans,{id:"entityCompare.generalInfo.noChanges",defaults:"Nothing changed."}))):null}};(0,n.gn)([i.Fl],C.prototype,"rowsFilter",null);(0,n.gn)([i.Fl],C.prototype,"rows",null);C=(0,n.gn)([o.Pi],C)},60172:(e,t,r)=>{"use strict";r.r(t);r.d(t,{NoChangesPlaceholder:()=>NoChangesPlaceholder});var a=r(86359);var n=r(67294);var i=r(27295);var o=r(80880);class NoChangesPlaceholder extends((0,i.Bq)({title:i.T.str(undefined)})){render(){return n.createElement(o.Zb,{title:this.props.title},n.createElement(o.b5,null,n.createElement(a.Trans,{id:"noChangesPlaceholder.text",defaults:"Nothing changed."})))}}},9297:(e,t,r)=>{"use strict";r.d(t,{e:()=>EntitySidebarConfig});var a=r(70655);var n=r(56650);var i=r(64567);class EntitySidebarConfig extends n.D{}(0,a.gn)([(0,i.Q)({type:String})],EntitySidebarConfig.prototype,"viewLayout",void 0);(0,a.gn)([(0,i.Q)({type:String})],EntitySidebarConfig.prototype,"editorLayout",void 0);(0,a.gn)([(0,i.Q)({internal:true,mergeableArray:true})],EntitySidebarConfig.prototype,"fetchRules",void 0)},56919:(e,t,r)=>{"use strict";r.d(t,{M:()=>i});var a=r(67294);var n=r(74674);const i=e=>{const{defaultNavigationActionHandler:t}=(0,a.useContext)(n.wH);const r=(0,a.useCallback)((r=>{r.preventDefault();if(e){t.handleTarget({kind:"entity",target:e})}}),[e,t]);return r}},73791:(e,t,r)=>{"use strict";r.d(t,{K:()=>EntitySidebarItem});var a=r(70655);var n=r(22188);var i=r(67294);var o=r(68922);var s=r(25542);var l=r(42413);var c=r(80860);var d=r(71382);var p=r(61492);var m=r(94975);var u=r(89597);var h=r(10716);var g=r(77544);var y=r(76851);var v=r(95073);var f=r(80880);const E=()=>i.createElement(v.C,null,i.createElement(f.mL,null),i.createElement(f.cY,null));var b=r(9297);var N=r(33948);var P=r(29323);var C=r(27023);var $=r(1946);let x=class EntityFetcher extends i.Component{constructor(){super(...arguments);this.ready=!this.requiresLoad}get requiresLoad(){const{entityVersion:e,fetchRules:t}=this.props;return Boolean(e._gid&&(t===null||t===void 0?void 0:t.length))}async componentDidMount(){if(this.requiresLoad){const{entityVersion:e,fetchRules:t}=this.props;e._query.require(t!==null&&t!==void 0?t:[]);await this.context.waitDeferred((()=>e._query.ensureRequired()));if(!e._.versions.getVersion(g.XH.Draft)){e._query.rootQuery.requireVersionAt(e._query.queryPath.parent,g.XH.Draft,$.Im);await this.context.waitDeferred((()=>e._query.ensureRequired()))}this.ready=true}}render(){return this.ready&&this.props.children}};x.contextType=C.jV;(0,a.gn)([n.LO],x.prototype,"ready",void 0);(0,a.gn)([n.aD],x.prototype,"componentDidMount",null);x=(0,a.gn)([P.Pi],x);var w=r(99235);var T=r(28722);class EntitySidebarRenderer extends i.Component{get config(){return this.propertyConfigService.get(b.e,this.props.entityVersion._.metadata.property)}get layout(){if(this.props.customLayout){return this.props.customLayout}const{viewLayout:e}=this.config;return e&&JSON.parse(e)}get ctx(){const{entityVersion:e}=this.props;return this.contextFactory.create({property:e._.metadata.property,entity:e._,entityVersion:e,actionContext:m.f.Detail,widgetType:w.l9.Label,onSuccess:this.props.onSuccess})}get fetchRules(){const e=this.config.fetchRules?this.config.fetchRules:[];if((0,g.tH)(this.props.entityVersion._query.queryPath.versionSelector)){e.push({pattern:".",entityVersionExtensions:["history"],entityExtensions:[]})}else{e.push({pattern:".",entityExtensions:[],entityVersionExtensions:["ancestor"]})}return e}async ensureNodeSets(){const{entityVersion:e}=this.props;if(e._.hasComplexWorkflow){await e._.traits.withTrait(T.k,(e=>e.ensureNodeSets()))}}componentDidMount(){this.ensureNodeSets()}render(){const{layout:e,ctx:t}=this;return i.createElement(p.Q,{spinner:i.createElement(E,null)},i.createElement(x,{entityVersion:this.props.entityVersion,fetchRules:this.fetchRules},e?i.createElement(u.O,{layout:e,ctx:t}):i.createElement(c.$,null)))}}(0,a.gn)([(0,y.Q)((()=>h.I))],EntitySidebarRenderer.prototype,"propertyConfigService",void 0);(0,a.gn)([(0,y.Q)((()=>d.q))],EntitySidebarRenderer.prototype,"contextFactory",void 0);(0,a.gn)([n.Fl],EntitySidebarRenderer.prototype,"layout",null);(0,a.gn)([n.Fl],EntitySidebarRenderer.prototype,"ctx",null);class EntitySidebarItem{constructor(e,t,r,a){this.entityVersion=e;this.customLayout=t;this.onSuccess=r;this.config=a;this.isDestructive=false;this.hooks={onUnload:new l.O}}get name(){var e;return((e=this.config)===null||e===void 0?void 0:e.name)||this.entityVersion._displayName}get link(){var e;const{entityVersion:t}=this;const r=!t._to;const a=(e=t._from)===null||e===void 0?void 0:e.id;const n={};if(!r){n.versionId=a}if(!t._gid){return}return{routeName:s.N.entity(t._.metadata.getEffectiveEntity().name).detail("overview"),params:{...n,gid:t._gid}}}get icon(){var e;return((e=this.config)===null||e===void 0?void 0:e.icon)||i.createElement(o.W,{entityVersion:this.entityVersion})}get Renderer(){return()=>i.createElement(EntitySidebarRenderer,{entityVersion:this.entityVersion,customLayout:this.customLayout,onSuccess:this.onSuccess})}get entityGid(){return this.entityVersion._gid}}(0,a.gn)([n.Fl],EntitySidebarItem.prototype,"name",null);(0,a.gn)([n.Fl],EntitySidebarItem.prototype,"link",null);(0,a.gn)([n.Fl],EntitySidebarItem.prototype,"icon",null);(0,a.gn)([n.Fl],EntitySidebarItem.prototype,"Renderer",null)},259:(e,t,r)=>{"use strict";r.d(t,{x:()=>l});var a=r(67294);var n=r(33031);var i=r(81012);const o=(0,i.ZP)(n.KJ$)`
  color: ${e=>e.theme.palette.success[5]};
`;const s=(0,i.ZP)(n.T7q)`
  color: ${e=>e.theme.palette.display[3]};
`;const l=({value:e})=>e?a.createElement(o,{"data-testid":"value"}):a.createElement(s,{"data-testid":"value"})},76159:(e,t,r)=>{"use strict";r.d(t,{Q:()=>c});var a=r(67294);var n=r(73394);var i=r(17923);var o=r(56919);var s=r(80880);var l=r(4001);const c=({entityVersion:e,customLabel:t,showAncestorBreadcrumbs:r})=>{const c=(0,o.M)(e);const d=e=>{c(e);e.stopPropagation()};return a.createElement(l.om,null,a.createElement(s.Kq,{gap:"S"},a.createElement("div",null,t!==null&&t!==void 0?t:e._displayName),r&&a.createElement(n.O,{disabled:true,items:(0,i.Z)(e._)})),a.createElement(l.BS,{onClick:d}))}},4001:(e,t,r)=>{"use strict";r.d(t,{Mj:()=>s,BS:()=>c,om:()=>d,rU:()=>p,VO:()=>m,Q:()=>u});var a=r(33031);var n=r(9009);var i=r(80880);var o=r(81012);const s=(0,o.ZP)(i.II)`
  min-width: 250px;
  border: none;
  outline: none;
  box-shadow: none !important; // NOTE: overload src/ui-kit/components/Input.tsx:32 (&&&)
  padding-left: ${e=>`calc(${e.theme.symbol.spacing.M} + ${e.theme.symbol.spacing.S} + 20px)`};
`;const l=o.ZP.div`
  ${e=>e.theme.padding("S","M")};
  display: flex;
  justify-content: center;
`;const c=(0,o.ZP)(a.oG7)`
  color: ${e=>e.theme.palette.display[3]};
  display: none;
`;const d=o.ZP.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
  &:hover {
    ${c} {
      display: block;
    }
  }
`;const p=o.ZP.div`
  text-decoration: underline;
  cursor: pointer;
  color: ${e=>e.theme.palette.display[7]};
  &:hover {
    color: ${e=>e.theme.palette.interaction[5]};
  }
`;const m=o.ZP.div`
  ${e=>e.theme.padding("S")};
  padding-left: calc(${e=>e.theme.symbol.spacing.L} * 2);
  flex: auto;
  display: flex;
  ${e=>e.theme.font.body("medium")};
  background-color: ${e=>e.theme.palette.tertiary[1]};
`;const u=(0,o.ZP)(n.$j)`
  margin-right: ${e=>e.theme.symbol.spacing.M};
`},19965:(e,t,r)=>{"use strict";r.d(t,{h:()=>n});var a=r(25542);const n=(e,t="overview")=>({routeName:a.N.entity(e.metadata.getEffectiveEntity().name).detail(t),params:{gid:e.gid}})},77924:(e,t,r)=>{"use strict";r.d(t,{O:()=>u});var a=r(33948);var n=r.n(a);var i=r(70655);var o=r(29323);var s=r(67294);var l=r(74674);var c=r(83786);var d=r(80880);var p=r(68591);var m=r(21471);let u=class TermTag extends s.Component{constructor(){super(...arguments);this.handleClick=e=>{const{term:t,onClick:r}=this.props;if(r){r(e)}if(!(e!==null&&e!==void 0&&e.isDefaultPrevented())){e===null||e===void 0?void 0:e.preventDefault();e===null||e===void 0?void 0:e.stopPropagation();e===null||e===void 0?void 0:e.nativeEvent.stopImmediatePropagation();if(t){this.context.defaultNavigationActionHandler.handleTarget({kind:"entity",target:t})}}};this.handleAdd=e=>{const{onAdd:t}=this.props;e.preventDefault();e.stopPropagation();e.nativeEvent.stopImmediatePropagation();if(t){t()}};this.handleRemove=e=>{const{onRemove:t}=this.props;e.preventDefault();e.stopPropagation();e.nativeEvent.stopImmediatePropagation();if(t){t()}}}render(){var e;const{term:t,isSuggestion:r,confidence:a,isDeleteDraft:n,onAdd:i,onRemove:o}=this.props;const l=(0,c.q)(t);const u=s.createElement(m.W2,{onClick:this.handleClick,onKeyDown:e=>{e.key==="Enter"&&this.handleClick()},tabIndex:0,"data-testvalue":t?t._displayName:"","data-testid":r?"termTag_suggestion":"termTag"},s.createElement(m.VY,{color:l,isSuggestion:r,isDeleteDraft:n},s.createElement(m.Q$,null,t?s.createElement(p.gQ,{inKey:`${(e=t._.metadata.entity)===null||e===void 0?void 0:e.name}_name_${t._gid}`},t._displayName):i18n({id:"glossary.term.hidden.text",defaults:"Hidden term"})),(i||o)&&!n&&s.createElement(m.KN,null,i&&s.createElement(m.Kk,{"data-testid":"termTag_add",onClick:this.handleAdd},s.createElement(m.dt,null)),o&&s.createElement(m.Kk,{onClick:this.handleRemove,"data-testid":"termTag_remove"},s.createElement(m.HF,null)))),a&&s.createElement(m.nH,{confidence:a},s.createElement(m.Q$,null,Math.round(a*100),"%")));return t?u:s.createElement(d.u,{tooltip:i18n({id:"glossary.term.hidden.tooltip",defaults:"This term is not visible to you because of lack of permissions."})},u)}};u.contextType=l.wH;u=(0,i.gn)([o.Pi],u)},21471:(e,t,r)=>{"use strict";r.d(t,{ES:()=>o,W2:()=>s,Kk:()=>l,KN:()=>c,VY:()=>d,dt:()=>m,HF:()=>u,Q$:()=>h,nH:()=>g});var a=r(2227);var n=r(33031);var i=r(81012);const o=10;const s=i.ZP.div`
  display: flex;
`;const l=i.ZP.button`
  height: 100%;
  cursor: pointer;
  line-height: 0;
`;const c=i.ZP.div`
  padding-right: 3px;
  position: absolute;
  right: 0;
  top: 0;
  bottom: 0;

  &:before {
    content: '';
    display: block;
    position: absolute;
    right: 100%;
    width: 5px;
    height: 100%;
  }
`;const d=i.ZP.div`
  ${e=>e.theme.padding("XXS","S")};
  flex-shrink: 0;
  display: inline-flex;
  align-items: center;
  border-radius: 2px;
  position: relative;
  border: 1px solid;
  cursor: pointer;

  ${({color:e,theme:t})=>{const r=e||t.palette.display.base;const n=(0,a.CD)(.84,t.palette.tertiary.base,r);return i.iv`
      color: ${r};
      background-color: ${n};
      border-color: ${n};

      ${c}: before {
        background: linear-gradient(to right, transparent 0%, ${r} 100%);
      }

      ${c} {
        background-color: ${r};
      }

      &:hover {
        color: ${e=>e.theme.palette.tertiary.base};
        background-color: ${r};
        border-color: ${r};
      }
    `}}

  &:hover ${c} {
    display: flex;
  }

  ${c} {
    display: none;
    color: ${e=>e.theme.palette.tertiary.base};
  }

  ${e=>e.isSuggestion&&i.iv`
      background: transparent;
      border-color: ${e=>e.theme.palette.display[3]};
      border-right: none;
      border-top-right-radius: 0;
      border-bottom-right-radius: 0;
      color: ${e=>e.theme.palette.display.base};

      &:hover {
        background-color: ${e=>e.theme.palette.display.base};
        border-color: ${e=>e.theme.palette.display.base};
        ${c} {
          color: ${e=>e.theme.palette.tertiary.base};
        }
      }

      ${c} {
        padding: 0 0 0 3px;
        display: flex;
        position: static;
        background: transparent;
        color: ${e=>e.theme.palette.display.base};
        :before {
          background: transparent;
        }
      }
    `}

  ${e=>e.isDeleteDraft&&i.iv`
      opacity: 0.5;
      text-decoration: line-through;
    `}
`;const p=i.iv`
  width: 15px;
  opacity: 0.6;
  &:hover {
    opacity: 1;
  }
`;const m=(0,i.ZP)(n.NOm)`
  ${p}
`;const u=(0,i.ZP)(n.bMz)`
  ${p}
`;const h=i.ZP.span`
  ${e=>e.theme.font.captionMedium()};
  color: inherit;
`;const g=i.ZP.div`
  padding: 0 4px;
  display: flex;
  align-items: center;
  color: ${e=>e.theme.palette.tertiary.base};
  border-top-right-radius: 2px;
  border-bottom-right-radius: 2px;
  ${e=>e.confidence&&i.iv`
      background-color: ${e.confidence>.8?e.theme.palette.success[5]:e.theme.palette.warning[5]};
    `}
`},47192:(e,t,r)=>{"use strict";r.d(t,{w:()=>n});var a=r(30987);const n=(0,a.r)("fe:term")},83786:(e,t,r)=>{"use strict";r.d(t,{q:()=>o});var a=r(81012);const n={businessTerm:a.KQ.palette.interaction[5],securityTerm:a.KQ.palette.error[5],technicalTerm:a.KQ.palette.display.base,keyPerformanceIndicator:a.KQ.palette.secondary.base};var i=r(47192);const o=e=>{if(e){var t,r;const a=(t=e._.metadata.getEffectiveEntity().getTrait(i.w))===null||t===void 0?void 0:t.params.color;if(a){return a}const o=(r=e._.metadata.entity)===null||r===void 0?void 0:r.name;return o?n[o]:undefined}}}}]);
//# sourceMappingURL=widgets.5440776bf386d6ae3e95.js.map