(self["webpackChunkataccama_fe"]=self["webpackChunkataccama_fe"]||[]).push([[8330],{30869:(e,t,a)=>{"use strict";a.d(t,{y:()=>y});var i=a(67294);var n=a(80880);var r=a(81012);var s=a(2227);const l=r.ZP.div`
  display: flex;
  align-items: center;

  & > *:not(:first-child) {
    ${e=>e.theme.margin.left("XS")};
  }
  ${e=>e.theme.margin.right("S")};
`;const o=r.ZP.div`
  flex-shrink: 0;
  padding: 2px 7px;
  display: inline-flex;
  align-items: center;
  border-radius: 2px;
  position: relative;
  ${e=>e.theme.font.body()};
  color: ${e=>e.theme.palette.tertiary.base};
  background-color: ${e=>e.theme.palette.secondary.base};
  & > *:not(:first-child) {
    ${e=>e.theme.margin.left("XS")};
  }
`;const c=r.ZP.div`
  ${(0,s.LH)("180px")};
`;const d=r.ZP.div`
  display: inline-block;
  width: 8px;
  height: 8px;
  border-radius: 100%;
  vertical-align: middle;
  background-color: ${e=>e.theme.palette.tertiary.base};
  opacity: 0.75;
`;const u=r.ZP.div`
  display: flex;
  align-items: center;
`;var p=a(16583);const h=3;const m=r.ZP.div`
  background: ${e=>e.theme.palette.tertiary.base};
  box-shadow: 0 3px 4px 0 rgba(0, 0, 0, 0.1);
  // Default popup index is 10201, @see {@link POPUP_Z_INDEX}
  z-index: calc(${p.$o} + 42);
`;const v=({children:e,popperChildrenProps:{ref:t,style:a}})=>i.createElement(m,{ref:t,style:a},e);const g=({items:e,children:t})=>i.createElement(n.u,{Frame:v,placement:p.Iw.bottom,tooltip:i.createElement(n.aV,{items:e.map((e=>({value:e.displayName,label:i.createElement(o,null,i.createElement(c,null,e.displayName))}))),itemSize:n.Fz.S})},i.createElement(u,null,t));const y=({items:e})=>{if(e.length===0){return null}const t=e.slice(0,h);const a=e.slice(h);return i.createElement(l,null,t.map((e=>{var t;return i.createElement(o,{key:(t=e.key)!==null&&t!==void 0?t:e.displayName},i.createElement(c,null,e.displayName))})),a.length>0&&i.createElement(g,{items:a},i.createElement(o,null,i.createElement(c,null,"+",a.length),i.createElement(d,null))))}},52550:(e,t,a)=>{"use strict";a.d(t,{L:()=>h});var i=a(81012);var n=a(2227);var r=a(33031);const s=i.iv`
  ${e=>e.theme.font.body()};
  color: ${e=>e.theme.palette.display.base};
`;const l=i.iv`
  ${e=>e.theme.font.bodyMedium()};
  color: ${e=>e.theme.palette.display[6]};
  border: 1px solid ${e=>e.theme.palette.secondary.base};

  :not([disabled]):hover {
    border: 1px solid ${e=>e.theme.palette.secondary[7]};
  }
`;const o=(0,i.ZP)(r.CCt)`
  color: ${e=>e.theme.palette.display[3]};
  ${e=>e.theme.transition.fast("margin-top","color")};
`;const c=i.ZP.button`
  height: 36px;
  line-height: 36px;

  background-color: ${e=>e.theme.palette.tertiary.base};
  color: ${e=>e.theme.palette.display.base};
  border: 1px solid ${e=>e.theme.palette.display[2]};

  ${e=>e.theme.padding("S","M")};
  ${e=>e.theme.font.regular()};

  /* border-radius hack https://stackoverflow.com/questions/29966499/border-radius-in-percentage-and-pixels-px-or-em */
  border-radius: 999px;

  ${e=>e.theme.transition.fast("background-color","color")};

  :not([disabled]):hover {
    color: ${e=>e.theme.palette.display[7]};
    border: 1px solid ${e=>e.theme.palette.display[3]};
  }

  :not([disabled]):hover ${o} {
    color: ${e=>e.theme.palette.display.base};
    ${e=>e.theme.margin.top("XS")};
  }

  :not([disabled]) {
    cursor: pointer;
  }

  &[disabled] {
    color: ${e=>e.theme.palette.display[3]};
  }

  ${e=>e.active?l:s};

  :focus {
    outline: none;
  }
  display: inline-flex;
  align-items: center;
  white-space: nowrap;
`;const d=i.ZP.div`
  ${(0,n.LH)("180px")};
  ${e=>e.theme.margin.right("S")};
`;const u=i.ZP.div``;var p=a(67294);const h=({displayName:e,active:t,disabled:a,children:i,showArrow:n=true})=>p.createElement(c,{active:t,disabled:a,"data-testid":"filterButton","data-testvalue":e},e&&p.createElement(d,null,e),p.createElement(u,null,i),n&&p.createElement(o,null))},28721:(e,t,a)=>{"use strict";a.d(t,{k:()=>n});var i=a(81012);const n=i.ZP.div`
  display: flex;
  ${e=>e.theme.padding("M")};
  & :not(:last-child) {
    ${e=>e.theme.margin.right("M")};
  }
`},84901:(e,t,a)=>{"use strict";a.d(t,{r:()=>n});var i=a(81012);const n=i.ZP.div`
  height: 1px;
  width: 100%;
  border: none;
  background: ${e=>e.theme.palette.separate[1]};
`},58280:(e,t,a)=>{"use strict";a.d(t,{J:()=>n});var i=a(81012);const n=i.ZP.div`
  display: flex;
  flex-direction: column;
  border-radius: 4px;
  background: ${e=>e.theme.palette.tertiary.base};
  box-shadow: 0 3px 4px 0 rgba(0, 0, 0, 0.1);
  border: ${e=>e.theme.border.separate};
  max-width: 340px;
  min-width: 240px;
`},33524:(e,t,a)=>{"use strict";a.d(t,{R:()=>P});var i=a(33948);var n=a(86359);var r=a(70655);var s=a(43174);var l=a.n(s);var o=a(22188);var c=a(29323);var d=a(13271);var u=a(67294);var p=a(31563);var h=a(58280);var m=a(28721);var v=a(81012);const g=v.ZP.div`
  flex: auto;
  display: flex;
  align-items: center;
  justify-content: center;
  ${e=>e.theme.font.body()};
  color: ${e=>e.theme.palette.display[3]};
  ${e=>e.theme.padding("M",0)};
  white-space: nowrap;
`;var y=a(84901);var f=a(90601);var b=a(80880);var E=a(16583);var w=a(33031);const C=v.ZP.div`
  max-height: 300px;
  overflow: auto;
`;const S=v.ZP.div`
  display: flex;
  align-items: center;
  height: 40px;
  position: relative;
  color: ${e=>e.theme.palette.display[3]};
  border-bottom: ${e=>e.theme.border.separate};
`;const I="20px";const x=(0,v.ZP)(w.jVj)`
  ${e=>e.theme.margin(0,"M")};
  width: ${I};
  position: absolute;
  z-index: 10;
`;const T=v.ZP.input`
  display: block;
  flex: 1;
  border: 0;
  width: 100%;
  height: 100%;
  ${e=>e.theme.font.body()};
  padding-left: ${e=>`calc(${e.theme.symbol.spacing.M} + ${e.theme.symbol.spacing.S} + ${I})`};

  &:focus {
    outline: none;
  }

  ::placeholder,
  ::-webkit-input-placeholder {
    color: ${e=>e.theme.palette.display[3]};
  }
  :-ms-input-placeholder {
    color: ${e=>e.theme.palette.display[3]};
  }
`;let P=class KeywordFilterPopupContent extends u.Component{constructor(){super(...arguments);this.handleReset=e=>{e===null||e===void 0?void 0:e();this.props.onReset()};this.searchText="";this.handleSearch=e=>{this.searchText=e}}handleClick(e,t,a,i){e.stopPropagation();if(a){this.props.onDeselect(t)}else{i===null||i===void 0?void 0:i();this.props.onSelect(t)}}get items(){const{selectedValues:e}=this.props;return(this.searchText.length===0?this.props.items:this.props.items.filter((e=>(0,p.H)(e.searchableText||typeof e.label==="string"&&e.label||"",this.searchText)))).map((t=>{const a=e.includes(t.value);return{item:t,id:t.value,isSelected:a,label:t.label||t.value,onClick:e=>this.handleClick(e,t.value,a)}}))}render(){const{selectedValues:e}=this.props;const[t,a]=l()(this.items,(e=>(0,f.m)(e.id)));return u.createElement(E.tH.Consumer,null,(({closePopup:i})=>u.createElement(d.Qj,null,(()=>u.createElement(h.J,null,u.createElement(S,null,u.createElement(x,null),u.createElement(T,{onChange:e=>this.handleSearch(e.target.value),autoFocus:true,placeholder:"Search","data-testid":"searchInput","data-testvalue":this.props.filterDisplayName})),u.createElement(b.aV,{multiselect:false,itemSize:b.Fz.S,items:t.map((e=>({...e,onClick:t=>this.handleClick(t,e.id,e.isSelected,i)})))}),t.length>0&&u.createElement(y.r,null),u.createElement(C,null,u.createElement(b.aV,{multiselect:true,itemSize:b.Fz.S,items:a})),this.searchText.length>0&&this.items.length===0&&u.createElement(g,null,u.createElement(n.Trans,{id:"keywordFilter.noSearchResults",defaults:"No search results"})),u.createElement(y.r,null),u.createElement(m.k,null,u.createElement(b.zx,{disabled:e.length===0,onClick:()=>this.handleReset(i)},u.createElement(n.Trans,{id:"keywordFilter.clear",defaults:"Clear"}))))))))}};(0,r.gn)([o.LO],P.prototype,"searchText",void 0);(0,r.gn)([o.Fl],P.prototype,"items",null);(0,r.gn)([o.aD],P.prototype,"handleSearch",void 0);P=(0,r.gn)([c.Pi],P)},90601:(e,t,a)=>{"use strict";a.d(t,{N:()=>i,m:()=>n});var i;(function(e){e["MissingValue"]="__missing";e["AnyValue"]="__any"})(i||(i={}));function n(e){return e===i.AnyValue||e===i.MissingValue}},57516:(e,t,a)=>{"use strict";a.d(t,{x:()=>d});var i=a(70655);var n=a(29323);var r=a(67294);var s=a(27023);var l=a(92527);var o=a(83183);var c=a(80880);let d=class DataPreviewModal extends r.Component{componentDidMount(){const e=this.context.wait();this.props.dataPreview.fetchData().then(e).catch(e)}render(){const{tableData:{columns:e,rows:t},name:a,isEmpty:i}=this.props.dataPreview;return r.createElement(c.u_,{size:c.u_.Size.fluid,onOverlayClick:this.props.onDecline,onEscape:this.props.onDecline,testId:"dataPreview_modal"},r.createElement(c.u_.Header,{onClose:this.props.onDecline},a),r.createElement(c.Rm,null,!!e.length&&r.createElement(l.w,{stickyHeader:true,columns:e,rows:t}),r.createElement(o.G,{isEmpty:i})))}};d.contextType=s.jV;d=(0,i.gn)([n.Pi],d)},43025:(e,t,a)=>{"use strict";a.d(t,{P:()=>Z});var i=a(33948);var n=a(34140);var r=a(29323);var s=a(67294);var l=a(61745);var o=a(19252);var c=a(80880);var d=a(67047);var u=a(45037);var p=a(43539);var h=a(16583);var m=a(33031);var v=a(81012);const g=v.ZP.div`
  position: absolute;
  top: 0;
  right: 0;
  width: 100%;
  height: 100%;
  border: 2px solid ${e=>e.theme.palette.warning[5]};
`;const y=v.ZP.div`
  display: flex;
  align-items: center;
  justify-content: center;
  position: absolute;
  top: 0;
  right: 0;
  width: 36px;
  height: 24px;
  border-bottom-left-radius: 4px;
  background-color: ${e=>e.theme.palette.warning[5]};
  color: ${e=>e.theme.palette.tertiary.base};
`;const f=({tooltip:e})=>s.createElement(g,null,s.createElement(y,null,s.createElement(c.u,{delay:0,placement:h.Iw.top,tooltip:e},s.createElement(m.FCX,null))));var b=a(19965);var E=a(17828);const w=v.ZP.div`
  position: relative;
  ${e=>e.theme.font.subtitle()};

  a {
    position: relative;
    color: inherit;

    &::after {
      content: '';
      position: absolute;
      bottom: 1px;
      left: 0;
      background-color: ${e=>e.theme.palette.display[3]};
      width: 100%;
      height: 1px;
    }
  }
`;const C=v.ZP.div`
  ${e=>e.theme.padding("M")};
  position: relative;
  white-space: normal;
  width: max-content;
  min-width: 100%;
  height: ${e=>e.hasActions?"calc(100% - var(--actions-header-height))":"100%"}; /* [1] */
`;const S=v.ZP.div`
  display: flex;
  align-items: center;
  min-height: 30px;
  max-height: 30px;
  width: 100%;
`;const I=v.ZP.div`
  height: var(--actions-header-height);
  ${e=>e.theme.padding("XS")};
  background-color: ${e=>e.active?e.theme.palette.interaction[5]:e.theme.palette.separate[1]};
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-right: 1px solid
    ${e=>e.active?e.theme.palette.interaction[5]:e.theme.palette.separate[0]};
  ${e=>e.active&&v.iv`
      border-top-left-radius: 4px;
      border-top-right-radius: 4px;
    `}
`;const x=(0,v.ZP)(m.a6P)`
  transform: rotate(90deg);
  color: ${e=>e.theme.palette.display[4]};
  cursor: pointer;
  ${e=>e.theme.transition.fast("color")};
  &:hover {
    color: ${e=>e.theme.palette.display["base"]};
  }
`;const T=v.ZP.div`
  position: absolute;
  top: 0;
  right: 0;
  height: 100%;
  width: 100%;
  pointer-events: none;
  background: ${e=>e.theme.utils.hexToRgba(e.theme.palette.tertiary.base,.5)};
`;const P=v.ZP.table`
  --actions-header-height: 28px;
  border-collapse: separate;
  white-space: nowrap;
  background-color: ${e=>e.theme.palette.tertiary.base};
  border-radius: 4px;
  border: 1px solid ${e=>e.theme.palette.separate[1]};

  thead tr {
    height: 1px; /* [1] */
  }

  thead tr:first-child th:first-child {
    border-top-left-radius: 4px;
  }

  thead tr:first-child th:last-child {
    border-top-right-radius: 4px;
  }

  td:not(:last-child),
  th:not(:last-child) {
    border-right: 1px solid ${e=>e.theme.palette.separate[1]};
  }

  td,
  th {
    border-bottom: 1px solid ${e=>e.theme.palette.separate[1]};
  }

  tbody tr:last-child th,
  tbody tr:last-child td {
    border-bottom: 0;
  }
`;const N=v.ZP.tbody`
  ${e=>e.theme.font.data()};
`;const k=v.ZP.td`
  position: relative;
  ${e=>e.theme.padding(0,"M")};
  height: 44px;
  vertical-align: middle;
  min-width: 150px;
  max-width: 300px;
  white-space: normal;
  text-align: ${e=>e.isRightAligned?"right":"left"};
`;const D=(0,v.ZP)(c.Y8)`
  --radio-color: ${e=>e.theme.palette.interaction[5]};
`;const L=v.ZP.th`
  position: relative;
  vertical-align: top;
  min-width: 150px;
  height: inherit; /* [2] */

  ${e=>e.selected&&v.iv`
      :before {
        content: '';
        position: absolute;
        left: 0;
        right: 0;
        top: -1px; /* [1] */
        border: 1px solid ${e.theme.palette.interaction[5]};
        border-radius: 4px;
        height: var(--table-height, 40px);
        pointer-events: none; /* [4] */
      }
    `}

  /* [2][3] */
  @supports (height: -moz-available) {
    height: 100%;
  }
`;var M=a(48400);function V({column:e,attribute:t,testId:a,hasActions:i}){var n;return s.createElement(C,{hasActions:i},$(e),s.createElement(c.Kq,{gap:"S",align:"left"},s.createElement(c.gF,{gap:"S",nowrap:true,alignY:"center"},t&&s.createElement(p.X,{attribute:t,showTooltip:true}),s.createElement(c.Hm,null,s.createElement(w,null,t?s.createElement(d.F,{"data-testid":`${a}_data_column_titleLink`,to:(0,b.h)(t._)},e.name):s.createElement("span",null,e.name))),e.hasPolicyApplied&&s.createElement(u.Vd,null)),t&&((n=t.termInstances)===null||n===void 0?void 0:n.length)>0&&s.createElement(S,null,s.createElement(E.Y,{termInstances:t.termInstances,oneRow:true,disabled:true}))))}function $(e){switch(e.state){case M.lI.NotInCatalogItem:return s.createElement(f,{tooltip:i18n({id:"catalogItem.data.attributeNotAvailableInCatalog",defaults:"The attribute in the data source is not available in the catalog item."})});case M.lI.NotInBrowsing:return s.createElement(f,{tooltip:i18n({id:"catalogItem.data.attributeNotAvailableInDataSources",defaults:"The attribute in the catalog item is no longer available in the data source. Possible reason: the attribute was renamed or deleted."})});default:return null}}const A=i18n({id:"catalog.previewTable.notInCatalog",defaults:", not available in the catalog item"});const F=i18n({id:"catalog.previewTable.notInSource",defaults:", no longer available in the data source"});const R=i18n({id:"catalog.previewTable.hasPolicy",defaults:", has applied policy"});const _=i18n({id:"catalog.previewTable.selected",defaults:", selected column"});const O=({isMultiselect:e,label:t,value:a,isDisabled:i,onChange:r})=>e?s.createElement("label",null,s.createElement(c.XZ,{value:a,disabled:i,onChange:r,"aria-labelledby":`dataPreviewTable_label_${a}`}),s.createElement(n.T,{id:`dataPreviewTable_label_${a}`},t)):s.createElement(D,{value:a,isDisabled:i},s.createElement(n.T,null,t));const B=(0,r.Pi)((({testId:e,onColumnSelect:t,tableName:a,columns:i,rows:r,attributes:d,actions:u,selectedColumns:p,multiselect:h})=>{const m=(0,o.E)();const v=(0,s.useCallback)((e=>{if(e!==null){const t=e.getBoundingClientRect().height;e.style.setProperty("--table-height",`${t}px`)}}),[]);return s.createElement(P,{ref:v,"data-testid":`${e}_data`},s.createElement(n.T,{elementType:"caption"},i18n({id:"catalog.previewTable.tableName",defaults:"Data preview of {tableName}.",values:{tableName:a}})," ",t&&i18n({id:"catalog.previewTable.selectable",defaults:"Has selectable columns"})," "),s.createElement("thead",null,s.createElement("tr",null,i.map(((a,i)=>{var n;const r=a.HeaderCell||L;const o=a.HeaderContent||V;const m=d.find((e=>e.name===a.name));const v=!!(p!==null&&p!==void 0&&p.has(a.key));const g=a.state!==M.lI.Actual;return s.createElement(r,{key:a.key||i,"data-testid":`${e}_data_header`,style:{...a.style},scope:"col",selected:v},s.createElement("div",{"aria-label":`${a.name} ${m!==null&&m!==void 0&&m.dataType?`, data type: ${m===null||m===void 0?void 0:(n=m.dataType)===null||n===void 0?void 0:n.valueOf().toLowerCase()}`:""} ${a.state===M.lI.NotInCatalogItem?A:""}${a.state===M.lI.NotInBrowsing?F:""} ${a.hasPolicyApplied?R:""} ${v?_:""}`,style:{height:"100%"}},(u||t)&&s.createElement(I,{active:v},t?s.createElement(c.xu,{alignY:"center"},s.createElement(O,{value:a.key,label:a.name,isDisabled:g,isMultiselect:h,onChange:()=>{if(m){t(m)}}})):s.createElement("span",null),u&&s.createElement(l.J,{actions:u(m)})),g&&s.createElement(T,null),o({column:a,attribute:m,testId:e,hasActions:!!(u||t)})))})))),s.createElement(N,null,r.map((t=>{const a=m(t);return s.createElement("tr",{key:a},i.map((i=>{const n=i.CellRenderer||M.ls;return s.createElement(k,{key:`${i.name}-${a}`,isRightAligned:i.alignRight,"data-testid":`${e}_data_cell_value`},i.state!==M.lI.Actual&&s.createElement(T,null),s.createElement(c.Hm,null,n(t,i.name)))})))}))))}));function Z({rows:e,tableName:t,columns:a,attributes:i=[],onColumnSelect:n,selectedColumns:r,multiselect:l=false,testId:o="data_preview",actions:d}){return s.createElement(c.Rm,null,l?s.createElement(B,{rows:e,tableName:t,columns:a,attributes:i,multiselect:l,testId:o,actions:d,onColumnSelect:n,selectedColumns:r}):s.createElement(s.Fragment,null,s.createElement(c.Ee,{groupElement:"div",legendElement:"div",orientation:"horizontal",label:"",onChange:e=>{const t=i.find((t=>t._displayName===e));if(t&&n){n(t)}},value:r?[...r][0]:undefined},s.createElement(B,{rows:e,tableName:t,columns:a,attributes:i,multiselect:l,testId:o,actions:d,onColumnSelect:n,selectedColumns:r}))))}},48400:(e,t,a)=>{"use strict";a.d(t,{lI:()=>l,ls:()=>c,Q5:()=>d,RC:()=>u});var i=a(33948);var n=a.n(i);var r=a(80828);var s=a(53536);var l;(function(e){e["NotInCatalogItem"]="NOT_IN_CATALOG_ITEM";e["NotInBrowsing"]="NOT_IN_BROWSING";e["Actual"]="ACTUAL"})(l||(l={}));function o(e){switch(e){case s.Vz.Integer:case s.Vz.Float:case s.Vz.Long:return true;default:return false}}function c(e,t){(0,r.h)(!(typeof e[t]==="object"&&e[t]!==null),`Trying to render non-scalar data without custom renderer. Please provide cell-render for column ${t}`);return e[t]}function d(e){if(e){return e.rows.map((t=>t.records.reduce(((t,a,i)=>{t[e.columns[i].name]=a.value;return t}),{})))}return[]}function u(e,t){if(e){const a=e.columns.map((e=>{const a=t?t.find((t=>t.name===e.name)):undefined;return{name:e.name,key:e.name,state:a===undefined?l.NotInCatalogItem:l.Actual,hasPolicyApplied:e.dataPolicy,primaryKey:e.item.primaryKey,foreignKey:e.item.foreignKey,alignRight:a?o(a.dataType):false}}));let i=[];if(t){i=t.reduce(((t,a)=>{const i=e.columns.find((e=>e.name===a.name));if(!i){t.push({name:a.name,key:a.name,state:l.NotInBrowsing,primaryKey:a.primaryKey,foreignKey:a.foreignKey})}return t}),[])}return[...a,...i]}return[]}},63570:(e,t,a)=>{"use strict";a.d(t,{e:()=>CatalogItemDataBrowser});var i=a(70655);var n=a(22188);var r=a(82142);var s=a(22930);var l=a(15897);var o=a(23552);var c=a(76851);var d=a(80673);var u=a.n(d);function p(e,t){return e.add({document:u(),variables:t})}var h=a(68221);const m=e=>e==="INTEGER"||e==="FLOAT"||e==="LONG";class CatalogItemDataBrowser{constructor(e,t=50){this.catalogItemGid=e;this.limit=t;this.columns=[];this.rows=[];this.isLoading=false;this.isLoadedInitially=false;this.init=()=>this.fetchData();this.setCredential=e=>{this.credential=e;return this.fetchData()};this.handleError=e=>{this.error=(0,h.U)(e).decode(e)}}get isEmpty(){return this.isLoadedInitially&&this.rows.length===0}get tableData(){const e=this.columns.map((e=>{const t=m(e.dataType)?"right":"left";return{...e,key:e.name,style:{maxWidth:"400px",textAlign:t},headerStyle:{textAlign:t}}}));const t=this.rows.map((({records:e})=>e.reduce(((e,t,a)=>{e[this.columns[a].name]=t.value;return e}),{})));return{columns:e,rows:t}}async fetchData(){this.isLoading=true;const e=this.credential===undefined;try{var t;const a=await p(new s.wk(this.apiClient),{gid:this.catalogItemGid,credentialsSelector:this.credential?{gid:this.credential._gid,publishedVersion:true}:undefined,defaultCredential:e,limit:this.limit});a.ensureOkAt(["catalogItem","preview"]);if((t=a.data.catalogItem)!==null&&t!==void 0&&t.preview){this.columns=a.data.catalogItem.preview.headers;this.rows=a.data.catalogItem.preview.data}}catch(e){if(e instanceof l.H){this.handleError(e)}else{throw e}}finally{this.isLoading=false;this.isLoadedInitially=true}}}(0,i.gn)([(0,c.Q)((()=>r.l))],CatalogItemDataBrowser.prototype,"apiClient",void 0);(0,i.gn)([n.LO],CatalogItemDataBrowser.prototype,"columns",void 0);(0,i.gn)([n.LO],CatalogItemDataBrowser.prototype,"rows",void 0);(0,i.gn)([n.LO],CatalogItemDataBrowser.prototype,"isLoading",void 0);(0,i.gn)([n.LO],CatalogItemDataBrowser.prototype,"isLoadedInitially",void 0);(0,i.gn)([n.LO],CatalogItemDataBrowser.prototype,"error",void 0);(0,i.gn)([n.Fl],CatalogItemDataBrowser.prototype,"isEmpty",null);(0,i.gn)([n.Fl],CatalogItemDataBrowser.prototype,"tableData",null);(0,i.gn)([o.H,n.aD],CatalogItemDataBrowser.prototype,"fetchData",null)},42645:(e,t,a)=>{"use strict";a.d(t,{w:()=>DatasourceBrowserSelectionModel});var i=a(70655);var n=a(85023);var r=a(86359);var s=a(67294);var l=a(29052);var o=a(82142);var c=a(22930);var d=a(45548);var u=a(77745);var p=a(17267);var h=a(47836);var m=a(9447);var v=a(9190);const g=(e,t,a,i)=>n=>{if(!n.items.some((e=>e.importable))){return null}const r={displayName:t,tooltip:a,execute:()=>y(n,e),testId:i};return r};async function y(e,t){if(t.includes(v.r4.PROFILE)){const e=d.n.get(l.g);const{accepted:t}=await e.show(((e,t)=>s.createElement(u.b,{title:s.createElement(r.Trans,{id:"catalog.BulkImportToCatalogAction.confirm.title",defaults:"Full profiling"}),onAccept:e,onDecline:t},s.createElement(r.Trans,{id:"catalog.BulkImportToCatalogAction.confirm.content",defaults:"Full profiling will access your data source in order to retrieve more information regarding these catalog items.<0><1>This may temporarily reduce source performance</1><2>Others may be using the source so notify them of the potential disruption</2></0>",components:[s.createElement("ul",null),s.createElement("li",null),s.createElement("li",null)]}))));if(!t){return null}}const{connection:a}=e;const i=!(0,h.tF)(a._);const n={connectionId:a._gid,path:e.items.map((e=>e.path)),flows:t};if(i){const e=await(0,m.E)(a);if(!e){return null}n.credentialsSelector={gid:e._.gid,publishedVersion:true}}const g=d.n.get(o.l);await(0,p.S)(new c.wk(g),n)}var f=a(25917);class AbstractDatasourceBrowserSelectionModel extends f.O{isEqual(e,t){return e.path.length===t.path.length&&e.path.every(((e,a)=>e===t.path[a]))}}var b=a(22188);var E;(function(e){e["ROOT"]="ROOT";e["DIRECTORY"]="DIRECTORY";e["FILE"]="FILE";e["FILE_COLUMN"]="FILE_COLUMN";e["DATABASE"]="DATABASE";e["SCHEMA"]="SCHEMA";e["TABLE"]="TABLE";e["COLUMN"]="COLUMN";e["RDM"]="RDM";e["RDM_ENTITY_TYPE"]="RDM_ENTITY_TYPE";e["RDM_COLUMN"]="RDM_COLUMN";e["METASTORE_DATABASE"]="METASTORE_DATABASE";e["METASTORE_TABLE"]="METASTORE_TABLE";e["METASTORE_COLUMN"]="METASTORE_COLUMN";e["MDM"]="MDM";e["MDM_MASTER_VIEW"]="MDM_MASTER_VIEW";e["MDM_LAYER"]="MDM_LAYER";e["MDM_TABLE"]="MDM_TABLE";e["MDM_COLUMN"]="MDM_COLUMN"})(E||(E={}));const w=[{factory:g([],i18n({id:"catalog.actions.bulkImportToCatalog",defaults:"Import to catalog"}),i18n({id:"catalog.actions.bulkImportToCatalog.tooltip",defaults:"Quickly scan the source and import metadata without accessing the data."}),"catalog_bulkImportToCatalog"),isSample:false},{factory:g([v.r4.DISCOVER],i18n({id:"catalog.actions.bulkDiscover",defaults:"Discover"}),i18n({id:"catalog.actions.bulkDiscover.tooltip",defaults:"Profile a sample of data."}),"catalog_bulkDiscover"),isSample:true},{factory:g([v.r4.PROFILE],i18n({id:"catalog.actions.bulkProfile",defaults:"Profile"}),i18n({id:"catalog.actions.bulkProfile.tooltip",defaults:"Profile all data."}),"catalog_bulkProfile"),isSample:false}];const C=[E.FILE,E.FILE_COLUMN,E.DIRECTORY];class DatasourceBrowserSelectionModel extends AbstractDatasourceBrowserSelectionModel{constructor(e){super();this.connection=e;this.actions=[];this.secondaryAction=null}get primaryAction(){const{items:e}=this;const t=e.some((e=>C.includes(e.type)));const a=w.map((e=>{if(e.isSample&&t){return null}return e.factory(this)})).filter(n.D);if(a.length===0){return null}return{actions:a,testId:"catalog_bulkProfileGroup",mainActionIdx:a.length-1}}}(0,i.gn)([b.Fl],DatasourceBrowserSelectionModel.prototype,"primaryAction",null)},43625:(e,t,a)=>{"use strict";a.r(t);a.d(t,{AttributeColumnTypeTableCell:()=>c});var i=a(70655);var n=a(29323);var r=a(27295);var s=a(71534);var l=a(40952);const o={rowData:s.T.entityVersion(l.ah)};let c=class AttributeColumnTypeTableCell extends((0,r.Bq)({},o)){render(){const{columnType:e,columnSize:t}=this.props.rowData;if(!e){return null}if(t){return`${e} (${t})`.toUpperCase()}return e.toUpperCase()}};c=(0,i.gn)([n.Pi],c)},20389:(e,t,a)=>{"use strict";a.r(t);a.d(t,{AttributeConstraintTableCell:()=>v});var i=a(33948);var n=a(70655);var r=a(29323);var s=a(67294);var l=a(27295);var o=a(71534);var c=a(80880);var d=a(81012);const u=d.ZP.div`
  display: flex;
`;let p=class AttributeConstraints extends s.Component{render(){const{items:e}=this.props;return s.createElement(u,null,e.map((({text:e,tooltip:t},a)=>t?s.createElement(c.u,{key:a,tooltip:t},s.createElement(c.Zx,null,e)):s.createElement(c.Zx,{key:a},e))))}};p=(0,n.gn)([r.Pi],p);var h=a(40952);const m={rowData:o.T.entityVersion(h.ah)};let v=class AttributeConstraintTableCell extends((0,l.Bq)({},m)){get attributeName(){return this.props.rowData.name}get parentCatalogItem(){var e;return(e=this.props.rowData._.parent)===null||e===void 0?void 0:e.versions.draft}getPrimaryKey(e){const t=this.attributeName;const a=e.columns._.items.reduce(((e,t)=>t?[...e,t.name]:e),[]);if(a.includes(t)){return{text:`PRIMARY KEY${a.length>1?`(${a.join(",")})`:""}`}}return null}getForeignKeys(e){const t=this.attributeName;return e.items.reduce(((e,a)=>{const i=(a===null||a===void 0?void 0:a.columns._.items)||null;if(i&&i.length>0){i.forEach((a=>{if((a===null||a===void 0?void 0:a.name)===t){const{referencedSchema:t,referencedTableName:i,referencedColumnName:n}=a;const r=[t,i,n].filter(Boolean).join(".");e.push({text:`FOREIGN KEY(${n})`,tooltip:r})}}))}return e}),[])}render(){const{rowData:e}=this.props;const t=this.parentCatalogItem;if(t){const a=t.primaryKey;const i=a?this.getPrimaryKey(a):null;const n=this.getForeignKeys(t.foreignKeys._);const r=[];if(i){r.push(i)}r.push(...n);if(!e.nullable){r.push({text:"NOT NULL"})}return s.createElement(p,{items:r})}return null}};v=(0,n.gn)([r.Pi],v)},13624:(e,t,a)=>{"use strict";a.r(t);a.d(t,{AttributeDataTypeTableCell:()=>u});var i=a(70655);var n=a(29323);var r=a(67294);var s=a(27295);var l=a(71534);var o=a(43539);var c=a(40952);const d={rowData:l.T.entityVersion(c.ah)};let u=class AttributeDataTypeTableCell extends((0,s.Bq)({},d)){render(){const{rowData:e}=this.props;return r.createElement(o.X,{attribute:e,showTooltip:true})}};u=(0,i.gn)([n.Pi],u)},51194:(e,t,a)=>{"use strict";a.r(t);a.d(t,{CatalogItemAttributesView:()=>$});var i=a(70655);var n=a(29323);var r=a(67294);var s=a(27295);var l=a(33948);var o=a(39693);var c=a.n(o);var d=a(18446);var u=a.n(d);var p=a(22188);var h=a(22558);var m=a(77544);var v=a(86676);var g=a(80828);var y=a(76851);var f=a(76754);var b=a(73225);var E=a(42496);var w=a(26387);var C=a(29289);var S=a(17828);var I=a(81012);var x=a(43539);var T=a(59446);const P=I.ZP.div`
  align-self: center;
  display: flex;
  align-items: center;
`;let N=class AttributesList extends r.Component{constructor(){super(...arguments);this.loadingAnomalyStates=false}get listingItems(){return this.props.hierarchyModel.items.items}async componentDidUpdate(){if(!u()(this.listingItems,this.prevListingItems)){this.prevListingItems=[...this.listingItems];await this.fetchAnomalyStates()}}async componentDidMount(){this.prevListingItems=[...this.listingItems];await this.fetchAnomalyStates()}async fetchAnomalyStates(){var e;if(!this.props.showAnomalies||!((e=this.listingItems)!==null&&e!==void 0&&e.length)){return}this.loadingAnomalyStates=true;const t=c()(this.listingItems.map((e=>e.item._gid)));const a=this.listingItems[0].item._.metadata.entity;(0,g.h)(a,`Unable to find entity`);await this.entityManager.getEntitiesOfCollection(t,a,{fetchRules:[...b.I7,...b.Wl],version:m.XH.Draft});this.loadingAnomalyStates=false}render(){const{handleItemClick:e,isHierarchical:t,detailController:a,showTerms:i,showAnomalies:n,anomalyPopupPlacement:s}=this.props;return r.createElement(r.Fragment,null,this.listingItems.map((l=>{var o;const{item:c}=l;const{termInstances:d,termSuggestions:u,hiddenTermInstances:p}=c;const h=(o=a.defaultValueManager)===null||o===void 0?void 0:o.checkIsDefault(c);return r.createElement(r.Fragment,{key:c._gid},r.createElement(C.B,{item:l,level:0,onItemClick:e,itemActionsFactory:this.props.itemActionsFactory,isHierarchical:t,beforeNameContent:r.createElement(x.X,{attribute:c,showTooltip:true}),isHighlighted:(0,T.x)(l.item._),afterNameContent:r.createElement(r.Fragment,null,h&&r.createElement(w.C,null,"Default"),i&&r.createElement(S.Y,{termInstances:d,termSuggestions:u,forcedAllowSuggestion:c._.permissions.canProperty(v.f.CreateNewDraft,"termSuggestions"),hiddenTermInstances:p,disabled:false,oneRow:true}),n&&r.createElement(P,null,this.loadingAnomalyStates?r.createElement(f.Vx,null):(0,E.cs)(c.anomalyState)&&r.createElement(f.e0,{feedback:c.anomalyState.feedback,explanationLabels:(0,E.II)(c.anomalyExplanations),popupPlacement:s,attribute:c,profileGid:c.anomalyState.catalogItemProfileGid})))}))})))}};(0,i.gn)([(0,y.Q)((()=>h.v))],N.prototype,"entityManager",void 0);(0,i.gn)([p.LO],N.prototype,"loadingAnomalyStates",void 0);(0,i.gn)([p.Fl],N.prototype,"listingItems",null);(0,i.gn)([p.LO],N.prototype,"prevListingItems",void 0);N=(0,i.gn)([n.Pi],N);var k=a(7214);var D=a(31310);var L=a(473);var M=a(87204);var V=a(16583);let $=class CatalogItemAttributesView extends((0,s.Bq)({renderController:s.T.instanceOf(D.q),isNested:s.T.bool(false),showTerms:s.T.bool(true),showAnomalies:s.T.bool(true),anomalyPopupPlacement:s.T.str(V.Iw.top)},{detailController:s.T.instanceOf(L.T),onRowClick:s.T.any(undefined)},(({ctx:e})=>({itemActionsFactory:(0,M.o)(e.variables)})))){render(){const{renderController:e,detailController:t,onRowClick:a,showAnomalies:i,showTerms:n,anomalyPopupPlacement:s}=this.props;return r.createElement(k.z,{detailController:t,listingHierarchy:[],onRowClick:a,renderController:e,isNested:false},(e=>r.createElement(N,Object.assign({showAnomalies:i,showTerms:n,anomalyPopupPlacement:s,itemActionsFactory:this.props.itemActionsFactory},e))))}};$=(0,i.gn)([n.Pi],$)},98273:(e,t,a)=>{"use strict";a.r(t);a.d(t,{CatalogItemDataStructure:()=>T});var i=a(70655);var n=a(29323);var r=a(67294);var s=a(27295);var l=a(1121);var o=a(33948);var c=a(86359);var d=a(22188);var u=a(80880);var p=a(47850);var h=a(75472);var m=a.n(h);var v=a(96907);var g=a(25108);class ManualSortingModel{constructor(){this.sortDirection=null;this.sortColumn=null;this.toggleOrder=e=>{if(this.sortColumn===e){if(this.sortDirection==="asc"){this.sortDirection="desc"}else{this.sortDirection=null;this.sortColumn=null}}else{this.sortColumn=e;this.sortDirection="asc"}}}sort(e,t){if(this.sortDirection&&this.sortColumn){var a;const i=e.find((e=>e.key===this.sortColumn));if(!i){g.error("Attempting to sort by unknown column");return t}const n=(a=i.cellDataGetter)!==null&&a!==void 0?a:p.Fi;return m()(t,(e=>n(e,i)),this.sortDirection)}return t}get order(){if(this.sortDirection&&this.sortColumn){return{property:this.sortColumn,direction:this.sortDirection==="asc"?v.N.ASC:v.N.DESC}}return undefined}}(0,i.gn)([d.LO],ManualSortingModel.prototype,"sortDirection",void 0);(0,i.gn)([d.LO],ManualSortingModel.prototype,"sortColumn",void 0);(0,i.gn)([d.aD],ManualSortingModel.prototype,"toggleOrder",void 0);(0,i.gn)([d.Fl],ManualSortingModel.prototype,"order",null);var y=a(81012);const f=y.ZP.span`
  ${e=>e.theme.font.data()};
`;const b=[{key:"partition",name:i18n({id:"catalog.partitionsList.tableHeader",defaults:"Partition"}),sortingEnabled:true,CellRenderer:({cellData:e})=>r.createElement(f,null,e)}];let E=class PartitionsList extends r.Component{constructor(){super(...arguments);this.sortingModel=new ManualSortingModel}get items(){const{partitions:e}=this.props;if(!e||e.length===0){return[]}const t=e.split(";").map((e=>({partition:e})));return this.sortingModel.sort(b,t)}render(){if(this.items.length===0){return null}return r.createElement(u.Zb,{title:r.createElement(c.Trans,{id:"catalog.partitionsList.title",defaults:"Latest Partitions"}),fullWidthContent:true},r.createElement(u.Rm,null,r.createElement(p.iA,{rows:this.items,columns:b,onColumnHeaderClick:this.sortingModel.toggleOrder,order:this.sortingModel.order})))}};(0,i.gn)([d.LO],E.prototype,"sortingModel",void 0);(0,i.gn)([d.Fl],E.prototype,"items",null);E=(0,i.gn)([n.Pi],E);var w=a(40952);const C=y.ZP.div`
  display: flex;
  ${e=>e.theme.margin.top("M")};
`;const S=y.ZP.div`
  flex: auto;
`;const I=y.ZP.div`
  width: 50%;
  ${e=>e.theme.margin.left("M")};

  &:empty {
    display: none;
  }
`;const x={entity:s.T.entity(w.t$)};let T=class CatalogItemDataStructure extends((0,s.Bq)(x,{},(async({props:{entity:e},ctx:t})=>{const a=e.versions.draft;const i=a.attributes._.clone();const n=new l._(i);const r=a.indices._;const o=new l._(r);return{AttributesRenderer:await s.T.widget({}).resolve({_type:"entity.listing",filterRenderer:{_type:"entity.listing.textFilter"}},t.createChild("_args").fork({listingView:n,entityMetadata:i.entityMetadata,requiredProperties:i.query.getProperties(),enableSelection:false,columns:{dataType:{sortingEnabled:false},name:{after:"dataType",name:"Name"},columnType:{after:"name",name:"Original type"},primaryKey:{after:"columnType",name:"Constraints"},comment:{after:"primaryKey",name:"Comment"},foreignKey:{enabled:false},nullable:{enabled:false},columnSize:{enabled:false},termInstances:{enabled:false},termSuggestions:{enabled:false}}})),IndicesRenderer:await s.T.widget({}).resolve({_type:"entity.listing",filterRenderer:{_type:"entity.listing.textFilter"}},t.createChild("_args").fork({listingView:o,entityMetadata:r.entityMetadata,requiredProperties:r.query.getProperties(),enableSelection:false,columns:{columns:{enabled:false},name:{after:"unique",name:"Name"},columnName:{after:"name",name:"Columns",dataPath:[],renderer:{_type:"index.columnName.tableCell"}}}}))}}))){render(){const{AttributesRenderer:e,IndicesRenderer:t,entity:a}=this.props;const i=a.versions.draft;return r.createElement(r.Fragment,null,r.createElement(u.Zb,{title:i18n({id:"catalogItem.dataStructure.attributes.title",defaults:"Attributes"})},e()),r.createElement(C,null,r.createElement(S,null,r.createElement(u.Zb,{title:i18n({id:"catalogItem.dataStructure.indices.title",defaults:"Indices"})},t())),r.createElement(I,null,r.createElement(E,{partitions:i.partitions}))))}};T=(0,i.gn)([n.Pi],T)},17455:(e,t,a)=>{"use strict";a.d(t,{y:()=>c});var i=a(67294);var n=a(90476);var r=a(80880);var s=a(81012);var l;(function(e){e[e["BrowsingNotAvailable"]=1]="BrowsingNotAvailable";e[e["EmptyPath"]=2]="EmptyPath";e[e["NoValidCredentials"]=3]="NoValidCredentials"})(l||(l={}));const o=(0,s.ZP)(r.nN)`
  display: flex;
  height: 440px;
`;function c({state:e}){var t;const a=i18n({id:"catalogItem.data.errorStateTitle",defaults:"Couldn't get the data sample"});const r=typeof e==="object"?(t=e.title)!==null&&t!==void 0?t:a:a;const s=typeof e==="object"?e.description:d(e);return i.createElement(o,null,i.createElement(n.a,{title:r,description:s}))}function d(e){switch(e){case l.BrowsingNotAvailable:return i18n({id:"catalogItem.data.browsingNotAvailable",defaults:"Catalog item has no connection reference"});case l.EmptyPath:return i18n({id:"catalogItem.data.emptyPath",defaults:"Catalog item's path is missing"});case l.NoValidCredentials:return i18n({id:"catalogItem.data.invalidCredentials",defaults:"Invalid credentials"});default:return i18n({id:"catalogItem.data.unknownError",defaults:"Unknown problem"})}}},81508:(e,t,a)=>{"use strict";a.r(t);a.d(t,{CatalogItemDataView:()=>F});var i=a(33948);var n=a.n(i);var r=a(15306);var s=a.n(r);var l=a(70655);var o=a(22188);var c=a(29323);var d=a(67294);var u=a(87625);var p=a(21610);var h=a(33031);var m=a(9009);var v=a(27295);var g=a(97325);var y=a(1946);var f=a(22558);var b=a(77544);var E=a(3997);var w=a(86676);var C=a(71534);var S=a(45548);var I=a(80828);var x=a(76851);var T=a(43025);var P=a(48400);var N=a(63570);var k=a(17455);var D=a(71052);var L=a(60328);var M=a(43503);var V=a(80880);var $=a(40952);const A={detailController:C.T.entityController($.me)};let F=class CatalogItemDataView extends((0,v.Bq)({},A,(async({ctx:e})=>{const t=S.n.get(f.v);const a=await t.getEntity("metadata",E.d.rootGid,{version:b.XH.Draft,fetchRules:[{pattern:`./lookupItems`}]});return{ctx:e.variables,lookupParentEntity:a}}))){constructor(){super(...arguments);this.dataBrowser=new N.e(this.props.detailController.entityVersion._gid,50);this.attributes=[];this.handleRedirectToLookupCreation=async e=>{var t;const{lookupParentEntity:a}=this.props;const i=a.metadata.getPropertyByName("lookupItems");const n=a.createChildDraft(i);const r=n._;const s=r.metadata.getEffectiveEntity();const l=await new L.h(s).getDefaultValues();if(l){r.update(l)}r.updateAt(["sourceItem"],(t=e._.parent)===null||t===void 0?void 0:t.versions.draft);r.updateAt(["key"],e);return this.sidebarManager.replace((0,D.w)(n))};this.columnActionsPopupContent=e=>[{displayName:i18n({id:"catalogItem.data.actions.createLookup",defaults:"Create new Lookup"}),disabled:!e||!this.canCreateLookup,execute:()=>this.handleRedirectToLookupCreation(e),testId:"ci-data-preview-create-lookup-action"}]}get isLoading(){return!this.dataBrowser||!this.dataBrowser.isLoadedInitially}get canCreateLookup(){return this.props.lookupParentEntity.permissions.canProperty(w.f.CreateNewDraft,"lookupItems")}async componentDidMount(){const{entityVersion:e}=this.props.detailController;(0,I.h)(e,`Missing catalog item entity version`);await Promise.all([this.dataBrowser.init(),this.fetchAllAttributes()])}get columns(){return(0,P.RC)(this.dataBrowser,this.attributes)}get rows(){return(0,P.Q5)(this.dataBrowser)}render(){const{error:e}=this.dataBrowser;if(e){return d.createElement(k.y,{state:{title:e.title,description:e.description}})}if(this.isLoading){return d.createElement(m.t2,null)}const{rows:t}=this.dataBrowser;const a=this.columns.filter((e=>e.state!==P.lI.Actual)).length;const i=a>0;const{bannerTitle:n,bannerText:r}=this.composeBannerTexts(t.length,a);return d.createElement(V.Kq,{gap:"M"},d.createElement(V.jL,{title:n,Icon:i?h.Ucq:h.ABW,type:i?V.$.Warning:V.$.Info},r),d.createElement(T.P,{columns:this.columns,rows:this.rows,tableName:`${this.props.detailController.entityMetadata.displayName} ${this.props.detailController.entityVersion._displayName}`,attributes:this.attributes,actions:this.columnActionsPopupContent,testId:this.props.detailController.property.testId}))}async fetchAllAttributes(){const{entityVersion:e}=this.props.detailController;if(!e){this.attributes=[];return}const t=this.entityManager.createMultiParentListing(e.attributes._.entityMetadata,{version:b.XH.LatestPublished,fetchRules:[...y.w$,...M.r4,{pattern:".",filter:`$parent.$id = "${e._gid}"`}]});await t.ensureItems({startIndex:0,size:Number.POSITIVE_INFINITY});this.attributes=t.filteredItems}composeBannerTexts(e,t){const a=this.dataBrowser.limit;const i=t?i18n({id:"catalogItem.metadata.changes",defaults:"Metadata Changes"}):e===a?i18n({id:"catalogItem.data.thisIsSample",defaults:"This is a Data Sample"}):i18n({id:"catalogItem.data.liveData",defaults:"Live data"});let n=i18n({id:"catalogItem.data.displayedDataIsLive",defaults:"Displayed data is live."});if(t){n=i18n({id:"catalogItem.data.changesInDataView",defaults:"{attributesChanged, plural, one {# change has been made to the data. The change made can be seen below. Displayed data is live.} few {# changes have been made to the data. The changes made can be seen below. Displayed data is live.} other {# changes have been made to the data. The changes made can be seen below. Displayed data is live.}}",values:{attributesChanged:t}})}if(e===a){n+=i18n({id:"catalogItem.data.dataIsSample",defaults:" The data displayed is a sample of the first {rowsAmount} lines of the data set.",values:{rowsAmount:e}})}return{bannerTitle:i,bannerText:n}}};(0,l.gn)([(0,x.Q)((()=>u.g))],F.prototype,"app",void 0);(0,l.gn)([(0,x.Q)((()=>E.d))],F.prototype,"mm",void 0);(0,l.gn)([(0,x.Q)((()=>f.v))],F.prototype,"entityManager",void 0);(0,l.gn)([(0,x.Q)((()=>g._f))],F.prototype,"actionRegistry",void 0);(0,l.gn)([(0,x.Q)((()=>p.E))],F.prototype,"sidebarManager",void 0);(0,l.gn)([o.LO],F.prototype,"attributes",void 0);(0,l.gn)([o.Fl],F.prototype,"isLoading",null);(0,l.gn)([o.Fl],F.prototype,"canCreateLookup",null);(0,l.gn)([o.aD],F.prototype,"componentDidMount",null);(0,l.gn)([o.Fl],F.prototype,"columns",null);(0,l.gn)([o.Fl],F.prototype,"rows",null);F=(0,l.gn)([c.Pi],F)},75197:(e,t,a)=>{"use strict";a.r(t);a.d(t,{CatalogItemInsights:()=>te});var i=a(33948);var n=a(70655);var r=a(22188);var s=a(29323);var l=a(67294);var o=a(90476);var c=a(27295);var d=a(1946);var u=a(22558);var p=a(77544);var h=a(3997);var m=a(45234);var v=a(96907);var g=a(80828);var y=a(76851);var f=a(29052);var b=a(40952);var E=a(98556);var w=a(81012);const C=w.ZP.div`
  display: flex;
  flex-direction: column;
`;const S=w.ZP.div`
  ${e=>e.theme.padding(0,"L")};
`;const I=w.ZP.div`
  ${e=>e.theme.font.bodyMedium()};
  ${e=>e.theme.margin.bottom("S")}
`;const x=w.ZP.div`
  ${e=>e.theme.font.bodyMedium()};
  color: ${e=>e.theme.palette.display.base};
  ${e=>e.theme.margin.bottom("S")}
`;var T=a(86359);var P=a(16702);var N=a(33031);var k=a(9009);var D=a(80880);var L=a(16583);var M=a(67047);var V=a(19965);const $=w.ZP.div`
  display: inline-flex;

  a {
    ${e=>e.theme.font.body()};
    color: ${e=>e.theme.palette.display[7]};
    text-decoration: underline solid ${e=>e.theme.palette.display[3]};
    cursor: pointer;

    ${L.le} {
      color: ${e=>e.theme.palette.display[3]};
      ${e=>e.theme.margin.right("XS")};
    }
  }
`;let A=class CatalogItemIconLink extends l.Component{render(){const{entityVersion:e}=this.props;const t=(0,V.h)(e._);return l.createElement($,null,l.createElement(M.F,{to:t},l.createElement(N.fqO,null),e.name))}};A=(0,n.gn)([s.Pi],A);const F=w.ZP.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  ${e=>e.theme.padding(0,"L")};

  &:not(:last-child) {
    border-bottom: 1px solid ${e=>e.theme.palette.separate[2]};
  }
`;const R=w.ZP.div`
  min-width: 275px;
`;const _=w.ZP.div`
  display: flex;
  align-items: center;

  ${R} {
    ${e=>e.theme.margin.right("M")};
  }
`;const O=w.ZP.div`
  ${e=>e.theme.margin.top("S")};
  display: flex;
  align-items: center;
  justify-content: space-between;
`;const B=w.ZP.div`
  display: flex;
  align-items: center;
  min-height: 44px;
  justify-content: space-between;

  div {
    display: flex;
    align-items: center;
  }
`;const Z=(0,w.ZP)(D.Mg)`
  display: flex;
  color: ${e=>e.theme.palette.display[3]};

  &:hover {
    color: ${e=>e.theme.palette.display.base};
  }
`;const q=(0,w.ZP)(Z)`
  ${e=>e.theme.margin.right("M")};
`;const Q=(0,w.ZP)(Z)``;const U=w.ZP.div`
  ${e=>e.theme.font.longread()};
  color: ${e=>e.theme.palette.display.base};
  ${e=>e.theme.padding.bottom("M")};

  ${e=>e.isExpandable&&w.iv`
      padding-left: 36px;
    `}
`;const H=w.ZP.span``;const K=w.ZP.div`
  display: inline-flex;
  align-items: center;
  justify-content: center;

  ${e=>e.theme.padding(0,"S")};
  height: 20px;
  border-radius: 10px;
  ${e=>e.theme.font.captionMedium()};
  color: ${e=>e.theme.palette.tertiary.base};

  ${e=>e.confidence&&w.iv`
      background-color: ${e.confidence>.8?e.theme.palette.success[5]:e.theme.palette.warning[5]};
    `}
`;let G=class SuggestedSimilarity extends l.Component{constructor(){super(...arguments);this.state={isExpanded:false};this.expand=()=>{this.setState((({isExpanded:e})=>({isExpanded:!e})))};this.handleOnSelectChange=e=>{this.setState({selectValue:e})};this.approveSuggestion=()=>{const{selectValue:e}=this.state;if(e){this.props.approve(this.props.similarity,e)}}}render(){const{confidence:e,metadataConfidence:t,dataConfidence:a}=this.props.similarity;const{target:i,relationshipTypeEdgesOptions:n,isLoading:r,isExpandable:s}=this.props;const{isExpanded:o,selectValue:c}=this.state;const[d,u,p]=[e,t,a].map((e=>e===null||e===-1||Number.isNaN(e)?null:(0,P.Ov)(1,e)));const h=e!==null?l.createElement(D.u,{tooltip:this.buildConfidenceTooltipText(d,u,p),delay:0,placement:s?L.Iw.left:L.Iw.top,Wrapper:H},l.createElement(K,{confidence:e},d)):null;const m=l.createElement(O,null,l.createElement(_,null,l.createElement(R,null,l.createElement(D.AS,{placeholder:i18n({id:"catalog.suggestedSimilarities.selectPlaceholder",defaults:"Choose Relationship"}),items:n,onChange:this.handleOnSelectChange,disabled:r,testId:"similarityItem_selectRelationship"})),c&&l.createElement(D.zx,{primary:true,"data-testid":"similarityItem_create",disabled:r,onClick:this.approveSuggestion,icon:r?l.createElement(k.$j,null):null},i18n({id:"catalog.suggestedSimilarities.approveSuggestion",defaults:"Create Relation"}))),l.createElement(D.u,{tooltip:i18n({id:"catalog.suggestedSimilarities.rejectSuggestion",defaults:"Reject Suggestion"}),delay:0,placement:L.Iw.left},l.createElement(Q,{"data-testid":"similarityItem_discard",icon:l.createElement(N.XSZ,null),onClick:()=>this.props.reject(this.props.similarity)})));return l.createElement(F,{"data-testid":"similarityItem"},s?l.createElement(l.Fragment,null,l.createElement(B,null,l.createElement("div",null,l.createElement(q,{icon:l.createElement(N.CCt,{direction:o?"DOWN":"RIGHT"}),onClick:this.expand}),l.createElement(A,{entityVersion:i})),h),o&&l.createElement(U,null,m)):l.createElement(U,null,l.createElement(T.Trans,{id:"catalog.suggestedSimilarities.suggestion",defaults:"There is a {confidenceTooltip} chance that this catalog item relates to {0}. Choose the type of the relationship.",values:{0:l.createElement(A,{entityVersion:i}),confidenceTooltip:h}}),m))}buildConfidenceTooltipText(e,t,a){let i=i18n({id:"catalog.suggestedSimilarities.tooltip.simple",defaults:"It is {confPerc} likely that these assets are related.",values:{confPerc:e}});if(t!==null&&a!==null){i=i18n({id:"catalog.suggestedSimilarities.tooltip.explained",defaults:"It is {confPerc} likely that these assets are related. The confidence level based on metadata is {mdConfPerc} and on data is {dataConfPerc}.",values:{confPerc:e,mdConfPerc:t,dataConfPerc:a}})}return i}};G=(0,n.gn)([s.Pi],G);let W=class SuggestedSimilarities extends l.Component{constructor(){super(...arguments);this.suggestionInApproval=null;this.rejectSuggestion=async e=>{if(await this.modalManager.confirm({title:i18n({id:"catalog.suggestedSimilarities.rejectSuggestion",defaults:"Reject Suggestion"}),content:i18n({id:"catalog.suggestedSimilarities.rejectDescription",defaults:"Do you really want to reject suggestion? You can’t undo this action."}),confirmButtonLabel:i18n({id:"catalog.suggestedSimilarities.rejectConfirm",defaults:"Reject"})})){e._.update({status:b.qC.Rejected});await this.entityManager.saveEntity(e._);await this.refreshSuggestionsWidget()}};this.approveSuggestion=async(e,t)=>{const a=this.props.relationshipsController.relationshipTypeEdges.find((e=>(0,E.zu)(e.type._.gid,e.name)===t));(0,g.h)(a,"Missing relationship type");this.suggestionInApproval=e;await this.createRelation(a,this.getSuggestionTarget(e));await this.refreshRelationsWidget();e._.update({status:b.qC.Approved});await this.entityManager.saveEntity(e._);await this.refreshSuggestionsWidget();this.suggestionInApproval=null};this.getSuggestionTarget=e=>{const{source:t}=this.props;const{catalogItem1:a,catalogItem2:i}=e;if(t._gid===a._gid){return i}else{return a}}}relationshipTypeEdgesOptions(e){return this.props.relationshipsController.relationshipTypeEdges.map((t=>({value:(0,E.zu)(t.type._.gid,t.name),label:`${t.name} ${e}`})))}render(){const{suggestions:e,multipleDescription:t}=this.props;const a=e.filteredItems.length>1;return l.createElement(C,null,l.createElement(S,null,l.createElement(I,null,i18n({id:"catalog.suggestedSimilarities.title",defaults:"Detected Similarities"})),a&&t&&l.createElement(x,null,t)),e.filteredItems.map(((e,t)=>{const i=this.getSuggestionTarget(e);return l.createElement(G,{key:e._gid||t,target:i,similarity:e,approve:this.approveSuggestion,reject:this.rejectSuggestion,relationshipTypeEdgesOptions:this.relationshipTypeEdgesOptions(i.name),isExpandable:a,isLoading:this.suggestionInApproval?e._gid===this.suggestionInApproval._gid:false})})))}async createRelation(e,t){const a=(0,E.xn)(e.type,e.name,e.isCurrentEntitySource);const i=this.props.relationshipsController.listing.appendNewItem({type:a.type,source:this.props.source,target:t});await this.entityManager.saveEntity(i._);return i}async refreshSuggestionsWidget(){this.props.suggestions.reset();await this.props.suggestions.ensureItems()}async refreshRelationsWidget(){this.props.relationshipsController.listing.reset();await this.props.relationshipsController.listing.ensureItems()}};(0,n.gn)([(0,y.Q)((()=>f.g))],W.prototype,"modalManager",void 0);(0,n.gn)([(0,y.Q)((()=>u.v))],W.prototype,"entityManager",void 0);(0,n.gn)([r.LO],W.prototype,"suggestionInApproval",void 0);(0,n.gn)([r.aD],W.prototype,"rejectSuggestion",void 0);(0,n.gn)([r.aD],W.prototype,"approveSuggestion",void 0);(0,n.gn)([r.aD],W.prototype,"createRelation",null);(0,n.gn)([r.aD],W.prototype,"refreshSuggestionsWidget",null);(0,n.gn)([r.aD],W.prototype,"refreshRelationsWidget",null);W=(0,n.gn)([s.Pi],W);var z=a(84258);var j=a(62744);const X=w.ZP.div`
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: ${e=>e.theme.palette.error[5]};
  ${e=>e.theme.padding(0,"S")};
  border-radius: 10px;
  ${e=>e.theme.font.captionMedium()};
  color: ${e=>e.theme.palette.tertiary.base};
  height: 20px;
  ${e=>e.theme.margin.left("S")};
`;const Y=w.ZP.div`
  display: flex;
  align-items: center;
`;const J=(0,w.ZP)(j.Y).attrs({width:"100px"})`
  color: ${e=>e.theme.palette.separate[2]};
`;const ee={entity:c.T.entity(b.me),relationshipController:c.T.instanceOf(z.H,undefined),relationshipPropertyPath:c.T.str()};let te=class CatalogItemInsights extends((0,c.Bq)(ee)){constructor(){super(...arguments);this.initialAmount=0;this.catalogItemRelationshipSuggestions=(()=>{const e=this.props.entity.gid;const t="/catalogItemSimilarityRelationSuggestions";const a=this.metadataManager.getPropertyForNodePath(t);(0,g.h)(a instanceof m.V,`Unknown property at ${t.toString()}`);const i=this.entityManager.createMultiParentListing(a.entity,{version:p.XH.Draft,fetchRules:[...d.w$,{pattern:".",orderBy:"confidence",orderDirection:v.N.DESC,filter:`(catalogItem1.$id = "${e}" OR catalogItem2.$id = "${e}") AND status = "${b.qC.Pending}" AND confidence >= 0.5`}]});return i})();this.relationshipsController=this.props.relationshipController||new z.H(this.props.relationshipPropertyPath,this.props.entity)}async componentDidMount(){await this.catalogItemRelationshipSuggestions.ensureItems();this.initialAmount=this.catalogItemRelationshipSuggestions.filteredItems.length}render(){const e=this.catalogItemRelationshipSuggestions.filteredItems.length;if(this.initialAmount===0){return null}const t=l.createElement(Y,null,i18n({id:"catalog.widgets.insights.title",defaults:"Insights"}),e>0&&l.createElement(X,null,e));const a=this.catalogItemRelationshipSuggestions.isLoading;return l.createElement(D.Zb,{title:t,fullWidthContent:true,fullHeightContent:!a},a?l.createElement(o.c,null):e===0?l.createElement(o.a,{icon:l.createElement(J,null),title:i18n({id:"catalog.widgets.insights.feedback.title",defaults:"Thanks for the feedback!"}),description:i18n({id:"catalog.widgets.insights.feedback.description",defaults:"When I have more interesting insights, I’ll let you know."})}):l.createElement(W,{source:this.props.entity.versions.draft,suggestions:this.catalogItemRelationshipSuggestions,relationshipsController:this.relationshipsController,multipleDescription:i18n({id:"catalog.suggestedSimilarities.descriptionWhenMultiple",defaults:"There is a chance that this catalog item relates to the following assets. Choose the type of each relationship."})}))}};(0,n.gn)([(0,y.Q)((()=>h.d))],te.prototype,"metadataManager",void 0);(0,n.gn)([(0,y.Q)((()=>u.v))],te.prototype,"entityManager",void 0);(0,n.gn)([r.LO],te.prototype,"initialAmount",void 0);(0,n.gn)([r.LO],te.prototype,"catalogItemRelationshipSuggestions",void 0);(0,n.gn)([r.LO],te.prototype,"relationshipsController",void 0);te=(0,n.gn)([s.Pi],te)},60849:(e,t,a)=>{"use strict";a.r(t);a.d(t,{CatalogItemLocationView:()=>f});var i=a(33948);var n=a.n(i);var r=a(70655);var s=a(81012);var l=a(16583);var o=a(29323);var c=a(67294);var d=a(73394);var u=a(84941);var p=a(27295);var h=a(80959);var m=a(18350);var v=a(42979);var g=a(80880);const y=(0,s.ZP)(d.O)`
  flex-wrap: wrap;

  ${u.FB} {
    ${g.RP};
    ${e=>e.theme.font.regular()};

    ${l.le} {
      color: ${e=>e.theme.palette.display[3]};
      ${e=>e.theme.transition.normal("color")};
    }

    &:hover,
    &:focus {
      color: ${e=>e.theme.palette.interaction[5]};
      text-decoration-color: ${e=>e.theme.palette.interaction[3]};

      ${l.le} {
        color: ${e=>e.theme.palette.display[4]};
      }
    }
  }
`;let f=class CatalogItemLocationView extends((0,p.Bq)({},{entityVersion:p.T.entityVersion()})){constructor(){super(...arguments);this.breadcrumbs=this.getBreadcrumbs()}render(){return c.createElement(g.Md,{"data-testid":`location`},c.createElement(m.V,null,i18n({id:"catalog.widgets.catalogItemLocationView.label",defaults:"Location"})),c.createElement(g.OI,null,c.createElement(y,{showIcons:true,items:this.breadcrumbs.items.slice(1)})))}getBreadcrumbs(){const{entityVersion:e}=this.props;const t=e._.traits.withTrait(v.o,(e=>e.all));return new h.Z(t)}};f=(0,r.gn)([o.Pi],f)},41299:(e,t,a)=>{"use strict";a.r(t);a.d(t,{CatalogItemOriginTableCell:()=>CatalogItemOriginTableCell,CatalogItemOriginView:()=>CatalogItemOriginView});var i=a(67294);var n=a(33031);var r=a(27295);var s=a(25542);const l={AMAZON_S3:n.Qk2,"AURORA-MYSQL":n.Ske,"AURORA-POSTGRESQL":n.Pnj,"AZURE-SYNAPSE":n.TuI,FILESYSTEM:n.xul,H2:n.xul,"METASTORE/KERBEROS/hdp03":n.xj_,MARIADB:n.V4s,MDM:n.pB7,MSSQL:n.AW2,MYSQL:n.Im0,ORACLE:n.Yv4,POSTGRESQL:n.Pnj,REDSHIFT:n.jpb,RDM:n.SqO,TERADATA:n.Kpj};var o=a(5013);var c=a(80880);var d=a(68591);var u=a(81012);var p=a(73734);const h=u.ZP.span`
  ${e=>e.theme.margin.right("S")}
`;const m=u.ZP.span`
  ${e=>e.lighter&&u.iv`
      color: ${e=>e.theme.palette.display.base};
      svg {
        color: ${e=>e.theme.palette.display[3]};
      }
    `};
`;const v=(0,u.ZP)(p._)`
  color: inherit;
`;const g=e=>({routeName:s.N.entity(e._.metadata.property.entity.name).detail("overview"),params:{gid:e._gid}});const y=({connection:e,lighterAppereance:t})=>{var a;const{Icon:r,label:s,link:o}=e?{Icon:l[e.executorType],label:e.name,link:g(e)}:{Icon:n.cHR,label:i18n({id:"catalog.catalogItemOriginTableCell.manuallyCreated",defaults:"manually created"}),link:undefined};const c=i.createElement(i.Fragment,null,r&&i.createElement(h,null,i.createElement(r,null)),i.createElement(d.gQ,{inKey:`${e===null||e===void 0?void 0:(a=e._.metadata.entity)===null||a===void 0?void 0:a.name}_name_${e===null||e===void 0?void 0:e._gid}`},s));return i.createElement(m,{lighter:t},o?i.createElement(v,{to:o,onClick:e=>e.stopPropagation(),onMouseUp:e=>e.stopPropagation()},c):c)};class CatalogItemOriginTableCell extends((0,r.Bq)({},{cellData:r.T.entityVersion({name:r.T.str(),executorType:r.T.str()},undefined)})){render(){const e=this.props.cellData;return i.createElement(y,{connection:e,lighterAppereance:true})}}class CatalogItemOriginView extends((0,r.Bq)({},{detailController:r.T.instanceOf(o.F)})){render(){const e=this.props.detailController.activeVersion;return i.createElement(c.Md,{"data-testid":"origin"},i.createElement(c.VR,null,i18n({id:"catalog.catalogItemOriginView.label",defaults:"Origin"})),i.createElement(c.OI,null,i.createElement(y,{connection:e})))}}},64749:(e,t,a)=>{"use strict";a.r(t);a.d(t,{CatalogItemTermsTableCell:()=>C});var i=a(33948);var n=a(70655);var r=a(22188);var s=a(29323);var l=a(67294);var o=a(27295);var c=a(96709);var d=a(22558);var u=a(77544);var p=a(36473);var h=a(85186);var m=a(96033);var v=a(3997);var g=a(80828);var y=a(76851);var f=a(50516);var b=a(77924);var E=a(81012);const w=E.ZP.span`
  color: ${e=>e.theme.palette.display[3]};
`;let C=class CatalogItemTermsTableCell extends((0,o.Bq)({maxWidth:o.T.number(300)},{cellData:o.T.any()})){constructor(){super(...arguments);this.terms=this.getTermEntities(this.props.cellData);this.fetchMoreTerms=async()=>{await this.props.cellData._.ensureItems({startIndex:this.props.cellData.length,size:10});this.terms=this.getTermEntities(this.props.cellData)}}render(){if(this.terms.length===0){return l.createElement(w,null,i18n({id:"catalog.catalogItemTerms.tableCell.empty",defaults:"no terms assigned yet"}))}return l.createElement(f.z,{isTableCell:true,termNodes:this.terms.map((e=>({term:e,node:l.createElement(b.O,{term:e})}))),totalCount:this.props.cellData._.totalCount,onLoadMore:this.fetchMoreTerms,maxWidth:this.props.maxWidth})}getTermEntities(e){const t=this.metadataManager.getEntityMetadataByName("term");(0,g.h)(t!=null,`Metadata of the 'term' entity not found.`);return e.map((({_gid:e,term_name:a,term_path:i,term_type:n})=>{const r=(0,p.ld)({metadataManager:this.metadataManager,store:this.entityManager.store,vars:{},response:new c.D({data:{gid:e,type:n,nodePath:i,draftVersion:{name:a,_displayName:a}}},{}),entityRequirements:{entityVersions:[{versionSelector:{kind:u.XH.Draft},properties:(0,m.I)(t,[{pattern:"./name"}]),extensions:[]}],extensions:[]},queryPath:new h.pG});return r.entity.versions.draft}))}};(0,n.gn)([(0,y.Q)((()=>v.d))],C.prototype,"metadataManager",void 0);(0,n.gn)([(0,y.Q)((()=>d.v))],C.prototype,"entityManager",void 0);(0,n.gn)([r.LO],C.prototype,"terms",void 0);(0,n.gn)([r.aD],C.prototype,"fetchMoreTerms",void 0);C=(0,n.gn)([s.Pi],C)},59473:(e,t,a)=>{"use strict";a.r(t);a.d(t,{CatalogItemTypeTableCell:()=>d});var i=a(70655);var n=a(29323);var r=a(67294);var s=a(27295);var l=a(39127);var o=a(81012);const c=(0,o.ZP)(l.h)`
  display: inline;
  color: ${e=>e.theme.palette.display[3]};
`;let d=class CatalogItemTypeTableCell extends((0,s.Bq)({},{rowData:s.T.entityVersion({partitions:s.T.str(undefined)})})){render(){const{rowData:e}=this.props;return r.createElement(c,{catalogItem:e,showTooltip:true})}};d=(0,i.gn)([n.Pi],d)},82544:(e,t,a)=>{"use strict";a.r(t);a.d(t,{CatalogItemsSearchResultsPage:()=>H});var i=a(33948);var n=a(86359);var r=a(70655);var s=a(29323);var l=a(67294);var o=a(73091);var c=a(27295);var d=a(22188);var u=a(94975);var p=a(76851);var h=a(22558);var m=a(3997);var v=a(58039);var g=a(82142);var y=a(87625);var f=a(91716);var b=a(90818);var E=a(1121);var w=a(62414);var C=a(2269);var S=a(39703);var I=a(71710);var x=a(80828);var T=a(55899);var P=a(37849);var N=a(97325);class ActionConfig{constructor(e,t){this.ctx=e;this.listing=t}get primaryAction(){var e,t;return(e=this.actionRegistryService.createActionWithConfig(this.actionConfig.primaryAction,this.listing,(t=this.ctx)!==null&&t!==void 0?t:{}))!==null&&e!==void 0?e:undefined}get actionConfig(){return this.widgetConfigService.get(T.d,this.listing.entityMetadata)}get secondaryAction(){var e,t;return(e=this.actionRegistryService.createActionWithConfig(this.actionConfig.secondaryAction,this.listing,(t=this.ctx)!==null&&t!==void 0?t:{}))!==null&&e!==void 0?e:undefined}get actions(){var e,t;return this.actionRegistryService.createActionWithConfig((e=this.actionConfig.actions)!==null&&e!==void 0?e:[],this.listing,(t=this.ctx)!==null&&t!==void 0?t:{})}}(0,r.gn)([(0,p.Q)((()=>P.c))],ActionConfig.prototype,"widgetConfigService",void 0);(0,r.gn)([(0,p.Q)((()=>N._f))],ActionConfig.prototype,"actionRegistryService",void 0);var k=a(6906);var D;(function(e){e["Elastic"]="elastic";e["AQL"]="aql";e["Query"]="query"})(D||(D={}));class CatalogSearchCompoundListingView{constructor(e,t){var a;const i=this.mm.getEntityMetadataByName("catalogItem");(0,x.h)(i,`Unable to find entity catalogItem`);this.entityMetadata=i;this.elasticListing=this.em.createSearchListing(this.entityMetadata);this.aqlListing=this.em.createMultiParentListing(this.entityMetadata,{fetchRules:t});this.defaultListing=this.em.createMultiParentListing(this.entityMetadata,{fetchRules:t});this.elasticListingView=this.createListingView(this.elasticListing,e);this.aqlListingView=this.createListingView(this.aqlListing,e);this.defaultListingView=this.createListingView(this.defaultListing,e);this.aqlLogListingEvents=new k.L(this.aqlListing);this.elasticLogListingEvents=new k.L(this.elasticListing);this.defaultLogListingEvents=new k.L(this.defaultListing);this.activeListingView=this.aqlListingView;if(((a=this.initialFilter)===null||a===void 0?void 0:a.type)===w.iG.AQL){this.activeListingView=this.aqlListingView}}get facets(){return this.elasticListing.facets}get hitReasons(){return this.elasticListing.hitReasons}get sortableFields(){return this.elasticListing.sortableFields}get activeListingViewType(){const e=[[this.defaultListingView,D.Query],[this.elasticListingView,D.Elastic],[this.aqlListingView,D.AQL]];return e.find((([e])=>e===this.activeListingView))[1]}setActiveListing(e){switch(e){case w.iG.Query:{this.activeListingView=this.defaultListingView;break}case w.iG.AQL:{this.activeListingView=this.aqlListingView;break}case w.iG.FulltextWithFilter:{this.activeListingView=this.elasticListingView;break}}}get activeLogListingEvents(){switch(this.activeListingViewType){case D.Elastic:return this.elasticLogListingEvents;case D.AQL:return this.aqlLogListingEvents;default:return this.defaultLogListingEvents}}createListingView(e,t){return new E._(e,new S.n6(new I.w(t,(0,S.mg)(e.query))))}get initialFilter(){var e,t;return(e=(t=this.activeListingView)===null||t===void 0?void 0:t.request.getUserFilter())!==null&&e!==void 0?e:undefined}get requiredProperties(){return this.aqlListing.query.getProperties()}getActionConfig(e){return new ActionConfig(e,this.aqlListing)}}(0,r.gn)([(0,p.Q)((()=>h.v))],CatalogSearchCompoundListingView.prototype,"em",void 0);(0,r.gn)([(0,p.Q)((()=>m.d))],CatalogSearchCompoundListingView.prototype,"mm",void 0);(0,r.gn)([(0,p.Q)((()=>y.g))],CatalogSearchCompoundListingView.prototype,"app",void 0);(0,r.gn)([d.LO],CatalogSearchCompoundListingView.prototype,"entityMetadata",void 0);(0,r.gn)([d.LO],CatalogSearchCompoundListingView.prototype,"elasticListing",void 0);(0,r.gn)([d.LO],CatalogSearchCompoundListingView.prototype,"elasticListingView",void 0);(0,r.gn)([d.LO],CatalogSearchCompoundListingView.prototype,"elasticLogListingEvents",void 0);(0,r.gn)([d.LO],CatalogSearchCompoundListingView.prototype,"aqlListing",void 0);(0,r.gn)([d.LO],CatalogSearchCompoundListingView.prototype,"aqlListingView",void 0);(0,r.gn)([d.LO],CatalogSearchCompoundListingView.prototype,"aqlLogListingEvents",void 0);(0,r.gn)([d.LO],CatalogSearchCompoundListingView.prototype,"defaultListing",void 0);(0,r.gn)([d.LO],CatalogSearchCompoundListingView.prototype,"defaultListingView",void 0);(0,r.gn)([d.LO],CatalogSearchCompoundListingView.prototype,"defaultLogListingEvents",void 0);(0,r.gn)([d.LO],CatalogSearchCompoundListingView.prototype,"activeListingView",void 0);(0,r.gn)([d.Fl],CatalogSearchCompoundListingView.prototype,"facets",null);(0,r.gn)([d.Fl],CatalogSearchCompoundListingView.prototype,"hitReasons",null);(0,r.gn)([d.Fl],CatalogSearchCompoundListingView.prototype,"sortableFields",null);(0,r.gn)([d.Fl],CatalogSearchCompoundListingView.prototype,"activeListingViewType",null);(0,r.gn)([d.aD],CatalogSearchCompoundListingView.prototype,"setActiveListing",null);(0,r.gn)([d.Fl],CatalogSearchCompoundListingView.prototype,"activeLogListingEvents",null);(0,r.gn)([d.Fl],CatalogSearchCompoundListingView.prototype,"initialFilter",null);(0,r.gn)([d.Fl],CatalogSearchCompoundListingView.prototype,"requiredProperties",null);var L=a(10446);var M=a(71880);var V=a(6642);function $(e,t,a=true,i=[]){const n=(0,l.useRef)();(0,l.useEffect)((()=>{n.current=e;if(a){e()}}),[e,...i]);(0,l.useEffect)((()=>{const e=setInterval((()=>{var e;return(e=n.current)===null||e===void 0?void 0:e.call(n)}),t);return()=>clearInterval(e)}),[t,...i])}var A=a(51979);var F=a.n(A);const R="UP";function _(){const e=(0,V.G)(g.l);const[t,a]=(0,l.useState)(undefined);$((()=>{e.execute({document:F()}).then((e=>a(e.data._searchStatus.status))).catch((()=>a("UNREACHABLE")))}),10*1e3);return t}function O(e){const t=_();const[a,i]=(0,l.useState)(undefined);(0,l.useEffect)((()=>{if(!a||a===R){i(t)}}),[t,a]);if(!a){return null}else if(a===R){return l.createElement(l.Fragment,null,e.children)}else{return l.createElement(l.Fragment,null,e.fallback(t===R,(()=>i(undefined))))}}var B=a(80880);var Z=a(33031);var q=a(8599);var Q=a(70148);class CatalogSearchCompoundLogListingEvents{constructor(e){this.view=e}logFilter(){this.view.activeLogListingEvents.logFilter()}logItemSelect(e){this.view.activeLogListingEvents.logItemSelect(e)}}const U={actionContext:c.T.number(u.f.None),screen:c.T.instanceOf(L.q),children:c.T.children(true,{listingView:c.T.instanceOf(E._),enableSorting:c.T.bool(undefined),enableFilter:c.T.bool(false),hitReasons:c.T.dict(c.T.list(c.T.obj(Q.Gy)),undefined),sortableFields:c.T.any(undefined)}),screenTitle:c.T.str(undefined)};let H=class CatalogItemsSearchResultsPage extends((0,c.Bq)(U,{},(({ctx:e,childCtx:t})=>({ctx:e.variables,view:t.variables.view,logListingEvents:t.variables.logListingEvents})),(({props:e,ctx:t})=>{const a=new CatalogSearchCompoundListingView(e.screen,q.kY);const i=new CatalogSearchCompoundLogListingEvents(a);return{...t.variables,view:a,logListingEvents:i,entityMetadata:a.entityMetadata,requiredProperties:a.requiredProperties}}))){constructor(){super(...arguments);this.searchResultsVisible=false;this.handleSubmit=async e=>{var t,a,i,n;this.props.view.setActiveListing(e.type);(t=this.selectionManager.activeSelection)===null||t===void 0?void 0:t.clear();(a=this.props.view.activeListingView)===null||a===void 0?void 0:a.request.setUserFilter(e);(i=this.props.view.activeListingView)===null||i===void 0?void 0:i.ensureView();(n=this.props.logListingEvents)===null||n===void 0?void 0:n.logFilter()}}get actionConfig(){return this.props.view.getActionConfig(this.props.ctx)}render(){return l.createElement(M._,null,l.createElement(f.h,{isViewOnlyMode:false,title:this.props.screenTitle},l.createElement(b.k,{primaryAction:this.actionConfig.primaryAction,actions:this.actionConfig.actions,secondaryAction:this.actionConfig.secondaryAction})),l.createElement(o.T3,null,l.createElement(O,{fallback:(e,t)=>l.createElement(l.Fragment,null,l.createElement(B.jL,{type:e?B.$.Info:B.$.Danger,title:e?i18n({id:"elasticIsBackUp.banner.title",defaults:"Smart search is back up"}):i18n({id:"elasticIsExperiencingProblems.banner.title",defaults:"Smart search is experiencing problems"}),Icon:e?Z.aUG:Z.Ucq,actions:e?[{label:"Turn on Fulltext search",onClick:t}]:[]},l.createElement(B.b5,null,e?l.createElement(n.Trans,{id:"elasticIsBackUp.banner.content",defaults:"Smart search is back up, click the button to enable it."}):l.createElement(n.Trans,{id:"elasticIsExperiencingProblems.banner.content",defaults:"There are issues which negatively impact search performance, relevancy, and usage of filters. Howewer, <0>you can still use it</0>.",components:[l.createElement("strong",null)]}))),l.createElement(o.yd,null,this.props.view.activeListingView&&this.props.children({enableFilter:true,listingView:this.props.view.activeListingView,enableSorting:this.props.view.activeListingViewType===D.AQL,hitReasons:{},sortableFields:undefined})))},l.createElement(o.Gh,{onSearch:this.handleSubmit,facets:this.props.view.facets,initialFilter:this.props.view.initialFilter,autoSubmit:true,nodeName:"catalogItem",onLoad:()=>{this.props.view.setActiveListing(w.iG.FulltextWithFilter);this.props.view.activeListingView.ensureView()}}),l.createElement(l.Fragment,null,this.props.view.activeListingView&&this.props.children({enableFilter:false,listingView:this.props.view.activeListingView,enableSorting:true,hitReasons:this.props.view.hitReasons,sortableFields:this.props.view.sortableFields})))),l.createElement(v.V,null))}};(0,r.gn)([d.LO],H.prototype,"searchResultsVisible",void 0);(0,r.gn)([(0,p.Q)((()=>h.v))],H.prototype,"entityManager",void 0);(0,r.gn)([(0,p.Q)((()=>C.Z))],H.prototype,"selectionManager",void 0);(0,r.gn)([(0,p.Q)((()=>m.d))],H.prototype,"metadataManager",void 0);(0,r.gn)([(0,p.Q)((()=>y.g))],H.prototype,"app",void 0);(0,r.gn)([d.Fl],H.prototype,"actionConfig",null);(0,r.gn)([(0,p.Q)((()=>g.l))],H.prototype,"apiClient",void 0);(0,r.gn)([d.aD],H.prototype,"handleSubmit",void 0);H=(0,r.gn)([s.Pi],H)},73091:(e,t,a)=>{"use strict";a.d(t,{yd:()=>at,T3:()=>tt,Gh:()=>et});var i=a(81012);var n=a(86359);var r=a(70655);var s=a(67294);var l=a(80880);var o=a(29323);var c=a(33031);const d=3;const u=60;const p=i.ZP.div`
  position: relative;

  box-sizing: border-box;
  padding: ${d}px ${e=>e.theme.symbol.spacing.M} ${d}px ${u+16}px;
  min-height: 56px;

  border: ${e=>e.theme.border.separate};
  border-radius: 4px;

  background: ${e=>e.theme.palette.tertiary.base};
`;const h=i.ZP.div`
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;

  width: ${u}px;
`;const m=i.ZP.button`
  display: flex;
  align-items: center;
  justify-content: space-between;

  width: 100%;
  height: 54px;
  ${e=>e.theme.padding.left("M")};

  color: ${e=>e.theme.palette.display[3]};

  cursor: pointer;

  ${l.$c};

  :hover,
  :focus {
    color: ${e=>e.theme.palette.display.base};
  }
`;const v=i.ZP.div`
  width: 100%;
  height: 100%;
  overflow: auto;

  & > * {
    width: 100%;
    height: 100%;
    padding: 0;

    line-height: 48px;
    min-height: 48px;

    border: none;
  }
`;const g=i.ZP.div`
  display: flex;
  align-items: center;
`;const y=(0,i.ZP)(l.hU)`
  color: ${e=>e.theme.palette.display[3]};
  ${e=>e.theme.margin("XS")};
  ${e=>!e.visible&&`visibility: hidden`};
`;const f=({view:e,className:t})=>{const a=()=>{e.activeSearchBar.clearSearchbar()};const i=t=>{e.setActiveSearchBar(t)};return s.createElement(p,{className:t},s.createElement(h,null,s.createElement(l.Qb,{items:e.searchBarPopupItems,selectedValues:[e.activeSearchBar.filterType],stretchToContent:true,onSelect:i},s.createElement(m,null,c.iQl[e.activeSearchBar.iconName],s.createElement(c.BDo,null)))),s.createElement(g,null,s.createElement(v,null,s.createElement(e.searchBarRenderer,null)),s.createElement(y,{onClick:a,visible:!e.activeSearchBar.isSearchbarEmpty(),"data-testid":"clearSearchInput"},s.createElement(c.ddr,null))))};const b=(0,o.Pi)(f);var E=a(47354);const w=i.ZP.div`
  min-width: 400px;
  max-width: 800px;
  display: flex;
  flex-wrap: nowrap;
  align-items: center;
  flex: 1 1 auto;
  ${e=>e.theme.margin.bottom("M")};
`;const C=i.ZP.div`
  width: 100%;
  ${e=>e.theme.margin.bottom("S")};
`;const S=(0,i.ZP)(b)`
  flex: 1 1 auto;
  overflow: auto;
  &:not(:last-child) {
    ${e=>e.theme.margin.right("M")};
  }
`;const I=(0,i.ZP)(l.zx).attrs({children:i18n({id:"defaultSearchBar.submit",defaults:"Search"}),form:"catalog-search-input",primary:true})``;const x=(0,i.ZP)(l.rU)`
  ${e=>e.theme.font.body()};
  align-items: center;
  display: flex;
  flex-shrink: 0;
`;const T=(0,i.ZP)(c.TqL)`
  ${e=>e.theme.margin.left("S")};
`;const P=({children:e})=>s.createElement(E.ww.div,{exit:{y:"-100%",opacity:0,height:0},initial:{y:"-100%",opacity:0,height:0},animate:{y:0,height:"auto",opacity:1},transition:{type:"spring",stiffness:900,damping:90,restDelta:.5,restSpeed:10},"data-testid":"bulkActionPanel"},e);var N=a(22188);var k=a(76851);var D=a(82142);var L=a(80828);class SearchInputView{constructor(e,t,a){this.searchBarNodes=e;this.onSubmit=t;(0,L.h)(e.length,"SearchInputView: Provided search bar node array is empty");this.activeSearchBar=this.getFilterByType(a.type);this.searchBarNodes.forEach((e=>e.initialize(this,a.type===e.filterType?a:null)))}get filter(){return this.activeSearchBar.filter}submit(){const e=this.activeSearchBar.submit();if(e){this.onSubmit(e)}}get searchBarPopupItems(){return this.searchBarNodes.map((e=>({value:e.filterType,label:e.displayName,icon:c.iQl[e.iconName]})))}getFilterByType(e){const t=this.searchBarNodes.findIndex((t=>t.filterType===e));if(t===-1){return this.searchBarNodes[0]}return this.searchBarNodes[t]}setActiveSearchBar(e){this.activeSearchBar=this.getFilterByType(e);this.onSubmit(this.filter)}setFilter(e){if(e.type===this.activeSearchBar.filterType){this.activeSearchBar.setFilter(e)}else{this.activeSearchBar=this.getFilterByType(e.type);this.activeSearchBar.setFilter(e)}}get searchBarRenderer(){return this.activeSearchBar.getSearchBarRenderer()}}(0,r.gn)([(0,k.Q)((()=>D.l))],SearchInputView.prototype,"apiClient",void 0);(0,r.gn)([N.LO],SearchInputView.prototype,"activeSearchBar",void 0);(0,r.gn)([N.Fl],SearchInputView.prototype,"filter",null);(0,r.gn)([N.aD.bound],SearchInputView.prototype,"submit",null);(0,r.gn)([N.Fl],SearchInputView.prototype,"searchBarPopupItems",null);(0,r.gn)([N.aD.bound],SearchInputView.prototype,"setActiveSearchBar",null);(0,r.gn)([N.aD],SearchInputView.prototype,"setFilter",null);(0,r.gn)([N.Fl],SearchInputView.prototype,"searchBarRenderer",null);var M=a(33948);class AbstractSearchBarNode{initialize(e,t){this.view=e;this.setFilter(t)}}(0,r.gn)([N.LO],AbstractSearchBarNode.prototype,"view",void 0);var V=a(39992);var $=a(6625);var A=a(15458);class CatalogAQLInput extends s.Component{constructor(){super(...arguments);this.aqlMarker=(e,t)=>{const{tokens:a,errors:i}=(0,V.M)(e);for(const e of[...a,...i]){t(e.start,e.stop+1,["aql-token",(0,A.S)(e.type)])}for(let a=0;a<e.length;a++){const i=e[a];if(["{","}","(",")"].includes(i)){t(a,a+1,["aql-token","aql-bracket"])}}}}render(){const{value:e,className:t,placeholder:a,testId:i}=this.props;return s.createElement($.M,{autofocus:true,testId:i,className:t,placeholder:a,defaultValue:e,marker:this.aqlMarker,onUpdate:this.props.onUpdate,onEnterKeyDown:this.props.onSubmit})}}var F=a(22259);var R=a(62414);function _(e=10){return Math.floor(Math.random()*e)}const O=[i18n({id:"catalogSearch.aql.placeholder.1",defaults:"e.g. attributes.count() > 10"}),i18n({id:"catalogSearch.aql.placeholder.2",defaults:"e.g. $parent.name IN ('sales', 'person')"}),i18n({id:"catalogSearch.aql.placeholder.3",defaults:"e.g. name like 'customer' and numberOfRecords > 10000"}),i18n({id:"catalogSearch.aql.placeholder.4",defaults:"e.g. attributes.some(dataType is 'INTEGER')"}),i18n({id:"catalogSearch.aql.placeholder.5",defaults:"e.g. $parent '{ name like \"sales\" & catalogItems.count() > 1000}'"})];const B=5e3;const Z={type:R.iG.AQL,value:""};class AQLSearchBarNode extends AbstractSearchBarNode{constructor(e){super();this.filterType=R.iG.AQL;this.displayName=i18n({id:"catalogSearch.aql.displayName",defaults:"Advanced filtering with AQL"});this.iconName="typeObject";this.key="aql";this.filter=Z;this.queryValue="";this.aqlInputKey=true;this.onParseError=e!==null&&e!==void 0?e:()=>this.flashMessageManager.simpleMessage("danger","Incorrect Format","Incorrect filter query format")}setFilter(e){this.filter=e!==null&&e!==void 0?e:Z}clearSearchbar(){var e;this.queryValue="";(e=this.view)===null||e===void 0?void 0:e.submit();this.aqlInputKey=!this.aqlInputKey}clearFilter(){this.filter=Z}isSearchbarEmpty(){return!this.filter.value||this.filter.value==""}initialize(e,t){var a;super.initialize(e,t);this.queryValue=(a=t===null||t===void 0?void 0:t.value)!==null&&a!==void 0?a:""}getSearchBarRenderer(){return(0,o.Pi)((({testId:e})=>{const[t,a]=(0,s.useState)(O[_(O.length)]);(0,s.useEffect)((()=>{const e=setInterval((()=>{const e=O.filter((e=>e!==t));a(e[_(e.length)])}),B);return()=>{clearInterval(e)}}),[t]);return s.createElement(CatalogAQLInput,{key:Number(this.aqlInputKey),placeholder:t,value:this.queryValue,testId:e,onSubmit:()=>{var e;return(e=this.view)===null||e===void 0?void 0:e.submit()},onUpdate:e=>this.handleValueUpdate(e)})}))}handleValueUpdate(e){this.queryValue=e}submit(){const e=this.queryValue;const{errors:t}=(0,V.M)(e);const a=e.endsWith("!");if(!t.length||a){this.filter.value=this.queryValue;return this.filter}else{var i;(i=this.onParseError)===null||i===void 0?void 0:i.call(this)}return null}getDefaultFilter(){return Z}}(0,r.gn)([(0,k.Q)((()=>F.HF))],AQLSearchBarNode.prototype,"flashMessageManager",void 0);(0,r.gn)([N.LO],AQLSearchBarNode.prototype,"filter",void 0);(0,r.gn)([N.LO],AQLSearchBarNode.prototype,"queryValue",void 0);(0,r.gn)([N.aD],AQLSearchBarNode.prototype,"setFilter",null);(0,r.gn)([N.LO],AQLSearchBarNode.prototype,"aqlInputKey",void 0);(0,r.gn)([N.aD],AQLSearchBarNode.prototype,"clearSearchbar",null);(0,r.gn)([N.aD],AQLSearchBarNode.prototype,"clearFilter",null);(0,r.gn)([N.aD.bound],AQLSearchBarNode.prototype,"handleValueUpdate",null);const q=i.iv`
  ${e=>e.theme.font.regular()};
  white-space: pre;
`;const Q=i.ZP.div`
  width: 100%;
  display: flex;
  flex-wrap: wrap;

  position: relative;

  box-sizing: border-box;
  min-height: 48px;

  background: ${e=>e.theme.palette.tertiary.base};
`;const U=(0,i.ZP)(l.II)`
  min-width: 60px;
  margin: 4px;
  padding: 0;

  &&&:not([disabled]):focus-within {
    box-shadow: none;
  }

  background: transparent;
  border: none;

  outline: none;

  ${q};
`;let H=class FulltextInput extends s.Component{constructor(){super(...arguments);this.handleChange=e=>{this.props.onUpdate(e.target.value)};this.handleKeyPress=e=>{if(e.key==="Enter"){e.preventDefault();this.props.onSubmit();return}}}render(){const{className:e,testId:t,value:a,placeholder:i,inputRef:n}=this.props;return s.createElement(Q,{className:e,"data-testid":t},s.createElement(U,{ref:n,placeholder:i,value:a,autoFocus:true,testId:"mainInput",onChange:this.handleChange,onKeyPress:this.handleKeyPress}))}};(0,r.gn)([N.aD],H.prototype,"handleChange",void 0);(0,r.gn)([N.aD],H.prototype,"handleKeyPress",void 0);H=(0,r.gn)([o.Pi],H);const K={type:R.iG.FulltextWithFilter,value:{query:"",filter:{}}};class FulltextSearchBarNode extends AbstractSearchBarNode{constructor(){super(...arguments);this.filterType=R.iG.FulltextWithFilter;this.displayName=i18n({id:"catalogSearch.fulltext.displayName",defaults:"Fulltext search"});this.iconName="search";this.key="fulltext";this.inputRef=s.createRef();this.filter=K;this.queryValue=""}setFilter(e){this.filter=e!==null&&e!==void 0?e:K}initialize(e,t){var a;super.initialize(e,t);this.queryValue=(a=t===null||t===void 0?void 0:t.value.query)!==null&&a!==void 0?a:""}clearSearchbar(){var e,t;this.queryValue="";(e=this.view)===null||e===void 0?void 0:e.submit();(t=this.inputRef.current)===null||t===void 0?void 0:t.focus()}clearFilter(){this.filter=K}isSearchbarEmpty(){return!this.filter.value||this.filter.value.query==""}getSearchBarRenderer(){return(0,o.Pi)((({testId:e})=>s.createElement(H,{inputRef:this.inputRef,placeholder:i18n({id:"catalogSearch.fulltext.placeholder",defaults:"Search for catalog items"}),value:this.queryValue,testId:e,onSubmit:()=>{var e;return(e=this.view)===null||e===void 0?void 0:e.submit()},onUpdate:e=>this.handleValueUpdate(e)})))}handleValueUpdate(e){this.queryValue=e}submit(){this.filter.value.query=this.queryValue;return this.filter}getDefaultFilter(){return K}}(0,r.gn)([N.LO],FulltextSearchBarNode.prototype,"filter",void 0);(0,r.gn)([N.LO],FulltextSearchBarNode.prototype,"queryValue",void 0);(0,r.gn)([N.aD],FulltextSearchBarNode.prototype,"setFilter",null);(0,r.gn)([N.aD],FulltextSearchBarNode.prototype,"clearSearchbar",null);(0,r.gn)([N.aD],FulltextSearchBarNode.prototype,"clearFilter",null);(0,r.gn)([N.aD.bound],FulltextSearchBarNode.prototype,"handleValueUpdate",null);(0,r.gn)([N.aD.bound],FulltextSearchBarNode.prototype,"submit",null);const G=i.ZP.div`
  display: flex;
  flex-wrap: wrap;
  & > * {
    ${e=>e.theme.margin.bottom("S")};
  }

  & > :not(:last-child) {
    ${e=>e.theme.margin.right("S")};
  }
`;const W=i.ZP.div`
  display: flex;
  justify-content: space-between;
`;const z=(0,i.ZP)(l.zx).attrs({icon:"cancelRounded"})`
  ${e=>e.theme.margin.left("M")};
  height: 36px;
`;var j=a(50361);var X=a.n(j);var Y=a(41609);var J=a.n(Y);let ee=class FacetFilter extends s.Component{constructor(){super(...arguments);this.handleChange=(e,t)=>{const a=this.props.filter;if(a){const i=X()(a);i[e]=t;this.props.onChange(i)}};this.handleReset=()=>{this.props.onChange({})}}render(){const{facetFilterDefinitions:e,className:t,facets:a,filter:i,disabled:r}=this.props;return s.createElement(W,{className:t},s.createElement(G,null,e.map((e=>{var t;return s.createElement(e.renderer,{disabled:r,displayName:e.displayName,key:e.key,onChange:t=>this.handleChange(e.key,t),facets:a[e.key],value:i&&((t=i[e.key])===null||t===void 0?void 0:t.value)})}))),!J()(i)&&s.createElement(z,{onClick:this.handleReset},s.createElement(n.Trans,{id:"catalogSearch.filters.clear",defaults:"Clear filters"})))}};(0,r.gn)([N.aD],ee.prototype,"handleReset",void 0);ee=(0,r.gn)([o.Pi],ee);var te=a(46046);var ae=a(2227);const ie="entityPickerInput";const ne=(0,i.ZP)(te.z).attrs({inputClassName:ie})`
  min-width: 250px;

  .${ie} {
    // padding is the same as in the input from the PopupList
    // but that file cannot be imported from this file
    padding-left: ${e=>`calc(${e.theme.symbol.spacing.M} + ${e.theme.symbol.spacing.S} + 20px)`};
    border: none;
  }
`;const re=i.ZP.div`
  flex: 1;
  display: flex;
  justify-content: space-between;
  max-width: 300px;
  min-width: 180px;
  & :not(:last-child) {
    ${e=>e.theme.margin.right("S")};
  }
`;const se=i.ZP.div`
  ${(0,ae.LH)()}
`;var le=a(90601);var oe=a(52550);var ce=a(30869);var de=a(31486);var ue=a.n(de);var pe=a(16583);var he=a(33524);var me=a(18446);var ve=a.n(me);let ge=class KeywordFilter extends s.Component{constructor(){super(...arguments);this.selectedValues=[...this.oldValue];this.handleSearchChange=e=>{};this.handleSelect=e=>{if((0,le.m)(e)){this.selectedValues=[e];this.props.onChange({type:R.IG.Keyword,value:e});return}if(this.selectedValues.length===1&&(0,le.m)(this.selectedValues[0])){this.selectedValues=[e]}else{this.selectedValues.push(e)}this.props.onChange({type:R.IG.Keyword,value:this.selectedValues})};this.handleDeselect=e=>{this.selectedValues=this.selectedValues.filter((t=>t!==e));this.props.onChange({type:R.IG.Keyword,value:this.selectedValues})};this.handleReset=()=>{this.selectedValues=[];this.props.onChange({type:R.IG.Keyword,value:this.selectedValues})};this.mapFacetToRow=e=>this.props.mapItemToRow?this.props.mapItemToRow(e):{value:e.value,label:s.createElement(re,null,s.createElement(se,null,e.displayName),e.count&&s.createElement("div",null,ue()(e.count))),groupName:(0,le.m)(e.value)?"Options":"Values",searchableText:(0,le.m)(e.value)?undefined:e.displayName}}get oldValue(){const e=this.props.value;if((0,le.m)(e)){return[e]}return e!==null&&e!==void 0?e:[]}get facetByValueMap(){return Object.fromEntries(this.facets.map((e=>[e.value,e])))}getFacetByValue(e){return this.facetByValueMap[e]}componentDidUpdate(e){if(!ve()(e.value,this.props.value)){this.selectedValues=[...this.oldValue]}}get facets(){var e,t,a,i;const n={value:le.N.MissingValue,displayName:"Blank",count:(e=this.props.facets.additionalData)===null||e===void 0?void 0:(t=e.missing)===null||t===void 0?void 0:t.missingCount};const r={value:le.N.AnyValue,displayName:"Any",count:(a=this.props.facets.additionalData)===null||a===void 0?void 0:(i=a.missing)===null||i===void 0?void 0:i.hasValueCount};return this.props.facets.items.length===0&&this.selectedValues.length===0?[]:[n,r,...this.props.facets.items]}get items(){const e=[...this.facets];this.selectedValues.forEach((t=>{if(!e.find((e=>e.value===t))){e.splice(2,0,{value:t,displayName:t,count:0})}}));return e.map(this.mapFacetToRow)}render(){const{disabled:e,displayName:t}=this.props;return s.createElement(pe.GI,{popup:s.createElement(he.R,{onReset:this.handleReset,onSelect:this.handleSelect,onDeselect:this.handleDeselect,selectedValues:this.selectedValues,items:this.items,filterDisplayName:t}),placement:pe.Iw.bottomStart,disabled:e||this.items.length===0},s.createElement(oe.L,{active:this.oldValue.length>0,displayName:t,disabled:e||this.items.length===0},s.createElement(ce.y,{items:this.selectedValues.map((e=>{var t,a;return{displayName:(t=(a=this.getFacetByValue(e))===null||a===void 0?void 0:a.displayName)!==null&&t!==void 0?t:e}}))})))}};(0,r.gn)([N.Fl],ge.prototype,"oldValue",null);(0,r.gn)([N.Fl],ge.prototype,"facetByValueMap",null);(0,r.gn)([N.LO],ge.prototype,"selectedValues",void 0);(0,r.gn)([N.aD],ge.prototype,"componentDidUpdate",null);(0,r.gn)([N.aD],ge.prototype,"handleSelect",void 0);(0,r.gn)([N.aD],ge.prototype,"handleDeselect",void 0);(0,r.gn)([N.aD],ge.prototype,"handleReset",void 0);(0,r.gn)([N.Fl],ge.prototype,"facets",null);(0,r.gn)([N.Fl],ge.prototype,"items",null);ge=(0,r.gn)([o.Pi],ge);var ye=a(89963);function fe(e){if(e.nodePath&&e.nodePath.length){var t;return e.nodePath[0]+((t=e.referencedNodePath)===null||t===void 0?void 0:t[0])+e.propertyName}else{return JSON.stringify(e)}}function be(e){switch(e.facetType){case ye.Q.Keyword:return e.keywordValues.map((e=>({value:e.value,displayName:e.value,count:e.count})));case ye.Q.Numeric:return e.numericIntervals.map((({min:e,max:t})=>({value:{min:e!==null&&e!==void 0?e:null,max:t!==null&&t!==void 0?t:null}})));case ye.Q.Date:return e.dateIntervals.map((({min:e,max:t,displayName:a,count:i})=>({displayName:a,count:i,value:{min:xe(e),max:xe(t)}})));default:return[]}}function Ee(e){return e===ye.Q.Numeric?R.IG.Numeric:R.IG.Keyword}function we(e){if(e.missing!=null){return{type:e.valueType,value:e.missing?le.N.MissingValue:le.N.AnyValue}}if(e.valueType===R.IG.Keyword){var t;const a=e;return{type:e.valueType,value:(t=a.keywordValues)!==null&&t!==void 0?t:[]}}else if(e.valueType===R.IG.Numeric){var a,i,n,r;const t=e;return{type:e.valueType,value:{min:(a=(i=t.numericInterval)===null||i===void 0?void 0:i.min)!==null&&a!==void 0?a:null,max:(n=(r=t.numericInterval)===null||r===void 0?void 0:r.max)!==null&&n!==void 0?n:null,key:null}}}else if(e.valueType===R.IG.Date){var s,l,o,c;const t=e;return{type:e.valueType,value:{min:xe((s=t.dateInterval)===null||s===void 0?void 0:s.min),max:xe((l=t.dateInterval)===null||l===void 0?void 0:l.max),key:(o=(c=t.dateInterval)===null||c===void 0?void 0:c.key)!==null&&o!==void 0?o:null}}}}function Ce(e){var t,a;switch(e.type){case R.iG.Text:return{type:R.iG.FulltextWithFilter,value:{query:e.value,filter:{}}};case R.iG.AQL:case R.iG.Query:return e;case R.iG.FulltextWithFilter:return{type:R.iG.FulltextWithFilter,value:{query:e.value.query,filter:Object.fromEntries((t=(a=e.value.filter)===null||a===void 0?void 0:a.map((e=>[fe(e),we(e)])).filter((([e,t])=>e&&t)))!==null&&t!==void 0?t:[])}}}}function Se(e,t){const a={referencedNodePath:t.referencedNodePath,nodePath:t.nodePath,propertyName:t.propertyName,missing:(0,le.m)(e.value)?e.value===le.N.MissingValue:undefined,valueType:e.type};if((0,le.m)(e.value)){return{...a}}switch(e.type){case R.IG.Keyword:{if(!e.value.length){return}return{...a,keywordValues:e.value}}case R.IG.Numeric:{var i,n;if(e.value.min==null&&e.value.max==null){return}return{...a,numericInterval:{min:(i=e.value.min)!==null&&i!==void 0?i:undefined,max:(n=e.value.max)!==null&&n!==void 0?n:undefined}}}case R.IG.Date:{var r,s,l,o;if(e.value.min==null&&e.value.max==null){return}return{...a,dateInterval:{min:(r=(s=e.value.min)===null||s===void 0?void 0:s.toISOString())!==null&&r!==void 0?r:undefined,max:(l=(o=e.value.max)===null||o===void 0?void 0:o.toISOString())!==null&&l!==void 0?l:undefined,key:e.value.key}}}}}function Ie(e,t){var a;switch(e.type){case R.iG.AQL:case R.iG.Query:return e;case R.iG.FulltextWithFilter:return{type:R.iG.FulltextWithFilter,value:{query:e.value.query,filter:Object.entries((a=e.value.filter)!==null&&a!==void 0?a:{}).map((([e,a])=>Se(a,t[e]))).filter((e=>e))}}}}function xe(e){return e?new Date(e):null}const Te=i.ZP.div`
  display: flex;
`;const Pe=i.ZP.div`
  flex: 1;
  display: flex;
  justify-content: space-between;
  width: 100%;
  & :not(:last-child) {
    ${e=>e.theme.margin.right("S")};
  }
`;const Ne=i.ZP.div`
  ${(0,ae.LH)()}
`;const ke=i.ZP.div`
  ${e=>e.theme.margin.top("S")};
  ${e=>e.theme.margin.bottom("S")};
`;var De=a(84901);var Le=a(28721);var Me=a(58280);function Ve({onSubmit:e,onReset:t,onChange:a,selectedValue:i,items:r,children:o}){const{closePopup:c}=(0,s.useContext)(pe.tH);const d=()=>{c();e()};const u=()=>{c();t()};return s.createElement(Me.J,null,s.createElement(l.aV,{multiselect:false,itemSize:l.Fz.S,disabled:false,items:r.map((e=>({item:e,id:Re(e.value),isSelected:ve()(e.value,i),label:e.label||e.value,onClick:()=>{if(ve()(e.value,i)){t();return}a(e.value);d()}})))}),o&&s.createElement(ke,null,o({onSubmit:d,onReset:u})),s.createElement(De.r,null),s.createElement(Le.k,null,o&&s.createElement(l.zx,{primary:true,onClick:d,"data-testid":"filterApply"},s.createElement(n.Trans,{id:"rangeFilter.apply",defaults:"Apply"})),s.createElement(l.zx,{disabled:ve()(i,{min:null,max:null}),onClick:u,"data-testid":"filterClear"},s.createElement(n.Trans,{id:"rangeFilter.clear",defaults:"Clear"}))))}const $e=(0,o.Pi)(Ve);const Ae=(e,t)=>typeof e==="object"&&typeof t==="object"&&(e===null||e===void 0?void 0:e.key)&&e.key===(t===null||t===void 0?void 0:t.key)||ve()(e,t);let Fe=class RangeFilter extends s.Component{constructor(){super(...arguments);this.selectedValue=X()(this.oldValue);this.handleSelect=e=>{if(Ae(this.selectedValue,e)){this.selectedValue={min:null,max:null,key:null}}else{this.selectedValue=e}this.handleSubmit()};this.handleRangeChange=e=>{this.selectedValue=e};this.handleSubmit=()=>{const{dataMin:e,dataMax:t,selectedValue:a}=this;if(!(0,le.m)(this.selectedValue)){const{min:i,max:n}=a;if(t!=null&&e!=null&&n===null&&i===null){this.selectedValue.min=e;this.selectedValue.max=t}if((i!==null&&i!==void 0?i:-Infinity)>(n!==null&&n!==void 0?n:Infinity)){throw new Error("The Min value must be smaller than the Max value")}}this.props.onChange(this.selectedValue)};this.handleReset=e=>{e===null||e===void 0?void 0:e();this.selectedValue={min:null,max:null,key:null};this.props.onChange(this.selectedValue)};this.mapFacetToRow=e=>this.props.mapItemToRow?this.props.mapItemToRow(e):{value:e.value,label:s.createElement(Pe,null,s.createElement(Ne,null,(0,le.m)(e.value)||e.displayName?e.displayName:e.value.min+" — "+e.value.max),e.count!=null&&s.createElement("div",null,ue()(e.count)))}}get oldValue(){var e;return(e=this.props.value)!==null&&e!==void 0?e:{min:null,max:null,key:null}}componentDidUpdate(e){if(!Ae(e.value,this.props.value)){this.selectedValue=X()(this.oldValue)}}get filterButtonContent(){const e=this.getFacetByValue(this.oldValue);if(this.props.mapValueToFilterButtonContent){const t=this.props.mapValueToFilterButtonContent(this.oldValue,e);return t?[t]:[]}if((0,le.m)(this.oldValue)||e!==null&&e!==void 0&&e.displayName){var t;return[{displayName:(t=e===null||e===void 0?void 0:e.displayName)!==null&&t!==void 0?t:e===null||e===void 0?void 0:e.value}]}const{min:a,max:i}=this.oldValue;if(a!=null&&i!=null){return[{displayName:`${a} — ${i}`}]}else if(a!=null){return[{displayName:`> ${a}`}]}else if(i!=null){return[{displayName:`< ${i}`}]}return[]}get dataMin(){var e,t,a;return(e=(t=this.props.facets)===null||t===void 0?void 0:(a=t.additionalData)===null||a===void 0?void 0:a.dataMin)!==null&&e!==void 0?e:undefined}get dataMax(){var e,t,a;return(e=(t=this.props.facets)===null||t===void 0?void 0:(a=t.additionalData)===null||a===void 0?void 0:a.dataMax)!==null&&e!==void 0?e:undefined}get _facetByValueMap(){return Object.fromEntries(this.facets.map((e=>[Re(e.value),e])))}getFacetByValue(e){return this._facetByValueMap[Re(e)]}get facets(){var e,t,a,i;return[{value:le.N.MissingValue,displayName:"Blank",count:(e=this.props.facets.additionalData)===null||e===void 0?void 0:(t=e.missing)===null||t===void 0?void 0:t.missingCount},{value:le.N.AnyValue,displayName:"Any",count:(a=this.props.facets.additionalData)===null||a===void 0?void 0:(i=a.missing)===null||i===void 0?void 0:i.hasValueCount},...this.props.facets.items]}get items(){var e;return(e=this.facets.map(this.mapFacetToRow))!==null&&e!==void 0?e:[]}render(){const{disabled:e,displayName:t,rangeSelectorComponent:a}=this.props;return s.createElement(pe.GI,{popup:s.createElement($e,{onSubmit:this.handleSubmit,onReset:this.handleReset,onChange:this.handleRangeChange,selectedValue:this.selectedValue,items:this.items},(({onSubmit:e,onReset:t})=>a&&s.createElement(a,{value:(0,le.m)(this.selectedValue)?{min:null,max:null,key:null}:this.selectedValue,onSubmit:e,onReset:t,onChange:this.handleRangeChange,dataMin:this.dataMin,dataMax:this.dataMax}))),placement:pe.Iw.bottomStart,disabled:e},s.createElement(oe.L,{key:t,displayName:t,active:this.filterButtonContent.length>0,disabled:e},s.createElement(ce.y,{items:this.filterButtonContent})))}};(0,r.gn)([N.Fl],Fe.prototype,"oldValue",null);(0,r.gn)([N.LO],Fe.prototype,"selectedValue",void 0);(0,r.gn)([N.aD],Fe.prototype,"componentDidUpdate",null);(0,r.gn)([N.aD],Fe.prototype,"handleSelect",void 0);(0,r.gn)([N.aD],Fe.prototype,"handleRangeChange",void 0);(0,r.gn)([N.aD],Fe.prototype,"handleSubmit",void 0);(0,r.gn)([N.aD],Fe.prototype,"handleReset",void 0);(0,r.gn)([N.Fl],Fe.prototype,"filterButtonContent",null);(0,r.gn)([N.Fl],Fe.prototype,"dataMin",null);(0,r.gn)([N.Fl],Fe.prototype,"dataMax",null);(0,r.gn)([N.Fl],Fe.prototype,"_facetByValueMap",null);(0,r.gn)([N.Fl],Fe.prototype,"facets",null);(0,r.gn)([N.Fl],Fe.prototype,"items",null);Fe=(0,r.gn)([o.Pi],Fe);function Re(e){return(0,le.m)(e)?e:e.key||String(e.min)+","+String(e.max)}const _e=i.ZP.div`
  display: inline-flex;
  justify-content: space-between;
  align-items: center;
  ${e=>e.theme.padding.left("M")};
  ${e=>e.theme.padding.right("M")};
  & :not(:last-child) {
    ${e=>e.theme.margin.right("M")}
  }
`;const Oe=i.ZP.div`
  width: 120px;
  color: ${e=>e.theme.palette.display[9]};
`;const Be=i.ZP.div`
  ${e=>e.theme.font.bodyMedium()};
  color: ${e=>e.theme.palette.display[3]};
  ${e=>e.theme.padding("XS")};
  ${e=>e.theme.padding.left(0)};
`;var Ze=a(43468);var qe;(function(e){e[e["Min"]=0]="Min";e[e["Max"]=1]="Max"})(qe||(qe={}));let Qe=class NumericRangeSelector extends s.Component{constructor(){super(...arguments);this.handleChange=e=>{const t={...this.props.value,...e};this.props.onChange(t)};this.UnitInputComponent=e=>{var t;const{dataMin:a,dataMax:i,value:{min:r,max:l}}=this.props;const o=t=>this.handleChange(e===qe.Min?{min:t}:{max:t});const c=e===qe.Min?a:i;const d=e===qe.Min?r:l;const u=e===qe.Min?"inputMin":"inputMax";return s.createElement(Oe,null,s.createElement(Be,null,e===qe.Min?s.createElement(n.Trans,{id:"numericRangeSelector.min",defaults:"Min"}):s.createElement(n.Trans,{id:"numericRangeSelector.max",defaults:"Max"})),s.createElement(Ze.O,{type:"number",required:false,placeholder:c!=null?String(c):undefined,units:this.props.units,value:(t=d===null||d===void 0?void 0:d.toString())!==null&&t!==void 0?t:"",onChange:e=>o(e.target.value?Number(e.target.value):null),testId:u}))};this.handleKeyDown=e=>{if(e.key==="Enter"){var t,a;(t=(a=this.props).onSubmit)===null||t===void 0?void 0:t.call(a)}}}render(){return s.createElement(_e,{onKeyDown:this.handleKeyDown},this.UnitInputComponent(qe.Min),this.UnitInputComponent(qe.Max))}};Qe=(0,r.gn)([o.Pi],Qe);const Ue=({displayName:e,value:t,facets:a,onChange:i,disabled:n})=>{const r=e=>i({type:R.IG.Numeric,value:e});return s.createElement(Fe,{displayName:e,value:t,facets:a,disabled:n,onChange:r,rangeSelectorComponent:Qe})};const He=(0,o.Pi)(Ue);var Ke=a(95639);const Ge=({displayName:e,value:t,facets:a,onChange:i,disabled:n})=>{const r=e=>i({type:R.IG.Date,value:e});const l={facetDateRange_last24Hours:i18n({id:"catalog.search.facets.facetDateRange_last24Hours",defaults:"Last 24 hours"}),facetDateRange_last7Days:i18n({id:"catalog.search.facets.facetDateRange_last7Days",defaults:"Last 7 days"}),facetDateRange_last14Days:i18n({id:"catalog.search.facets.facetDateRange_last14Days",defaults:"Last 14 days"}),facetDateRange_last30Days:i18n({id:"catalog.search.facets.facetDateRange_last30Days",defaults:"Last 30 days"})};const o=e=>e&&e in l?l[e]:e;const c=(e,t)=>{if((0,le.m)(e)||t!==null&&t!==void 0&&t.displayName){return{displayName:t!==null&&t!==void 0&&t.displayName?o(t.displayName):t===null||t===void 0?void 0:t.value}}const{min:a,max:i}=e;const n="MMM d, Y";const r=a!=null&&(0,Ke.default)(a,n);const s=i!=null&&(0,Ke.default)(i,n);if(a!=null&&i!=null){return{displayName:`${r} — ${s}`}}else if(a!=null){return{displayName:`> ${r}`}}else if(i!=null){return{displayName:`< ${s}`}}};const d={...a,items:a.items.map((({value:e,...t})=>{var a;return{...t,value:{...e,key:(a=t.displayName)!==null&&a!==void 0?a:null}}}))};return s.createElement(Fe,{displayName:e,value:t,facets:d,mapValueToFilterButtonContent:c,disabled:n,onChange:r,mapItemToRow:e=>({value:typeof e.value==="object"?{...e.value,key:e.displayName}:e.value,label:s.createElement(Pe,null,s.createElement(Ne,null,(0,le.m)(e.value)||e.displayName?e.displayName?o(e.displayName):e.displayName:e.value.min+" — "+e.value.max),e.count!=null&&s.createElement("div",null,ue()(e.count)))})})};const We=(0,o.Pi)(Ge);var ze=a(7139);var je=a(25108);const Xe={type:R.iG.Query,value:[]};class DefaultSearchBarNode extends AbstractSearchBarNode{constructor(){super(...arguments);this.filterType=R.iG.Query;this.displayName="Smart search";this.iconName="search";this.filter=Xe}submit(){return this.filter}setFilter(e){this.filter=e}isSearchbarEmpty(){return this.filter&&this.filter.value===[]}clearSearchbar(){this.filter=Xe;this.submit()}clearFilter(){this.filter=Xe}getSearchBarRenderer(){return()=>s.createElement(ze.s,{onParseError:je.error,placeholder:"Search",testId:"listingPageSearch",onSubmit:e=>{var t;this.setFilter(e);(t=this.view)===null||t===void 0?void 0:t.submit()},initialValue:this.filter})}getDefaultFilter(){return Xe}}(0,r.gn)([N.LO],DefaultSearchBarNode.prototype,"filter",void 0);(0,r.gn)([N.aD],DefaultSearchBarNode.prototype,"setFilter",null);(0,r.gn)([N.aD],DefaultSearchBarNode.prototype,"clearSearchbar",null);(0,r.gn)([N.aD],DefaultSearchBarNode.prototype,"clearFilter",null);const Ye={[ye.Q.Keyword]:ge,[ye.Q.Numeric]:He,[ye.Q.Date]:We};let Je=class CatalogSearchContainer extends s.Component{constructor(e){var t;super(e);this.keepSearchbar=false;this.handleSearch=e=>{this.keepSearchbar=true;const t=Ie(e,this.facetKeyMap);if(t){this.props.onSearch(t)}};this.handleFilterChange=e=>{const t=X()(this.view.filter);t.value.filter=e;this.view.setFilter(t);this.handleSearch(t)};const a=[];if(e.disableFullTextSearch){a.push(new DefaultSearchBarNode)}else{a.push(new FulltextSearchBarNode)}a.push(new AQLSearchBarNode);this.view=new SearchInputView(a,this.handleSearch,(t=e.initialFilter&&Ce(e.initialFilter))!==null&&t!==void 0?t:a[0].getDefaultFilter())}get facetKeyMap(){var e;return Object.fromEntries(((e=this.props.facets)!==null&&e!==void 0?e:[]).map((e=>[fe(e),e])))}componentDidMount(){this.props.onLoad()}componentDidUpdate(e){if(this.props.initialFilter!==e.initialFilter){if(this.props.initialFilter){var t;this.view.setFilter((t=Ce(this.props.initialFilter))!==null&&t!==void 0?t:this.view.activeSearchBar.getDefaultFilter())}else{this.view.activeSearchBar.clearFilter();if(!this.keepSearchbar){this.view.activeSearchBar.clearSearchbar()}}this.keepSearchbar=false}}get filters(){var e,t;return(e=(t=this.props.facets)===null||t===void 0?void 0:t.map((e=>({displayName:e.displayName,key:fe(e),type:Ee(e.facetType),renderer:Ye[e.facetType]}))))!==null&&e!==void 0?e:[]}get facets(){var e,t;return Object.fromEntries((e=(t=this.props.facets)===null||t===void 0?void 0:t.map((e=>{var t,a,i,n;return[fe(e),e.facetType===ye.Q.Numeric?{items:[],additionalData:{missing:e.missing,dataMin:(t=be(e)[0])===null||t===void 0?void 0:(a=t.value)===null||a===void 0?void 0:a.min,dataMax:(i=be(e)[0])===null||i===void 0?void 0:(n=i.value)===null||n===void 0?void 0:n.max}}:{items:be(e),additionalData:{missing:e.missing}}]})))!==null&&e!==void 0?e:[])}render(){var e;const{className:t,autoSubmit:a,facets:i=[]}=this.props;const r=this.view.activeSearchBar.filterType===R.iG.FulltextWithFilter;const l=!r;return s.createElement(C,{className:t},s.createElement(w,null,s.createElement(S,{view:this.view}),l&&s.createElement(x,{target:"_blank",href:"https://support.ataccama.com/home/docs/aip/latest/user-guides/one-web-application-user-guide/one-basics/searching-in-one-web-application","data-testid":"attribute_link"},s.createElement(n.Trans,{id:"catalogSearch.aql.viewDocumentation",defaults:"View documentation"}),s.createElement(T,null))),i.length>0&&this.filters.length>0&&s.createElement(E.M_,{initial:false},r&&s.createElement(P,null,s.createElement(ee,{filter:(e=this.view.filter.value.filter)!==null&&e!==void 0?e:undefined,facetFilterDefinitions:this.filters,facets:this.facets,onChange:this.handleFilterChange}))),!a&&s.createElement("span",null,s.createElement(I,{form:"catalog-search-input",onClick:this.view.submit})))}};(0,r.gn)([N.LO],Je.prototype,"view",void 0);(0,r.gn)([N.Fl],Je.prototype,"facetKeyMap",null);(0,r.gn)([(0,k.Q)((()=>D.l))],Je.prototype,"apiClient",void 0);(0,r.gn)([N.aD],Je.prototype,"componentDidUpdate",null);(0,r.gn)([N.Fl],Je.prototype,"filters",null);(0,r.gn)([N.Fl],Je.prototype,"facets",null);Je=(0,r.gn)([o.Pi],Je);const et=(0,i.ZP)(Je)`
  display: flex;
  flex-direction: column;
`;const tt=i.ZP.div`
  ${e=>e.theme.padding("L")};
`;const at=i.ZP.div`
  ${e=>e.theme.margin.top("L")};
`},81332:(e,t,a)=>{"use strict";a.r(t);a.d(t,{CatalogItemsStats:()=>k});var i=a(70655);var n=a(29323);var r=a(2227);var s=a(67294);var l=a(32177);var o=a(16702);var c=a(90476);var d=a(90714);var u=a(27295);var p=a(97325);var h=a(80828);var m=a(76851);var v=a(39526);var g=a(68039);var y=a(35537);var f=a(80880);var b=a(81012);const E=b.ZP.td`
  white-space: nowrap;
  vertical-align: middle;
  text-align: ${e=>e.alignLeft?"left":"right"};
  ${e=>e.emphasize?e.theme.font.bodyMedium():e.theme.font.body()};
  color: ${e=>e.emphasize?e.theme.palette.display[7]:e.theme.palette.display.base};

  &:not(:last-child) {
    ${e=>e.theme.padding.right("M")};
  }

  &:first-of-type {
    ${e=>e.theme.padding.right("L")};
  }
`;const w=b.ZP.tr`
  width: 100%;
  & + & {
    border-top: 1px solid ${e=>e.theme.palette.separate[2]};
  }
`;const C=(0,b.ZP)(E)`
  cursor: pointer;
`;const S=(0,b.ZP)(E)`
  width: 100%;
  min-width: 70px;
  padding-top: 14px;
  padding-bottom: 14px;
  ${e=>e.theme.padding.left("S")};
`;const I=b.ZP.div`
  ${e=>e.theme.margin(0,"L","M")}
`;const x=({label:e,count:t,totalCount:a,color:i,percentage:n})=>s.createElement(w,null,s.createElement(E,{alignLeft:true},e),s.createElement(C,{emphasize:true},(0,y.u)(t)),s.createElement(C,{emphasize:false},n&&s.createElement(f.u,{tooltip:n.tooltip},n.label)),s.createElement(S,null,s.createElement(v.E,{size:g.$u.Medium,data:[{value:t,color:i},{value:a-t}]})));var T=a(10651);const P=(e,t)=>{const a=(0,o.Ov)(e,t);return{label:a,tooltip:`${a} ${i18n({id:"catalog.documentationStats.percentageOfImported",defaults:"of imported"})}`}};const N={detailController:u.T.instanceOf(T.m)};let k=class CatalogItemsStats extends((0,u.Bq)({},N,(({ctx:e})=>({ctx:e.variables})))){componentDidMount(){var e;(e=this.props.detailController.entityVersion)===null||e===void 0?void 0:e._query.rootQuery.ensureRequired(true)}render(){const{detailController:e}=this.props;const{entityVersion:t}=e;let a;if(t==null){const{parentController:t}=e;(0,h.h)(t instanceof T.m,"Expected a detail controller of a connection entity.");const i=this.actionRegistry.get("catalog.document",t.entityVersion,this.props.ctx);a=s.createElement(c.a,{description:i18n({id:"catalog.documentationStats.emptyState",defaults:"No data assets have been documented yet. Run the documentation process."})},i&&s.createElement(d.D,{action:i}))}else{var i,n,o,u;const e=(i=t.totalCount)!==null&&i!==void 0?i:0;const c=(n=t.profiledCount)!==null&&n!==void 0?n:0;const d=(o=t.sampledCount)!==null&&o!==void 0?o:0;const p=(u=t.dqCount)!==null&&u!==void 0?u:0;const h=[{count:e,label:i18n({id:"catalog.documentationStats.imported",defaults:"Imported"}),color:b.KQ.palette.interaction[5]},{count:d,label:i18n({id:"catalog.documentationStats.sampled",defaults:"Sampled"}),color:(0,r.DZ)(.25,b.KQ.palette.interaction[5]),percentage:P(e,d)},{count:c,label:i18n({id:"catalog.documentationStats.profiled",defaults:"Profiled"}),color:(0,r.DZ)(.5,b.KQ.palette.interaction[5]),percentage:P(e,c)},{count:p,label:i18n({id:"catalog.documentationStats.dataQuality",defaults:"Data quality"}),color:(0,r.DZ)(.75,b.KQ.palette.interaction[5]),percentage:P(e,p)}];a=s.createElement(l.iA,null,s.createElement("tbody",null,h.map((t=>s.createElement(x,Object.assign({},t,{totalCount:e,key:t.label}))))))}return s.createElement(f.Zb,{title:i18n({id:"catalog.documentationStats.title",defaults:"Documented catalog items"})},a)}};(0,i.gn)([(0,m.Q)((()=>p._f))],k.prototype,"actionRegistry",void 0);k=(0,i.gn)([n.Pi],k)},9779:(e,t,a)=>{"use strict";a.r(t);a.d(t,{SearchIcon:()=>S,CatalogSearchEmptyState:()=>x});var i=a(33948);var n=a.n(i);var r=a(86359);var s=a(70655);var l=a(29323);var o=a(67294);var c=a(90476);var d=a(27295);var u=a(5167);var p=a(1121);var h=a(33031);var m=a(81012);var v=a(80880);var g=a(76851);var y=a(87625);var f=a(25143);var b=a(35338);var E=a(16887);var w=a(31802);const C=m.ZP.div`
  ${v.RP};
  ${e=>e.theme.font.body()};
  color: ${e=>e.theme.palette.interaction[5]};
`;const S=(0,m.ZP)(h.xxq).attrs({width:"56px"})`
  & path {
    fill: #979797;
  }
  color: ${e=>e.theme.palette.separate[0]};
`;const I=(0,m.ZP)(c.a)`
  padding-top: 100px;
  padding-bottom: 100px;
`;let x=class CatalogSearchEmptyState extends((0,d.Bq)({entityMetadata:d.T.instanceOf(u.T),actionContext:d.T.number(undefined),hasClearButton:d.T.bool(true)},{listingView:d.T.instanceOf(p._)},(({ctx:e})=>({ctx:e.variables})))){constructor(){super(...arguments);this.handleClear=()=>{this.props.listingView.request.setUserFilter(null);this.props.listingView.ensureView()}}get showCreateScreenAction(){if(this.props.listingView.listing instanceof E.Z){return w.V.create(this.props.listingView.listing,this.props.ctx)}return null}get isEmptyFilter(){return this.props.listingView.request.getUserFilter()==null}render(){const{entityMetadata:e}=this.props;const t=(0,f.u)(e,!!this.showCreateScreenAction);const a=i18n({id:"catalogSearch.emptyState.title",defaults:"We didn't find any results for your search."});return this.isEmptyFilter?o.createElement(c.a,{title:t.title,description:t.description},this.showCreateScreenAction&&o.createElement(b.K,{action:this.showCreateScreenAction,primary:true})):o.createElement(I,{description:a,icon:o.createElement(S,null)},this.props.hasClearButton&&o.createElement(C,{onClick:this.handleClear,"data-testid":"clearSearch"},o.createElement(r.Trans,{id:"catalogSearch.emptyState.clearText",defaults:"Clear search criteria"})))}};(0,s.gn)([(0,g.Q)((()=>y.g))],x.prototype,"app",void 0);x=(0,s.gn)([l.Pi],x)},3492:(e,t,a)=>{"use strict";a.r(t);a.d(t,{ConnectionHighlights:()=>y});var i=a(33948);var n=a.n(i);var r=a(70655);var s=a(73303);var l=a.n(s);var o=a(29323);var c=a(67294);var d=a(27295);var u=a(3997);var p=a(76851);var h=a(40952);var m=a(80880);const v=(e,t)=>{var a,i;switch(e){case"TABLE":return i18n({id:"catlaog.catalogItemsCount.tables",defaults:"Tables"});case"VIEW":return i18n({id:"catlaog.catalogItemsCount.views",defaults:"Views"});case"FILE":return i18n({id:"catlaog.catalogItemsCount.files",defaults:"Files"});default:return(a=(i=t.getEntityMetadataByName(e))===null||i===void 0?void 0:i.namingStrategy.displayNamePlural)!==null&&a!==void 0?a:e}};const g=(e,t)=>{var a,i;return(a=(i=t.getEntityMetadataByName(e))===null||i===void 0?void 0:i.namingStrategy.displayNamePlural)!==null&&a!==void 0?a:e};let y=class ConnectionHighlights extends((0,d.Bq)({},{parentDetailController:d.T.entityController(h.Yh)})){render(){var e,t;const a=this.props.parentDetailController.entityVersion;const i=(e=a===null||a===void 0?void 0:a.catalogItemStats.map((({groupType:e,groupCount:t})=>({title:v(e,this.metadataManager),value:t,testId:`${v(e,this.metadataManager)}_highlight`}))).sort(((e,t)=>t.value-e.value)))!==null&&e!==void 0?e:[];const n=(t=a===null||a===void 0?void 0:a.locationStats.map((({groupType:e,groupCount:t})=>({title:g(e,this.metadataManager),value:t,testId:`${g(e,this.metadataManager)}_highlight`}))))!==null&&t!==void 0?t:[];return c.createElement(m.Zb,{fullWidthContent:true,fullHeightContent:true},c.createElement(m.xK,{highlights:[{title:i18n({id:"catalog.catalogItemsCount.all",defaults:"Catalog Items"}),value:l()(i,(e=>e.value)),testId:"catalogItemsCount_highlight"},...i,...n]}))}};(0,r.gn)([(0,p.Q)((()=>u.d))],y.prototype,"metadataManager",void 0);y=(0,r.gn)([o.Pi],y)},43069:(e,t,a)=>{"use strict";a.r(t);a.d(t,{ConnectionTile:()=>p});var i=a(70655);var n=a(29323);var r=a(67294);var s=a(27295);var l=a(10651);var o=a(80880);var c=a(81012);const d=c.ZP.div`
  ${e=>e.theme.margin.top("S")};

  :empty {
    display: none;
  }
`;const u=c.ZP.div`
  ${e=>e.theme.font.regular()};
  color: ${e=>e.theme.palette.display.base};
`;let p=class ConnectionTile extends((0,s.Bq)({},{detailController:s.T.instanceOf(l.m)})){render(){var e;const{detailController:t}=this.props;const a=t.entityVersion;const i=a._.metadata.getEffectiveEntity();const n=["jdbc","mountName","serverName"];const s=n.filter((e=>i.getPropertyByName(e)!=null&&a[e]!=null)).map((e=>r.createElement(u,{key:e,"data-testid":`${e}_property`},a[e])));return r.createElement(r.Fragment,null,r.createElement(o.QE,{"data-testid":"name_property"},(e=a.name)!==null&&e!==void 0?e:t.property.entity.displayName),r.createElement(d,null,s))}};p=(0,i.gn)([n.Pi],p)},76675:(e,t,a)=>{"use strict";a.r(t);a.d(t,{ConnectionTypeSelect:()=>T});var i=a(33948);var n=a.n(i);var r=a(70655);var s=a(22188);var l=a(29323);var o=a(67294);var c=a(27023);var d=a(14017);var u=a(10943);var p=a(27295);var h=a(94975);var m=a(37849);var v=a(3997);var g=a(42971);var y=a(76851);var f=a(47836);var b=a(10651);var E=a(99966);var w=a(62070);var C=a(85147);var S=a(80880);var I=a(3307);var x=a(48661);let T=class ConnectionTypeSelect extends((0,p.Bq)({children:p.T.children(true),actionContext:p.T.number(),showActions:p.T.bool(false),label:p.T.str(undefined)},{parentDetailController:p.T.instanceOf(b.m)},(async({ctx:e})=>({ctx:e})))){constructor(){super(...arguments);this.valueProvider=(0,f.y7)(this.metadataManager,this.valueProvidersService);this.typeWasPicked=false;this.handleTypeSelect=e=>{var t,a;this.typeWasPicked=true;const i=this.items.find((t=>t.value===e));const{parentDetailController:n}=this.props;(t=n.entityVersion)===null||t===void 0?void 0:t._.updateAt([f.q9],e);const r=this.metadataManager.getEntityMetadataByName(i.connectionEntityMapping.connectionEntityName);(a=n.entityVersion)===null||a===void 0?void 0:a._.metadata.setEntity(r);const s=Object.values(n.effectiveProperties).some((e=>{var t;const a=e.constraints.some((e=>!(0,g.Zy)(e)));const i=(t=n.entityVersion)===null||t===void 0?void 0:t._.isDirtyAt([e.name]);return a&&i}));if(s){const e=(0,x.B)(n,(e=>{var t;return e instanceof b.m&&Boolean((t=e.entityVersion)===null||t===void 0?void 0:t._parentGid)}));if(e instanceof b.m){var l;(l=e.entityVersion)===null||l===void 0?void 0:l._.traits.withTrait(w.c,(e=>e.validate()))}}}}get actions(){if(this.props instanceof b.m){const e=this.wcs.get(C.V,this.props.parentDetailController.property);return(0,E.Sv)(e,this.props.entityVersion,this.props.ctx.variables)}}get items(){return(0,f.xl)(this.valueProvider).map((e=>({groupName:e.connectionEntityMapping.categories[0],...e})))}async componentDidMount(){const e=this.valueProvider;if(!e.hasBeenLoaded&&!e.isLoading){const t=this.context.wait();await e.ensureItems();t()}if(this.initialValue){this.typeWasPicked=true}else if(this.items.length===1){this.handleTypeSelect(this.items[0].value)}}get initialValue(){var e;return(e=this.props.parentDetailController.entityVersion)===null||e===void 0?void 0:e[f.q9]}render(){var e;if(this.valueProvider&&this.valueProvider.hasBeenLoaded&&this.items.length===0){return o.createElement(I.mU,null,o.createElement(I.St,null,o.createElement(I.Pz,null),i18n({id:"connectionTypeSelect.errorTitle",defaults:"Data processing engine is not running"})),o.createElement(I.Dy,null,i18n({id:"connectionTypeSelect.errorDescription",defaults:"We are not able to create a physical connection to any data source because the data\n            processing engine is not running. Create a data source without the connection or try\n            again in a moment."})))}const{children:t,showActions:a,actionContext:i,label:n}=this.props;const r=i&&h.f.Create^h.f.CreateEmbedded;const s=o.createElement(S.Sp,{"data-testid":"connectionTypeSelect.PropertyPair"},o.createElement(S.VR,{"data-testid":"connectionTypeSelect.PropertyLabel"},n!==null&&n!==void 0?n:i18n({id:"catalog.connectionType.select.label",defaults:"Connection type"})),o.createElement(S.OI,null,o.createElement(S.AS,{items:this.items,onChange:e=>this.handleTypeSelect(e),initialValue:this.initialValue,clearable:false,hasSearch:true,testId:"connectionTypeSelect.Select"})));return o.createElement("div",null,this.items.length>1&&s,(this.typeWasPicked||!r)&&o.createElement(o.Fragment,null,o.createElement(I.hu,null,t),a&&this.actions&&o.createElement(I.eX,null,o.createElement(u.y,{actions:this.actions.actions,primaryAction:(e=this.actions.primaryAction)!==null&&e!==void 0?e:undefined}))))}};T.contextType=c.jV;(0,r.gn)([(0,y.Q)((()=>v.d))],T.prototype,"metadataManager",void 0);(0,r.gn)([(0,y.Q)((()=>d.s))],T.prototype,"valueProvidersService",void 0);(0,r.gn)([(0,y.Q)((()=>m.c))],T.prototype,"wcs",void 0);(0,r.gn)([s.Fl],T.prototype,"actions",null);(0,r.gn)([s.LO],T.prototype,"typeWasPicked",void 0);(0,r.gn)([s.aD],T.prototype,"handleTypeSelect",void 0);(0,r.gn)([s.Fl],T.prototype,"initialValue",null);T=(0,r.gn)([l.Pi],T)},3307:(e,t,a)=>{"use strict";a.d(t,{hu:()=>r,eX:()=>s,mU:()=>l,Pz:()=>o,St:()=>c,Dy:()=>d});var i=a(33031);var n=a(81012);const r=n.ZP.div`
  ${e=>e.theme.margin.top("L")};
`;const s=n.ZP.div`
  ${e=>e.theme.margin.top("L")};
`;const l=n.ZP.div``;const o=(0,n.ZP)(i.Ucq)`
  ${e=>e.theme.margin.right("S")};
  color: ${e=>e.theme.palette.error[5]};
`;const c=n.ZP.div`
  ${e=>e.theme.font.emphasized()};
  color: ${e=>e.theme.palette.error[5]};
`;const d=n.ZP.div`
  ${e=>e.theme.margin.top("S")};

  ${e=>e.theme.font.regular()};
  color: ${e=>e.theme.palette.display.base};
`},11402:(e,t,a)=>{"use strict";a.r(t);a.d(t,{ConnectionTypeView:()=>g});var i=a(33948);var n=a.n(i);var r=a(70655);var s=a(29323);var l=a(67294);var o=a(27023);var c=a(14017);var d=a(27295);var u=a(76851);var p=a(98519);var h=a(45772);var m=a(5013);var v=a(25108);let g=class ConnectionTypeView extends((0,d.Bq)({},{detailController:d.T.instanceOf(m.F)})){constructor(){super(...arguments);this.translateConnectionTypeJSON=e=>{if(this.valueProvider.hasBeenLoaded){try{const{label:t}=JSON.parse(e);return t}catch{v.warn(`Malformed or missing connection type value provider JSON for value "${e}".`)}}return e};this.valueProvider=this.valueProvidersService.getComplete(this.props.detailController.property)}componentDidMount(){const e=this.valueProvider;if(!e.hasBeenLoaded&&!e.isLoading){const t=this.context.wait();e.ensureItems().then(t)}}render(){const e=e=>this.translateConnectionTypeJSON(this.valueProvider.getLabel(e));const{detailController:t}=this.props;return l.createElement(p.R,{detailController:t},l.createElement(h.x,{detailController:t,transformValue:e}))}};g.contextType=o.jV;(0,r.gn)([(0,u.Q)((()=>c.s))],g.prototype,"valueProvidersService",void 0);g=(0,r.gn)([s.Pi],g)},65172:(e,t,a)=>{"use strict";a.r(t);a.d(t,{CredentialTile:()=>m});var i=a(70655);var n=a(29323);var r=a(67294);var s=a(27295);var l=a(10651);var o=a(80880);var c=a(81012);const d=c.ZP.div`
  ${e=>e.theme.margin.top("S")}
`;const u=c.ZP.div`
  ${e=>e.theme.font.regular()};
  color: ${e=>e.theme.palette.display.base};
`;const p=c.ZP.div`
  ${e=>e.theme.margin.top("S")}
`;const h=(0,c.ZP)(o.Vp)`
  display: inline;
  font-size: 12px;
`;let m=class CredentialTile extends((0,s.Bq)({},{detailController:s.T.instanceOf(l.m)})){render(){var e,t;const{detailController:a}=this.props;const i=a.entityVersion;const n=i._.metadata.getEffectiveEntity();const s=["username"];const l=s.filter((e=>n.getPropertyByName(e)!=null)).map((e=>r.createElement(u,{key:e},i[e])));const c=a.parentController;const m=(c===null||c===void 0?void 0:(e=c.defaultValueManager)===null||e===void 0?void 0:e.defaultValue)===i;return r.createElement("div",null,r.createElement(o.QE,null,(t=i.name)!==null&&t!==void 0?t:a.property.entity.displayName),r.createElement(d,null,l),r.createElement(p,null,m&&r.createElement(h,{label:i18n({id:"catalog.credentials.defaultTag",defaults:"Default"})})))}};m=(0,i.gn)([n.Pi],m)},69954:(e,t,a)=>{"use strict";a.r(t);a.d(t,{CredentialTileValue:()=>v});var i=a(70655);var n=a(29323);var r=a(67294);var s=a(52911);var l=a(27295);var o=a(71534);var c=a(40952);var d=a(19965);var u=a(67047);var p=a(81012);const h=(0,p.ZP)(u.F)`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  ${e=>e.theme.padding(0,"S")};
  color: ${e=>e.theme.palette.display.base};
  border-radius: 2px;
  border: ${e=>e.theme.border.separate};
  background-color: ${e=>e.theme.palette.tertiary.base};

  &:not(:last-child) {
    ${e=>e.theme.margin.right("S")};
  }
`;const m={tileData:o.T.entityVersion(c.ew)};let v=class CredentialTileValue extends((0,l.Bq)({},m)){render(){const{tileData:e}=this.props;return r.createElement(s.o,{"data-testid":"hello hello hello"},e.credentials.map(((e,t)=>r.createElement(h,{"data-testid":"yesyesyes",key:e._gid||t,to:(0,d.h)(e._)},e.name))))}};v=(0,i.gn)([n.Pi],v)},8689:(e,t,a)=>{"use strict";a.r(t);a.d(t,{CredentialTypeSelect:()=>C});var i=a(33948);var n=a.n(i);var r=a(70655);var s=a(22188);var l=a(29323);var o=a(67294);var c=a(27023);var d=a(14017);var u=a(27295);var p=a(94975);var h=a(22558);var m=a(77544);var v=a(3997);var g=a(76851);var y=a(7367);var f=a(47836);var b=a(10651);var E=a(80880);var w=a(3307);let C=class CredentialTypeSelect extends((0,u.Bq)({children:u.T.children(true),actionContext:u.T.number()},{detailController:u.T.instanceOf(b.m)})){constructor(){super(...arguments);this.valueProvider=(0,f.y7)(this.metadataManager,this.valueProvidersService);this.handleTypeSelect=e=>{var t;this.selectedType=e;const a=this.metadataManager.getEntityMetadataByName(e);(t=this.props.detailController.entityVersion)===null||t===void 0?void 0:t._.metadata.setEntity(a)};this.initializeType=()=>{if(this.connection){const e=this.getItems(this.connection.executorType);if(e.length===1){this.handleTypeSelect(e[0].value)}}}}getItems(e){const t=(0,f.xl)(this.valueProvider).find((t=>t.value===e));return t.connectionEntityMapping.supportedCredentialEntityNames.map((e=>({value:e,label:this.metadataManager.getEntityMetadataByName(e).displayName})))}async componentDidMount(){const e=this.valueProvider;if(!e.hasBeenLoaded&&!e.isLoading){const t=this.context.wait();await e.ensureItems();t()}const t=(0,b.c)(this.props.detailController,"connection");if(t){this.connection=t.entityVersion}else{var a;const e=(a=this.props.detailController.entityVersion)===null||a===void 0?void 0:a._;if(e){const t=await this.entityManager.getEntity(e.metadata.property.parent,e.parentGid,{version:m.XH.Draft});this.connection=t.versions.draft}}this.initializeType()}componentDidUpdate(){this.initializeType()}render(){if(!this.connection){return null}const{children:e,actionContext:t}=this.props;const a=t&&p.f.Create^p.f.CreateEmbedded;const i=this.getItems(this.connection.executorType);const n=o.createElement(E.Sp,{"data-testid":"connectionType_property"},o.createElement(E.VR,null,i18n({id:"catalog.credentialType.select.label",defaults:"Credential type"})),o.createElement(E.OI,null,o.createElement(E.q4,{items:i,onChange:e=>this.handleTypeSelect(e),value:this.selectedType,clearable:false,placeholder:i18n({id:"catalog.credentialType.select.placeholder",defaults:"Select Credential Type"}),hasSearch:true})));return o.createElement("div",null,i.length>1&&n,o.createElement(w.hu,null,(this.selectedType||!a)&&e))}};C.contextType=c.jV;(0,r.gn)([(0,g.Q)((()=>v.d))],C.prototype,"metadataManager",void 0);(0,r.gn)([(0,g.Q)((()=>h.v))],C.prototype,"entityManager",void 0);(0,r.gn)([(0,g.Q)((()=>d.s))],C.prototype,"valueProvidersService",void 0);(0,r.gn)([s.LO],C.prototype,"selectedType",void 0);(0,r.gn)([s.LO],C.prototype,"connection",void 0);(0,r.gn)([y.H],C.prototype,"getItems",null);(0,r.gn)([s.aD],C.prototype,"handleTypeSelect",void 0);(0,r.gn)([s.aD],C.prototype,"initializeType",void 0);(0,r.gn)([s.aD],C.prototype,"componentDidMount",null);C=(0,r.gn)([l.Pi],C)},9183:(e,t,a)=>{"use strict";a.r(t);a.d(t,{DatasourceBrowserOverlayView:()=>U});var i=a(33948);var n=a(70655);var r=a(29323);var s=a(67294);var l=a(27295);var o=a(71534);var c=a(22188);var d=a(47850);var u=a(3629);var p=a(29052);var h=a(2269);var m=a(9009);var v=a(76851);var g=a(57516);var y=a(39426);var f=a(42645);var b=a(40114);var E=a(14304);var w=a(9812);var C=a(81012);const S=(0,C.ZP)(w.H)`
  width: 457px;
  ${e=>e.theme.margin("L")};
`;const I=({onChange:e,value:t})=>s.createElement(S,{value:t,onChange:e,placeholder:i18n({id:"catalog.DatasourceBrowserFilter.placeholder",defaults:"Filter items"}),testId:"datasourceBrowserOverlay_filter"});var x=a(80880);var T=a(31650);const P=(0,C.ZP)(x.nN)`
  width: 800px;
`;const N=(0,C.ZP)(T.M)`
  ${e=>e.theme.padding(0)};
  border: none;
`;var k=a(86359);const D=C.ZP.span`
  flex: auto;
  ${e=>e.theme.font.title()};
`;const L=({title:e})=>s.createElement(D,null,s.createElement(k.Trans,{id:"catalog.DatasourceBrowserOverlay.title",defaults:"{title} — connection browser",values:{title:e}}));var M=a(16457);var V=a(90476);var $=a(9779);const A=({filter:e,onClearFilter:t})=>s.createElement(V.a,{title:s.createElement(k.Trans,{id:"catalog.DatasourceBrowserOverlay.NotFoundEmptyState.title",defaults:"No matches found for ‘{filter}’",values:{filter:e}}),description:s.createElement(k.Trans,{id:"catalog.DatasourceBrowserOverlay.NotFoundEmptyState.description",defaults:"Clear the filter to try again"}),icon:s.createElement($.SearchIcon,null)},s.createElement(x.zx,{onClick:t},s.createElement(k.Trans,{id:"catalog.DatasourceBrowserOverlay.NotFoundEmptyState.clearFilter",defaults:"Clear filter"})));const F=()=>s.createElement(V.a,{title:s.createElement(k.Trans,{id:"catalog.DatasourceBrowserOverlay.NoCredentialsEmptyState.title",defaults:"Couldn't browse the datasource"}),icon:s.createElement($.SearchIcon,null)});const R=({currentLocationName:e,previousLocationName:t,onGoBack:a})=>s.createElement(V.a,{title:e?s.createElement(k.Trans,{id:"catalog.DatasourceBrowserOverlay.NoItemsEmptyState.title",defaults:"No items in {currentLocationName}",values:{currentLocationName:e}}):s.createElement(k.Trans,{id:"catalog.DatasourceBrowserOverlay.NoItemsEmptyState.title.noName",defaults:"No items"}),description:s.createElement(k.Trans,{id:"catalog.DatasourceBrowserOverlay.NoItemsEmptyState.description",defaults:"Sorry, there’s nothing currently stored here."}),icon:s.createElement($.SearchIcon,null)},a&&s.createElement(x.rU,{onClick:a},t?s.createElement(k.Trans,{id:"catalog.DatasourceBrowserOverlay.NoItemsEmptyState.goBack.withItem",defaults:"Back to {previousLocationName}",values:{previousLocationName:t}}):s.createElement(k.Trans,{id:"catalog.DatasourceBrowserOverlay.NoItemsEmptyState.goBack",defaults:"Go back"})));const _=C.ZP.div`
  width: 100%;
  height: 250px;
  display: flex;
  align-items: center;
  justify-content: center;
`;const O=()=>s.createElement(_,null,s.createElement(m.$j,null));var B=a(23279);var Z=a.n(B);var q=a(25542);var Q=a(28525);let U=class DatasourceBrowserOverlayView extends((0,l.Bq)({entityVersion:o.T.entityVersion()})){constructor(){super(...arguments);this.browser=new y.x(this.props.entityVersion._);this.filter="";this.showDataPreview=async(e,t)=>{e.stopPropagation();const{credentialsNeeded:a,validCredential:i}=this.browser;try{if(!a||i){const e=await this.browser.getDataPreview(t);await this.modalManager.show(((t,a)=>s.createElement(g.x,{dataPreview:e,onDecline:a})))}}catch(e){this.emergencyService.handleError(e)}};this.importToCatalog=async(e,t)=>{e.stopPropagation();await this.browser.import(t.path)};this.handleRowClick=({row:e,openInNewTab:t})=>{if(!e.leafNode){this.navigateToPath(e.path,t)}};this.navigateToPath=(e,t)=>{this.clearActiveSelection();this.browser.browse(e);this.filter=""};this.handleChangeFilter=e=>{this.clearActiveSelection();this.browser.browse(this.browser.path,1,e)};this.debouncedChangeFilter=Z()(this.handleChangeFilter,300,{maxWait:600});this.handleFilter=e=>{if(this.filter!==e){this.filter=e;this.debouncedChangeFilter(e)}}}componentDidMount(){this.createSelection();this.browser.browse([])}componentWillUnmount(){this.clearActiveSelection()}get tableColumns(){return[{key:"__selection",CellRenderer:(0,r.Pi)((e=>s.createElement(E.M,Object.assign({},e,{selection:this.selection}))))},{key:"name",name:"Name",emphasized:true},{key:"type",name:"Type"},{key:"actions",CellRenderer:(0,r.Pi)((e=>s.createElement(M.X,Object.assign({showDataPreview:this.showDataPreview,importToCatalog:this.importToCatalog},e))))}]}clearActiveSelection(){if(this.selection){this.selectionManager.clearActiveSelection(this.selection);this.selection.clear()}}createSelection(){this.clearActiveSelection();this.selection=new f.w(this.props.entityVersion);this.selection.hooks.onSelect.tap("DatasourceBrowserView",(e=>{this.selectionManager.setActiveSelection(e)}));this.selection.hooks.onActionComplete.tap("DatasourceBrowserView",(()=>{this.createSelection()}))}content(e){const{isLoading:t,browseErrorMsg:a,items:i,hasBrowsed:n}=this.browser;if(!n){return s.createElement(m.t2,null)}if(a!==null){return s.createElement(P,null,s.createElement(F,null))}if(i.length===0&&!this.browser.filter){const{path:t}=this.browser;return s.createElement(P,null,s.createElement(R,{currentLocationName:t[this.browser.path.length-1],previousLocationName:t[this.browser.path.length-2],onGoBack:()=>t.length>0?this.navigateToPath(t.slice(0,-1)):e()}))}let r;if(t){r=s.createElement(O,null)}else if(i.length===0&&this.browser.filter){r=s.createElement(A,{filter:this.browser.filter,onClearFilter:()=>this.handleFilter("")})}else{r=s.createElement(s.Fragment,null,s.createElement(x.Rm,null,s.createElement(d.iA,{columns:this.tableColumns,rows:i,onRowClick:this.handleRowClick,absorbingColumn:true})),s.createElement(b.L,{datasourceBrowser:this.browser}))}return s.createElement(P,null,s.createElement(I,{value:this.filter,onChange:this.handleFilter}),r)}render(){const{entityVersion:e}=this.props;return s.createElement(Q.Q,{closeButtonFallbackLocation:{routeName:q.N.entity(this.props.entityVersion._.metadata.getEffectiveEntity().name).detail("overview"),params:{gid:this.props.entityVersion._gid}},header:s.createElement(x.gF,{gap:"M",alignY:"center",nowrap:true},s.createElement(L,{title:e._displayName}),this.browser.root&&s.createElement(N,{connection:this.props.entityVersion._,rootBrowserItem:this.browser.root,navigate:this.navigateToPath}))},(({onClose:e})=>this.content(e)))}};(0,n.gn)([c.LO],U.prototype,"browser",void 0);(0,n.gn)([(0,v.Q)((()=>p.g))],U.prototype,"modalManager",void 0);(0,n.gn)([(0,v.Q)((()=>h.Z))],U.prototype,"selectionManager",void 0);(0,n.gn)([c.LO],U.prototype,"selection",void 0);(0,n.gn)([(0,v.Q)((()=>u.m))],U.prototype,"emergencyService",void 0);(0,n.gn)([c.LO],U.prototype,"filter",void 0);(0,n.gn)([c.aD],U.prototype,"handleChangeFilter",void 0);(0,n.gn)([c.aD],U.prototype,"handleFilter",void 0);(0,n.gn)([c.aD],U.prototype,"clearActiveSelection",null);(0,n.gn)([c.aD],U.prototype,"createSelection",null);U=(0,n.gn)([r.Pi],U)},31650:(e,t,a)=>{"use strict";a.d(t,{M:()=>v});var i=a(33948);var n=a(70655);var r=a(29323);var s=a(67294);var l=a(33031);const o={SCHEMA:l.iQl.scheme,TABLE:l.iQl.table,DATABASE:l.iQl.database,POSTGRESQL:l.iQl.database,MYSQL:l.iQl.database,default:l.iQl.database};var c=a(81012);const d=c.ZP.div`
  ${e=>e.theme.margin.right("XS")}
  ${e=>e.theme.transition.normal("color")};
  color: ${e=>e.theme.palette.display[3]};
`;const u=c.ZP.div`
  display: flex;
  align-items: center;
  justify-content: center;
  height: 36px;
  cursor: pointer;
  ${e=>e.theme.transition.normal("color")};

  &:hover {
    color: ${e=>e.theme.palette.display[7]};

    ${d} {
      color: ${e=>e.theme.palette.display.base};
    }
  }
`;const p=c.ZP.div`
  ${e=>e.theme.padding(0,"M")}
  display: flex;
  align-items: center;
  border-bottom: 1px solid ${e=>e.theme.palette.separate[2]};
  ${e=>e.theme.font.secondary()};
  font-size: 12px;
`;const h=(0,c.ZP)(l.oAD)`
  color: ${e=>e.theme.palette.display[3]};
`;const m=({icon:e})=>s.createElement(d,null,e);let v=class DatasourceBrowserBreadcrumb extends s.Component{constructor(){super(...arguments);this.handleMouseUp=(e,t)=>t.button===1&&this.handleNavigate(e,true);this.handleClick=(e,t)=>this.handleNavigate(e,t.metaKey||t.ctrlKey);this.handleNavigate=(e,t)=>{const a=1;this.props.navigate(this.breadcrumbItems.map((e=>e.name)).slice(a,e+1),t)};this.getBreadcrumbIcon=e=>o[e]||o.default}get breadcrumbItems(){const{rootBrowserItem:e,connection:t}=this.props;const a={name:t.versions.draft._displayName,type:t.versions.draft.type};const i=e.detailedPath.map((({name:e,type:t})=>({name:e,type:t})));return[a,...i]}render(){const{className:e}=this.props;const t=this.breadcrumbItems;return s.createElement(p,{"data-testid":"browsing_breadcrumb",className:e},t.map(((e,a)=>s.createElement(s.Fragment,{key:e.name},s.createElement(u,{"data-testid":"browsing_breadcrumb_item",onMouseUp:e=>this.handleMouseUp(a,e),onClick:e=>this.handleClick(a,e)},s.createElement(m,{icon:this.getBreadcrumbIcon(e.type)}),e.name),a!==t.length-1&&s.createElement(h,null)))))}};v=(0,n.gn)([r.Pi],v)},16457:(e,t,a)=>{"use strict";a.d(t,{X:()=>h});var i=a(67294);var n=a(29323);var r=a(33031);var s=a(80880);var l=a(81012);const o=(0,l.ZP)(s.Mg)`
  color: ${e=>e.theme.palette.display[3]};

  &:hover {
    color: ${e=>e.theme.palette.display.base};
  }

  ${e=>e.theme.transition.normal("box-shadow","background-color","color")};
`;const c=(0,l.ZP)(o).attrs({icon:r.iQl.eye})``;const d=(0,l.ZP)(o).attrs({icon:r.iQl.upload2})``;const u=l.ZP.div`
  display: inline-block;
`;const p=({rowData:e,showDataPreview:t,importToCatalog:a})=>i.createElement(s.gF,{alignY:"center",align:"right",gap:"M",nowrap:true},e.hasPreview&&i.createElement(s.u,{Wrapper:u,tooltip:i18n({id:"catalog.browser.preview",defaults:"Preview"})},i.createElement(c,{"data-testid":"browsing_item_previewIcon",onClick:a=>t(a,e)})),e.importable&&i.createElement(s.u,{Wrapper:u,tooltip:i18n({id:"catalog.browser.import",defaults:"Import"})},i.createElement(d,{"data-testid":"browsing_item_importIcon",onClick:t=>a(t,e)})));const h=(0,n.Pi)(p)},40114:(e,t,a)=>{"use strict";a.d(t,{L:()=>l});var i=a(70655);var n=a(29323);var r=a(67294);var s=a(83812);let l=class DatasourceBrowserPaginator extends r.Component{render(){const{browserPageData:e,browse:t,path:a,page:i,filter:n,pageSize:l}=this.props.datasourceBrowser;if(!e){return null}return r.createElement(s.D,{variant:"wide",pagination:{pageNumber:i,pageSize:l,totalCount:e.children.totalCount,prevPage:()=>t(a,i-1,n),nextPage:()=>t(a,i+1,n),setPage:e=>t(a,e,n),setPageSize:e=>{this.props.datasourceBrowser.pageSize=e;t(a,1,n)},hasPreviousPage:i>1,hasNextPage:e.children.pageInfo.hasNextPage}})}};l=(0,i.gn)([n.Pi],l)},14304:(e,t,a)=>{"use strict";a.d(t,{M:()=>p});var i=a(33948);var n=a.n(i);var r=a(70655);var s=a(22188);var l=a(29323);var o=a(67294);var c=a(2269);var d=a(76851);var u=a(80880);let p=class DatasourceBrowserSelectionCell extends o.Component{constructor(){super(...arguments);this.handleChange=()=>{const{selection:e,rowData:t}=this.props;e.toggleSelect(t)};this.handleClick=e=>{e.stopPropagation()}}get disabled(){const{selection:e,rowData:t}=this.props;return e.isSealed||!t.selectable}get isSelected(){const{selection:e,rowData:t}=this.props;return e.isSelected(t)}render(){return o.createElement(u.XZ,{enableHoverEffect:true,checked:this.isSelected,disabled:this.disabled,onChange:this.handleChange,onClick:this.handleClick})}};(0,r.gn)([(0,d.Q)((()=>c.Z))],p.prototype,"bulkActionManager",void 0);(0,r.gn)([s.Fl],p.prototype,"disabled",null);(0,r.gn)([s.Fl],p.prototype,"isSelected",null);p=(0,r.gn)([l.Pi],p)},91446:(e,t,a)=>{"use strict";a.r(t);a.d(t,{DatasourceBrowserView:()=>k});var i=a(70655);var n=a(18446);var r=a.n(n);var s=a(22188);var l=a(29323);var o=a(67294);var c=a(87625);var d=a(47850);var u=a(3629);var p=a(29052);var h=a(2269);var m=a(9009);var v=a(27295);var g=a(25542);var y=a(60409);var f=a(71534);var b=a(76851);var E=a(16457);var w=a(80880);var C=a(57516);var S=a(39426);var I=a(42645);var x=a(31650);var T=a(40114);var P=a(14304);const N={entity:f.T.instanceOf(y.J),browserPath:f.T.list(f.T.str()),browser:f.T.instanceOf(S.x)};let k=class DatasourceBrowserView extends((0,v.Bq)(N)){constructor(e){super(e);this.showDataPreview=async(e,t)=>{e.stopPropagation();const{browser:a}=this.props;const{credentialsNeeded:i,validCredential:n}=a;try{if(!i||n){const e=await a.getDataPreview(t);await this.modalManager.show(((t,a)=>o.createElement(C.x,{dataPreview:e,onDecline:a})))}}catch(e){this.emergencyService.handleError(e)}};this.importToCatalog=async(e,t)=>{e.stopPropagation();const{browser:a}=this.props;await a.import(t.path)};this.handleRowClick=({row:e,openInNewTab:t})=>{if(!e.leafNode){this.navigateToPath(e.path,t)}};this.navigateToPath=(e,t)=>{const{entity:a}=this.props;const i={routeName:g.N.entity(a.metadata.getEffectiveEntity().name).detail("browse"),params:{gid:a.gid,path:e}};t?this.app.openInNewTab(i):this.app.navigate(i)};this.createSelection()}componentDidMount(){}componentDidUpdate(e){if(!r()(this.props.browserPath,e.browserPath)){this.createSelection();this.props.browser.browse(this.props.browserPath)}}componentWillUnmount(){this.clearActiveSelection()}get tableColumns(){return[{key:"__selection",CellRenderer:(0,l.Pi)((e=>o.createElement(P.M,Object.assign({},e,{selection:this.selection}))))},{key:"name",name:"Name",emphasized:true},{key:"type",name:"Type"},{key:"actions",CellRenderer:(0,l.Pi)((e=>o.createElement(E.X,Object.assign({showDataPreview:this.showDataPreview,importToCatalog:this.importToCatalog},e))))}]}render(){const{isLoading:e,browseErrorMsg:t,items:a,root:i}=this.props.browser;if(e){return o.createElement(m.t2,null)}if(t!==null){return o.createElement(w.b5,null,"Couldn't browse the datasource")}return o.createElement(o.Fragment,null,o.createElement(w.nN,null,i&&o.createElement(x.M,{connection:this.props.entity,rootBrowserItem:i,navigate:this.navigateToPath}),o.createElement(w.Rm,null,o.createElement(d.iA,{columns:this.tableColumns,rows:a,onRowClick:this.handleRowClick,absorbingColumn:true}))),o.createElement(T.L,{datasourceBrowser:this.props.browser}))}clearActiveSelection(){if(this.selection){this.selectionManager.clearActiveSelection(this.selection)}}createSelection(){this.clearActiveSelection();this.selection=new I.w(this.props.entity.versions.draft);this.selection.hooks.onSelect.tap("DatasourceBrowserView",(e=>{this.selectionManager.setActiveSelection(e)}));this.selection.hooks.onActionComplete.tap("DatasourceBrowserView",(()=>{this.createSelection()}))}};(0,i.gn)([(0,b.Q)((()=>c.g))],k.prototype,"app",void 0);(0,i.gn)([(0,b.Q)((()=>p.g))],k.prototype,"modalManager",void 0);(0,i.gn)([(0,b.Q)((()=>h.Z))],k.prototype,"selectionManager",void 0);(0,i.gn)([s.LO],k.prototype,"selection",void 0);(0,i.gn)([(0,b.Q)((()=>u.m))],k.prototype,"emergencyService",void 0);(0,i.gn)([s.aD],k.prototype,"clearActiveSelection",null);(0,i.gn)([s.aD],k.prototype,"createSelection",null);k=(0,i.gn)([l.Pi],k)},78020:(e,t,a)=>{"use strict";a.r(t);a.d(t,{DatasourceCatalogItemListingProvider:()=>E});var i=a(33948);var n=a.n(i);var r=a(70655);var s=a(29323);var l=a(6906);var o=a(27295);var c=a(22558);var d=a(77544);var u=a(3997);var p=a(39703);var h=a(1121);var m=a(71710);var v=a(45548);var g=a(80828);var y=a(8599);var f=a(40952);const b=e=>[{pattern:".",filter:`catalogItemSource.sourceId = '${e}'`},...y.kY];let E=class DatasourceCatalogItemListingProvider extends((0,o.Bq)({entity:o.T.entity(f.Yh),actionContext:o.T.number(),children:o.T.widget({listingView:o.T.instanceOf(h._)})},{},(({childCtx:e})=>({listingView:e.variables.listingView})),(({props:e,ctx:t})=>{const a=v.n.get(u.d).getEntityMetadataByName("catalogItem");(0,g.h)(a,`Metadata for "catalogItem" entity not found.`);const i=e.entity.gid;(0,g.h)(i,`Missing gid. The source entity is expected to be already persisted.`);const n=v.n.get(c.v).createMultiParentListing(a,{version:d.XH.Draft,fetchRules:b(i)});const r=new h._(n,new p.n6(new m.w(t.variables.screen,(0,p.mg)(n.query))));const s=new l.L(n);return{...t.variables,listing:n,listingView:r,entityMetadata:a,requiredProperties:n.query.getProperties(),logListingEvents:s,lazyFetchRules:y.f3}}))){render(){const{children:e,listingView:t}=this.props;return e({listingView:t})}};E=(0,r.gn)([s.Pi],E)},19529:(e,t,a)=>{"use strict";a.r(t);a.d(t,{DocumentationStatus:()=>E});var i=a(33948);var n=a(70655);var r=a(22188);var s=a(29323);var l=a(67294);var o=a(92450);var c=a(27295);var d=a(74674);var u=a(22558);var p=a(76851);var h=a(9009);var m=a(80880);var v=a(81012);const g=v.ZP.div`
  text-align: right;
`;const y=v.ZP.div`
  ${e=>e.theme.font.secondary()};
  white-space: nowrap;
  width: 100%;
`;const f=(0,v.ZP)(h.$j)`
  ${e=>e.theme.margin.right("S")};
`;const b=v.ZP.button`
  ${m.RP};
  ${e=>e.theme.font.regular()};
`;let E=class DocumentationStatus extends((0,c.Bq)({sourceOrConnection:c.T.entity(),renderIfEmpty:c.T.widget({},undefined)})){constructor(){super(...arguments);this.onDetailClick=async e=>{if(!this.runningFlowId){return}const t=await this.entityManager.getEntityVersion("documentationFlowInstance",this.runningFlowId,{fetchRules:[{pattern:"./*",enabled:false}]});this.context.defaultNavigationActionHandler.handleTarget({kind:"entity",target:t,openInNewTab:e.metaKey||e.ctrlKey})}}get runningFlowId(){return this.documentationStatusService.entityGidsWithRunningFlow.get(this.props.sourceOrConnection.gid)}render(){if(!this.runningFlowId){var e,t;return(e=(t=this.props).renderIfEmpty)===null||e===void 0?void 0:e.call(t)}return l.createElement(g,null,l.createElement(y,null,l.createElement(f,null),i18n({id:"documentationStatus.title",defaults:"Running documentation process"})),l.createElement(b,{onClick:this.onDetailClick},i18n({id:"documentationStatus.showDetails",defaults:"Show details"})))}};E.contextType=d.wH;(0,n.gn)([(0,p.Q)((()=>u.v))],E.prototype,"entityManager",void 0);(0,n.gn)([(0,p.Q)((()=>o.s))],E.prototype,"documentationStatusService",void 0);(0,n.gn)([r.Fl],E.prototype,"runningFlowId",null);E=(0,n.gn)([s.Pi],E)},56267:(e,t,a)=>{"use strict";a.r(t);a.d(t,{FileMetadataView:()=>E});var i=a(33948);var n=a(15306);var r=a(70655);var s=a(29323);var l=a(67294);var o=a(21610);var c=a(78320);var d=a(27295);var u=a(76851);const p='{\n  "_type": "entitySidebar.controller",\n  "children": {\n    "_type": "entitySidebar.view",\n    "disableTitleLink": true,\n    "children": {\n      "_type": "entity.entity",\n      "children": [\n        {\n          "_type": "entity.card",\n          "title": "File information",\n          "children": [\n            { "_type": "entity.property", "name": "size" },\n            { "_type": "entity.property", "name": "createdOn" },\n            {\n              "_type": "entity.property",\n              "name": "modifiedOn"\n            }\n          ]\n        }\n      ]\n    }\n  }\n}\n';var h=a(73791);var m=a(10651);var v=a(80880);var g=a(81012);const y=g.ZP.div`
  color: ${e=>e.theme.palette.display[3]};
`;const f=g.ZP.div`
  ${e=>e.theme.margin("M",0)};

  display: inline-flex;
  align-items: center;

  ${e=>e.theme.font.body()};
  ${v.RP};
  &:hover > ${y} {
    color: ${e=>e.theme.palette.display.base};
  }
`;const b=g.ZP.div`
  ${e=>e.theme.margin.left("S")};
`;let E=class FileMetadataView extends((0,d.Bq)({},{detailController:d.T.instanceOf(m.m)})){constructor(){super(...arguments);this.showAdditionalInfo=()=>{const e=this.props.detailController.entityVersion;this.sidebarManager.replace(new h.K(e,JSON.parse(p)))}}render(){return l.createElement(f,{onClick:this.showAdditionalInfo},l.createElement(y,null,l.createElement(c.o,null)),l.createElement(b,null,i18n({id:"catalog.fileMetadata.showAdditionalInfoButton",defaults:"Show Additional File Information"})))}};(0,r.gn)([(0,u.Q)((()=>o.E))],E.prototype,"sidebarManager",void 0);E=(0,r.gn)([s.Pi],E)},92834:(e,t,a)=>{"use strict";a.r(t);a.d(t,{IndexColumnNameTableCell:()=>c});var i=a(70655);var n=a(29323);var r=a(27295);var s=a(71534);var l=a(40952);const o={rowData:s.T.entityVersion(l.gm)};let c=class IndexColumnNameTableCell extends((0,r.Bq)({},o)){render(){const{rowData:e}=this.props;return e.columns._.items.map((e=>e===null||e===void 0?void 0:e.name)).join(", ")}};c=(0,i.gn)([n.Pi],c)},75427:(e,t,a)=>{"use strict";a.r(t);a.d(t,{LinkedInstances:()=>R});var i=a(33948);var n=a(70655);var r=a(86359);var s=a(22188);var l=a(29323);var o=a(67294);var c=a(61745);var d=a(33031);var u=a(9009);var p=a(27295);var h=a(74674);var m=a(1946);var v=a(22558);var g=a(77544);var y=a(3997);var f=a(4600);var b=a(86676);var E=a(71534);var w=a(76851);var C=a(17923);const S=[{pattern:"./targets",pageSize:Infinity},{pattern:"./targets/target",entityVersionExtensions:["ancestor"]},{pattern:"./targets/target/{tableType,dataInstances}"},{pattern:"./targets/target/dataInstaces/target"}];var I=a(36736);var x=a(80880);var T=a(73394);var P=a(81012);var N=a(39127);const k=P.ZP.div`
  position: relative;
  display: flex;
  justify-content: space-between;
  align-items: center;
  ${e=>e.theme.margin.top("S")};

  &:not(:last-child) {
    box-shadow: inset 0px -1px 0px #c8d4da;
  }
`;const D=(0,P.ZP)(T.O)`
  ${e=>e.theme.padding.bottom("S")};
`;const L=(0,P.ZP)(N.h)`
  color: ${e=>e.theme.palette.display[3]};
  ${e=>e.theme.padding.top("S")};
`;const M=P.ZP.div`
  color: ${e=>e.theme.palette.display[7]};
  ${e=>e.theme.padding.top("S")};
  cursor: pointer;
  &:hover {
    text-decoration: underline;
  }
`;const V=(0,P.ZP)(x.zx)`
  ${e=>e.theme.margin.top("L")};
`;const $=(0,P.ZP)(x.xv)`
  ${e=>e.theme.margin.top("L")};
`;const A=P.ZP.div`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  flex-wrap: wrap;
`;const F={entity:E.T.entity({synonym:E.T.str(undefined)}),entityVersion:E.T.entityVersion({synonym:E.T.str(undefined)})};let R=class LinkedInstances extends((0,p.Bq)(F)){constructor(){var e;super(...arguments);this.initialized=false;this.groupListing=this.em.createTopLevelListing(this.mm.getPropertyForNodePath("/catalogItemGroups"),{fetchRules:[{pattern:".",filter:`targets.some(target.$id = "${this.props.entity.gid}")`},...S]});this.pickerListing=this.em.createMultiParentListing(((e=this.props.entity.metadata.entity)===null||e===void 0?void 0:e.getSuperSuperEntity())||this.props.entity.metadata.entity,{version:g.XH.Draft,fetchRules:[...m.w$,{pattern:".",filter:`$id != "${this.props.entity.gid}"`}]});this.handleClick=e=>{this.context.defaultNavigationActionHandler.handleTarget({kind:"entity",target:e})};this.handleLink=async e=>{var t;const a=this.props.entityVersion;const i=this.group;const n=await this.getCIGroupContainingMember(e._gid);let r;if(i&&n){if(i._gid===n._gid){return}r=this.groupListing.appendNewItem();[...i.targets,...n.targets].forEach((e=>r.targets._.appendNewItem(e)));this.em.deleteEntities([i._,n._])}else if(i||n){r=i!==null&&i!==void 0?i:n;r.targets._.appendNewItem({target:i?e:a})}else{r=this.groupListing.appendNewItem();r.targets._.appendNewItem({target:e});r.targets._.appendNewItem({target:a})}await this.em.saveEntity(r._);(0,s.z)((()=>this.group=r));await((t=this.group)===null||t===void 0?void 0:t._query.require(S).ensureRequired(true))};this.handleUnlink=async e=>{if(!this.group){return}if(this.group.targets._.allItems.length===2){await this.em.deleteEntities([this.group._]);(0,s.z)((()=>this.group=undefined))}else{var t;const a=this.group.targets.find((t=>t.target===e));await this.em.deleteEntities([a._]);await((t=this.group)===null||t===void 0?void 0:t._query.ensureRequired())}if(e===this.props.entityVersion){(0,s.z)((()=>this.group=undefined))}}}get isReadOnly(){var e;return((e=this.props.entityVersion)===null||e===void 0?void 0:e._draftType)===f.d.Delete||!this.props.entity.permissions.canEntity(b.f.CreateDeleteDraft)}async getCIGroupContainingMember(e){const t=this.em.createTopLevelListing(this.mm.getPropertyForNodePath("/catalogItemGroups"),{fetchRules:[{pattern:".",filter:`targets.some(target.$id = "${e}")`},{pattern:"./targets/target"}]});await t.ensureItems();return t.allItems[0]}async componentDidMount(){await this.groupListing.ensureItems();(0,s.z)((()=>{this.group=this.groupListing.allItems[0];this.initialized=true}))}render(){var e;const{entity:t}=this.props;const a=`${t.metadata.property.testId}_linkedInstances`;const i=(e=this.group)===null||e===void 0?void 0:e.targets.map((e=>e.target)).filter((e=>e!==this.props.entityVersion));const n=o.createElement(I.E,{listing:this.pickerListing,selectedItems:i,multiselect:true,onSelect:this.handleLink,stretchToContent:true},o.createElement(x.u,{disabled:!this.isReadOnly,tooltip:i18n({id:"catalog.linkedInstances.noPermissions.tooltip",defaults:"You don't have permissions to link"})},o.createElement(V,{size:"S",disabled:this.isReadOnly,"data-testid":`${a}_add`,icon:o.createElement(d.WaA,null)},o.createElement(r.Trans,{id:"catalog.linkedInstances.add",defaults:"Link catalog item"}))));const s=o.createElement(x.Kq,null,o.createElement(x.gF,{alignY:"center"},o.createElement(x.gF,{align:"right"})),i===null||i===void 0?void 0:i.map((e=>{var t;return o.createElement(k,{key:e._.gid},o.createElement(x.gF,{gap:"M"},o.createElement(L,{catalogItem:e}),o.createElement(x.Kq,null,o.createElement(x.gF,{gap:"S"},o.createElement(M,{onClick:()=>this.handleClick(e)},e._displayName),o.createElement(x.cM,{tags:(t=e.dataInstances)===null||t===void 0?void 0:t._.allNotDeletedItems.map((e=>({key:e._gid,label:e.target?e.target._displayName:e._displayName})))})),o.createElement(D,{items:(0,C.Z)(e._).slice(1)}))),!this.isReadOnly&&o.createElement(c.J,{actions:[{displayName:i18n({id:"catalog.linkedInstances.remove",defaults:"Remove"}),execute:()=>this.handleUnlink(e),testId:"UnlinkItem"}]}))})),o.createElement(A,null,n,o.createElement(V,{size:"S",icon:o.createElement(d.HkR,null),disabled:this.isReadOnly,onClick:()=>this.handleUnlink(this.props.entityVersion),"data-testid":`${a}_remove`},o.createElement(r.Trans,{id:"entity.linkedInstances.unlink",defaults:"Unlink from related items"}))));return o.createElement(x.Zb,{title:i18n({id:"catalog.linkedInstances.title",defaults:"Linked instances"}),"data-testid":a,tooltip:i18n({id:"catalog.linkedInstances.tooltip",defaults:"If there are other instances of this catalog item, which have a different purpose, add them here."})},this.initialized?s:o.createElement(u.$j,null))}};R.contextType=h.wH;(0,n.gn)([(0,w.Q)((()=>v.v))],R.prototype,"em",void 0);(0,n.gn)([(0,w.Q)((()=>y.d))],R.prototype,"mm",void 0);(0,n.gn)([s.LO],R.prototype,"group",void 0);(0,n.gn)([s.LO],R.prototype,"initialized",void 0);(0,n.gn)([s.Fl],R.prototype,"isReadOnly",null);(0,n.gn)([s.LO],R.prototype,"groupListing",void 0);(0,n.gn)([s.LO],R.prototype,"pickerListing",void 0);R=(0,n.gn)([l.Pi],R)},19597:(e,t,a)=>{"use strict";a.r(t);a.d(t,{SchedulerPartitionEditor:()=>S});var i=a(33948);var n=a.n(i);var r=a(70655);var s=a(29323);var l=a(67294);var o=a(27295);var c=a(22930);var d=a(5013);var u=a(77740);var p=a(78017);var h=a(18350);var m=a(80880);var v=a(82142);var g=a(45548);var y=a(22558);var f=a(77544);var b=a(9190);const E={label:i18n({id:"catalog.scheduler.partitionEditor.noPartition",defaults:"No partition"}),value:null};const w={label:i18n({id:"catalog.scheduler.partitionEditor.latestPartition",defaults:"Latest partition"}),value:b.Pf};const C=({detailController:e})=>{const t=(0,l.useMemo)((()=>new u.P(e)),[]);const[a,i]=(0,l.useState)("loading");(0,l.useEffect)((()=>{const t=async()=>{var t,a,n,r,s;const l=(t=e.parentController.entityVersion)===null||t===void 0?void 0:t._parentGid;if(!l){return i("notAvailable")}const o=g.n.get(y.v);const d=await o.getEntityVersion("catalogItem",l,{version:f.XH.Draft,fetchRules:[{pattern:"./*",enabled:false},{pattern:"./connection/defaultCredential/{name}"}]});const u=(a=d.connection)===null||a===void 0?void 0:(n=a.defaultCredential)===null||n===void 0?void 0:n._gid;if(!u){return i("notAvailable")}const h=g.n.get(v.l);const m=await(0,p.h)(new c.wk(h),{catalogItemId:l,credentialsSelector:{gid:u,publishedVersion:true}});if(m.allErrors.length>0){return i("notAvailable")}i((r=(s=m.data.catalogItem)===null||s===void 0?void 0:s.partitionsInfo)!==null&&r!==void 0?r:[])};t()}),[]);const n=(0,l.useMemo)((()=>{if(typeof a==="string"){return[E]}else{return[E,w,...a.map((e=>({label:e,value:e})))]}}),[a]);const r=(0,l.useMemo)((()=>!e.isEditable),[e]);const s=(0,l.useCallback)((e=>{if(t.editorValue!==e){t.handleEditorChange(e);t.process()}}),[t]);return l.createElement(m.Sp,{"data-testid":e.property.testId},l.createElement(h.V,{required:e.property.isRequired},e.property.displayName),l.createElement(m.OI,null,l.createElement(m.AS,{items:n,initialValue:t.editorValue,disabled:r||a==="notAvailable",onChange:s,hasError:t.showError,isLoading:a==="loading",hasSearch:true})))};let S=class SchedulerPartitionEditor extends((0,o.Bq)({},{detailController:o.T.instanceOf(d.F)})){render(){return l.createElement(C,{detailController:this.props.detailController})}};S=(0,r.gn)([s.Pi],S)},56919:(e,t,a)=>{"use strict";a.d(t,{M:()=>r});var i=a(67294);var n=a(74674);const r=e=>{const{defaultNavigationActionHandler:t}=(0,i.useContext)(n.wH);const a=(0,i.useCallback)((a=>{a.preventDefault();if(e){t.handleTarget({kind:"entity",target:e})}}),[e,t]);return a}},71052:(e,t,a)=>{"use strict";a.d(t,{w:()=>l});var i=a(10716);var n=a(45548);var r=a(9297);var s=a(73791);function l(e,t,a){const l=n.n.get(i.I);const{editorLayout:o}=l.get(r.e,e._.metadata.property);const c=o&&JSON.parse(o);return new s.K(e,c,t,a)}},59446:(e,t,a)=>{"use strict";a.d(t,{x:()=>s});var i=a(45548);var n=a(21610);var r=a(73791);function s(e){const t=i.n.get(n.E);const{currentItem:a}=t;return a instanceof r.K&&a.entityGid!=null&&a.entityGid===e.gid}},27619:(e,t,a)=>{"use strict";a.d(t,{j:()=>ManageDefaultAccess});var i=a(70655);var n=a(22188);var r=a(21610);var s=a(76851);var l=a(67294);var o=a(42413);var c=a(33031);var d=a(33948);var u=a(86359);var p=a(80880);var h=a(29323);var m=a(3997);var v=a(95073);var g=a(48403);var y=a.n(g);var f=a(22558);var b=a(57030);var E=a(40413);var w=a(42903);var C=a(90692);var S=a(81012);const I=(0,S.ZP)(p.xu)`
  background-color: ${e=>e.theme.palette.tertiary.base};
  border-bottom: 1px solid ${e=>e.theme.palette.separate[2]};
`;const x=S.ZP.div`
  cursor: ${e=>e.disabled?"help":"pointer"};
  color: ${e=>e.theme.palette.display[3]};
  ${e=>e.theme.transition.normal("color")};
  opacity: ${e=>e.disabled?.5:1};

  &:hover {
    color: ${e=>e.theme.palette.display.base};
  }
`;var T=a(16583);var P=a(9812);var N=a(45021);var k=a.n(N);var D=a(80828);const L=S.ZP.div`
  border-radius: 50%;
  width: 64px;
  height: 64px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  ${e=>e.theme.margin("M","L",0,0)}
  background-color: white;
`;let M=class ManageDefaultAccessSidebar extends l.Component{constructor(){super(...arguments);this.search="";this.handleSearchInputChange=e=>{this.search=e}}get operationSets(){var e,t;return((e=(t=this.eam)===null||t===void 0?void 0:t.manageAccess.operationSets)!==null&&e!==void 0?e:[]).filter((({id:e})=>{const t=(0,C.S)(this.capabilities,e);if(t.length===1){const e=t[0];if(b.E6.includes(e.id)){return false}}return t.length>0}))}get capabilities(){var e,t;return(e=(t=this.eam)===null||t===void 0?void 0:t.manageAccess.capabilities)!==null&&e!==void 0?e:[]}get identities(){var e,t;return(e=(t=this.eam)===null||t===void 0?void 0:t.manageAccess.assignedRoleIdentities)!==null&&e!==void 0?e:[]}async componentDidMount(){const e=this.props.listing.property.parent;(0,D.h)(this.props.listing.parent.gid,"Expected parent entity to have a GID");const t=this.props.listing.parent.gid;this.entityAncestor=await this.em.getEntity(e,t,{fetchRules:[{pattern:"/",entityVersionExtensions:["ancestor"]}]});(0,n.z)((()=>{this.eam=new E.s(this.entityAncestor,new b.X6(this.entityAncestor,this.nodePath));this.eam.manageAccess.fetchCapabilities()}))}get nodePath(){const e=this.props.listing.parent.metadata.nodePath;if(e!==null&&e!==void 0&&e.endsWith("/")){return e+this.props.listing.property.name}return e+"/"+this.props.listing.property.name}get metadata(){return this.props.listing.entityMetadata}get isTopLevel(){return this.props.listing.parent.gid===m.d.rootGid}get ancestorName(){var e,t;const a=(e=this.entityAncestor)===null||e===void 0?void 0:(t=e.metadata.entity)===null||t===void 0?void 0:t.namingStrategy.displayName;return l.createElement(p.xv,{variant:"bodyMedium"},y()(a))}get entityName(){const e=this.metadata.namingStrategy.displayName;return l.createElement(p.xv,{variant:"bodyMedium"},y()(e))}get entityNamePlural(){const e=this.metadata.namingStrategy.displayNamePlural;return l.createElement(p.xv,{variant:"bodyMedium"},y()(e))}getFilteredIdentities(e){var t;const a=k()(this.search);return(t=this.identities)===null||t===void 0?void 0:t.filter((({grantingStrategy:t,capability:i,identity:n})=>{if(t!==b.xp.GRANT||!i.operationSets.some((t=>t.id===e))){return false}if(!a){return true}if(n.__typename==="Person"){return k()(n.username).includes(a)}if(n.__typename==="GroupRole"){return k()(n.name).includes(a)||n.users.some((e=>e.__typename==="Person"&&k()(e.username).includes(a)))||k()(i.displayName).includes(a)}return false}))}render(){if(!this.eam||!this.entityAncestor){return null}if(this.eam.manageAccess.hasBeenLoaded&&this.operationSets.length===0){return l.createElement(v.C,null,l.createElement(p.Kq,{gap:"M",align:"center"},l.createElement(L,null,l.createElement(c.eKb,{color:"basic"})),l.createElement(p.xv,{variant:"headline2"},l.createElement(u.Trans,{id:"topLevelPermissions.sidebar.emptyState.title",defaults:"Configuration is not available"})),l.createElement(p.xv,{variant:"paragraph"},l.createElement(u.Trans,{id:"topLevelPermissions.sidebar.emptyState.message",defaults:"Default permissions are not configurable for these entities."}))))}return l.createElement(v.C,null,l.createElement(p.Kq,{gap:"M"},l.createElement(p.xv,{variant:"paragraph"},this.isTopLevel?l.createElement(u.Trans,{id:"topLevelPermissions.sidebar.topLevelDescription",defaults:"These settings represent default access for all instances of entity {0}. They are applied to {1} that have been already created and also for new ones.",values:{0:this.entityName,1:this.entityNamePlural}}):l.createElement(u.Trans,{id:"topLevelPermissions.sidebar.midLevelDescription",defaults:"Specify which users will have {0} permissions for the {1} of this {2}. These permissions will apply to all existing {3} of this {4}, as well as any that will be added, and can't be overridden at the {5} level.",values:{0:this.operationSets.map((({displayName:e})=>e)).join(" "),1:this.entityNamePlural,2:this.ancestorName,3:this.entityNamePlural,4:this.ancestorName,5:this.entityName}})),l.createElement(P.H,{value:this.search,onChange:this.handleSearchInputChange,placeholder:"Filter users or groups"}),this.operationSets.map((({displayName:e,id:t,description:a})=>{const i=this.getFilteredIdentities(t);return l.createElement(l.Fragment,{key:t},l.createElement(p.gF,{gap:"S",alignY:"center"},l.createElement(p.xv,{variant:"headline2"},e),l.createElement(p.u,{delay:0,tooltip:a!==null&&a!==void 0?a:e,placement:T.Iw.top},l.createElement(x,null,l.createElement(c.aUG,null)))),l.createElement(p.Kq,null,l.createElement(w.p,{selectedItems:[],onChange:e=>{var a;(a=this.eam)===null||a===void 0?void 0:a.manageAccess.assignSingleIdentity(e[0],t)},testId:"selectGroup_select"},l.createElement(I,{padding:"M",align:"center"},l.createElement(x,{disabled:false},l.createElement(c.SC9,null)))),i===null||i===void 0?void 0:i.map(((e,a)=>{var i;return l.createElement(l.Fragment,{key:a},(i=this.eam)===null||i===void 0?void 0:i.getSidebarRoleItem(e,t))}))))}))))}};(0,i.gn)([(0,s.Q)((()=>m.d))],M.prototype,"mm",void 0);(0,i.gn)([(0,s.Q)((()=>f.v))],M.prototype,"em",void 0);(0,i.gn)([n.Fl],M.prototype,"operationSets",null);(0,i.gn)([n.Fl],M.prototype,"capabilities",null);(0,i.gn)([n.Fl],M.prototype,"identities",null);(0,i.gn)([n.LO],M.prototype,"entityAncestor",void 0);(0,i.gn)([n.LO],M.prototype,"eam",void 0);(0,i.gn)([n.LO],M.prototype,"search",void 0);(0,i.gn)([n.aD],M.prototype,"handleSearchInputChange",void 0);(0,i.gn)([n.aD],M.prototype,"componentDidMount",null);M=(0,i.gn)([h.Pi],M);class ManageDefaultAccessSideBarItem{constructor(e){this.listing=e;this.isDestructive=false;this.hooks={onUnload:new o.O}}get name(){return"Default Access"}get icon(){return l.createElement(c.Ol,null)}get Renderer(){return()=>l.createElement(M,{listing:this.listing})}}(0,i.gn)([n.Fl],ManageDefaultAccessSideBarItem.prototype,"name",null);(0,i.gn)([n.Fl],ManageDefaultAccessSideBarItem.prototype,"icon",null);(0,i.gn)([n.Fl],ManageDefaultAccessSideBarItem.prototype,"Renderer",null);var V=a(16887);var $=a(86676);class ManageDefaultAccess{constructor(e){this.listing=e;this.iconName="key";this.execute=async()=>{this.sidebarManager.push(new ManageDefaultAccessSideBarItem(this.listing))}}static create(e){if(!(e instanceof V.Z)||!e.parent.permissions.canEntity($.f.ManageAccessSettings)){return null}return new ManageDefaultAccess(e)}get displayName(){return"Manage default Access"}get testId(){return"manage-default-access"}}(0,i.gn)([(0,s.Q)((()=>r.E))],ManageDefaultAccess.prototype,"sidebarManager",void 0);(0,i.gn)([n.Fl],ManageDefaultAccess.prototype,"displayName",null);(0,i.gn)([n.Fl],ManageDefaultAccess.prototype,"testId",null)},31802:(e,t,a)=>{"use strict";a.d(t,{V:()=>ShowCreateScreenAction});var i=a(70655);var n=a(22188);var r=a(87625);var s=a(3997);var l=a(16887);var o=a(65793);var c=a(45548);var d=a(76851);var u=a(93097);class ShowCreateScreenAction{constructor(e,t){this.target=e;this.subtype=t;this.displayName="Create";this.link=(0,u.l)(this.target,this.subtype);this.testId="showCreateScreen_action"}static create(e,t={}){var a,i;if(!(e instanceof l.Z)){return null}if((a=t.entityMetadata)!==null&&a!==void 0&&a.hasTrait((0,o.Z)({viewOnly:true}))){return null}const n=t.entityMetadata&&t.entityMetadata.getSuperEntities().length>0?(i=t.entityMetadata)===null||i===void 0?void 0:i.name:undefined;const r=c.n.get(s.d);if(r.isTopLevelProperty(e.property)||e.parent.gid!=null){return new ShowCreateScreenAction(e,n)}return null}get disabled(){var e;if(!this.target.canAddItems){return{reason:i18n({id:"core.actions.create.noPermissions.tooltip",defaults:"You don't have permissions to create an entity"})}}return(e=this.target.parent)===null||e===void 0?void 0:e.hasDeleteDraft}execute(e){const t=(e===null||e===void 0?void 0:e.event.metaKey)||(e===null||e===void 0?void 0:e.event.ctrlKey);this.app.navigate(this.link,t)}}(0,i.gn)([(0,d.Q)((()=>r.g))],ShowCreateScreenAction.prototype,"app",void 0);(0,i.gn)([n.Fl],ShowCreateScreenAction.prototype,"disabled",null)},45151:(e,t,a)=>{"use strict";a.d(t,{_:()=>ShowDetailScreenAction,A:()=>d});var i=a(70655);var n=a(87625);var r=a(4600);var s=a(29715);var l=a(45548);var o=a(76851);var c=a(19965);class ShowDetailScreenAction{constructor(e,t={}){this.target=e;this.ctx=t;this.displayName="Show details";this.link=(0,c.h)(this.target._);this.testId="showDetailScreen_action"}static create(e,t={}){const a=l.n.get(n.g);if(e instanceof r.f&&d(e._)&&a.routeExist((0,c.h)(e._))){return new ShowDetailScreenAction(e,t)}return null}execute(e){var t,a;const i=(e===null||e===void 0?void 0:e.openInNewTab)||(e===null||e===void 0?void 0:(t=e.event)===null||t===void 0?void 0:t.metaKey)||(e===null||e===void 0?void 0:(a=e.event)===null||a===void 0?void 0:a.ctrlKey);this.app.navigate(this.link,i)}}(0,i.gn)([(0,o.Q)((()=>n.g))],ShowDetailScreenAction.prototype,"app",void 0);function d(e){return e.metadata.property.entity.hasTrait((0,s.O)({standaloneAccessible:true}))}},28329:(e,t,a)=>{"use strict";a.d(t,{U:()=>QueryInput});var i=a(33948);var n=a(15306);var r=a(67294);class LinkedListItem{constructor(e,t){this.value=e;this.next=t}}class MarkedIndex{constructor(e=0,t=[]){this.index=e;this.classes=t}}class MarkedRange{constructor(e,t,a){this.start=e;this.end=t;this.classes=a}}function s(e,t){if(Array.isArray(t)){for(const a of t){if(!e.includes(a)){e.push(a)}}}else{if(!e.includes(t)){e.push(t)}}return e}class MarkedRanges{constructor(){this.markRange=(e,t,a)=>{let i=this.list;let n;let r;let l;if(!i){r=new MarkedIndex(e,s([],a));this.list=new LinkedListItem(r);r=new MarkedIndex(t);this.list.next=new LinkedListItem(r);return}while(i&&i.value.index<e){n=i;i=i.next}if(i&&i.value.index===e){s(i.value.classes,a);n=i;i=i.next}else{r=new MarkedIndex(e,s(n?n.value.classes.slice():[],a));l=new LinkedListItem(r,i);if(n){n.next=l}else{this.list=l}n=l;l=undefined}while(i&&i.value.index<t){s(i.value.classes,a);n=i;i=i.next}if(i&&i.value.index===t){return}let o;if(n){o=n.value.classes.slice();o.pop()}else{o=[]}r=new MarkedIndex(t,o);l=new LinkedListItem(r,i);if(n){n.next=l}};this.list=undefined}getRanges(){var e=[],t,a,i;if(this.list){let n=this.list;while(n&&n.next){i=n.value.classes;if(!i.length){n=n.next;continue}t=n.value.index;a=n.next.value.index;n=n.next;e.push(new MarkedRange(t,a,i))}}return e}reset(){this.list=undefined}}var l=a(97450);var o=a(81012);const c=o.ZP.div.attrs({contentEditable:true})`
  ${l.hG};

  white-space: nowrap;
  overflow: hidden;
  text-align: left;
  cursor: text;

  &:before {
    color: ${e=>e.theme.palette.display[3]};
    content: attr(data-placeholder);
  }
`;const d={ENTER:13,Z:90,BRACKET_LEFT:219};function u(e,t){if(!e.textContent||t>e.textContent.length){return null}if(e.nodeType===Node.TEXT_NODE){const a=document.createRange();a.setStart(e,t);return a}if(e.nodeType===Node.ELEMENT_NODE){for(let a=0;a<e.childNodes.length;a++){const i=e.childNodes[a];if(!i.textContent){continue}if(t>i.textContent.length){t-=i.textContent.length}else{return u(i,t)}}}return null}class QueryInput extends r.Component{constructor(e){super(e);this.markedRanges=new MarkedRanges;this.editorRef=r.createRef();this.handleChange=()=>{if(!this.editableElem){return}const e=this.editableElem.textContent;const t=this.editableElem.querySelectorAll("*").length;const a=this.editableElem===document.activeElement;const i=this.findSelectionOffset();if(e===this._txContent&&t===this._numDescendants){return}this.forceHtml();if(a){this.setSelection()}this._setRaw(e,i?i.end:0,a)};this.handleFocus=()=>{this._uxHadFocus=true;setTimeout((()=>{if(!this.editableElem){return}const e=this.findSelectionOffset();this.setState({hasFocus:true,rawCaretPos:e?e.end:0})}),0)};this.handleBlur=()=>{this.setState({hasFocus:false})};this.handleKeyDown=e=>{if(e.keyCode===d.ENTER){e.preventDefault();if(this.props.onEnterKeyDown){const t={event:e,metaKey:e.metaKey,shiftKey:e.shiftKey,clean:this.clean,component:this,raw:this.state.raw};this.props.onEnterKeyDown(t)}}else if(e.metaKey&&e.keyCode===d.Z){e.preventDefault();this._isUndo=true;if(e.shiftKey){this._stepForwardInHistory()}else{this._stepBackInHistory()}}else if(e.keyCode===d.BRACKET_LEFT){e.preventDefault();const t=this.editableElem.textContent||"";const a=this.findSelectionOffset();const i=a?a.start:0;const n=a?a.end:0;const r=t.split("");const s=[...r.slice(0,i),"{",...r.slice(i,n),"}",...r.slice(n)].join("");this.editableElem.textContent=s;this.setState({raw:s,rawCaretPos:n+1})}if(this.props.onKeyDown){this.props.onKeyDown(e)}};const t=e.defaultValue||e.value||"";this.state={clean:"",cleanCaretPos:0,hasFocus:false,raw:t,rawCaretPos:0};this._valueHistory=[t];this._caretHistory=[0];this._historyPos=0;this._txContent=undefined;this._numDescendants=undefined;this._uxInitialValue=t;this._uxHadFocus=false;this._cleanCacheSrc=undefined;this._cleanCacheValue=undefined}get editableElem(){return this.editorRef.current}get clean(){if(this.state.raw===this._cleanCacheSrc){return this._cleanCacheValue}this._cleanCacheSrc=this.state.raw;return this._cleanCacheValue=this.normalizeSpaces(this._cleanCacheSrc)}get raw(){return this.state.raw}_stepBackInHistory(){const e=this._valueHistory.length-1,t=this.state.raw,a=this.state.rawCaretPos;var i,n;while(this._historyPos<e){this._historyPos++;i=this._valueHistory[this._historyPos];n=this._caretHistory[this._historyPos];if(i!==t||n!==a){this._setRaw(i,n,true);return}}}_stepForwardInHistory(){const e=this.state.raw,t=this.state.rawCaretPos;var a,i;while(this._historyPos>0){this._historyPos--;a=this._valueHistory[this._historyPos];i=this._caretHistory[this._historyPos];if(a!==e||i!==t){this._setRaw(a,i,true);return}}}_addToHistory(e,t){const a=100;if(this._historyPos){this._valueHistory.splice(0,this._historyPos);this._caretHistory.splice(0,this._historyPos);this._historyPos=0}this._valueHistory.unshift(e);this._caretHistory.unshift(t);if(a&&this._valueHistory.length>a){this._valueHistory.length=a;this._caretHistory.length=a}}_setRaw(e,t,a){if(this.props.onRawChange){this.props.onRawChange({caret:t,raw:e})}if(!("value"in this.props)){this.setState({hasFocus:a,raw:e,rawCaretPos:t})}else if(!("caret"in this.props)){this.setState({hasFocus:a,rawCaretPos:t})}}_emitUpdate(){if(typeof this.props.onUpdate!=="function"){return}this.props.onUpdate(this.clean)}componentDidMount(){this._uxInitialValue=this.props.defaultValue||this.props.value||"";this.setState({raw:this._uxInitialValue,rawCaretPos:0});this.forceHtml();this._emitUpdate();if(this.props.autofocus){this.handleFocus();this.editableElem.focus()}}shouldComponentUpdate(e,t){return e.placeholder!==this.props.placeholder||t.hasFocus!==this.state.hasFocus||t.raw!==this.state.raw||t.rawCaretPos!==this.state.rawCaretPos}componentDidUpdate(){this.forceHtml();if(this.state.hasFocus&&this.state.rawCaretPos!=null){this.setSelection()}if(this._isUndo){this._isUndo=false}else{this._addToHistory(this.state.raw,this.state.hasFocus?this.state.rawCaretPos:this.state.raw.length)}this._emitUpdate()}render(){const{className:e,placeholder:t,testId:a}=this.props;return r.createElement(c,{className:e,ref:this.editorRef,onBlur:this.handleBlur,onFocus:this.handleFocus,onInput:this.handleChange,onKeyDown:this.handleKeyDown,"data-placeholder":this.clean?"":t,"data-testid":a})}normalizeSpaces(e){const t=e.replace(/^\s+/,"").replace(/\s/g," ").replace(/ {3,}/g,"  ");return t}forceHtml(){if(!this.editableElem){return}const e=this.clean;const t=e.replace(/\s/g," ");const{marker:a}=this.props;this.editableElem.innerHTML="";if(!e){this._txContent=this.editableElem.textContent;this._numDescendants=this.editableElem.childNodes.length;return""}this.markedRanges.reset();a(e,this.markedRanges.markRange);const i=this.markedRanges.getRanges();const n=document.createDocumentFragment();let r=0;for(let e=0;e<i.length;e++){const a=i[e];if(a.start>r){const e=document.createTextNode(t.slice(r,a.start));n.appendChild(e)}const s=document.createElement("span");for(const e of a.classes){s.classList.add(e)}s.textContent=t.slice(a.start,a.end);n.appendChild(s);r=a.end}if(r<e.length){const e=document.createTextNode(t.slice(r));n.appendChild(e)}this.editableElem.appendChild(n);this._txContent=this.editableElem.textContent;this._numDescendants=this.editableElem.querySelectorAll("*").length}findSelectionOffset(){const e=document.getSelection();if(!e){return undefined}const t=e.getRangeAt(0);if(!t){return undefined}let a=t.endContainer;let i=t.endOffset;const n=i-t.startOffset;if(!this.editableElem.contains(a)){return 0}while(a!==this.editableElem){while(a.previousSibling){a=a.previousSibling;if([Node.ELEMENT_NODE,Node.TEXT_NODE].includes(a.nodeType)){i+=a.textContent.length}}a=a.parentNode}return{start:i-n,end:i}}setSelection(){const e=document.getSelection();if(!e){return}const t=this.state.raw.slice(0,this.state.rawCaretPos);let a=u(this.editableElem,this.normalizeSpaces(t).length);if(!a){a=document.createRange();a.selectNodeContents(this.editableElem);a.collapse(false)}e.removeAllRanges();e.addRange(a)}}},46046:(e,t,a)=>{"use strict";a.d(t,{z:()=>C});var i=a(33948);var n=a(70655);var r=a(23279);var s=a.n(r);var l=a(22188);var o=a(29323);var c=a(67294);var d=a(39992);var u=a(97450);var p=a(28329);var h=a(81012);var m;(function(e){e["Bracket"]="rgb(0, 35, 57)";e["Operator"]="rgb(123, 48, 208)";e["System"]="rgb(223, 134, 24)";e["String"]="rgb(164, 65, 133)";e["Number"]="rgb(23, 71, 129)";e["Identifier"]="rgb(47, 134, 210)"})(m||(m={}));const v=h.ZP.div`
  width: 100%;
  position: relative;

  & .aql-token {
    display: inline-block;
  }

  & .aql-error {
    text-decoration: underline solid ${e=>e.theme.palette.error[5]};
  }

  & .aql-bracket {
    color: ${m.Bracket};
  }

  & .aql-operator {
    color: ${m.Operator};
  }

  & .aql-system {
    color: ${m.System};
  }

  & .aql-string {
    color: ${m.String};
  }

  & .aql-number {
    color: ${m.Number};
  }

  & .aql-identifier {
    color: ${m.Identifier};
  }
`;const g=u.Mm;const y=(0,h.ZP)(p.U)`
  /** consider size of the submit button */
  padding-right: ${e=>parseInt(e.theme.symbol.spacing.M)+(e.hasSubmitButton?u.nM:0)}px;
`;var f=a(15458);var b=a(63050);function E(e){return e!=null&&(0,b.n)(e,"originalEvent")}var w;(function(e){e["Open"]="{";e["Close"]="}"})(w||(w={}));let C=class AQLInput extends c.Component{constructor(e){var t;super(e);this.value="";this.lastSubmittedValue="";this.submitChange=e=>{const t=E(e)?e:e===null||e===void 0?void 0:e.event;let a="";const i=this.value.endsWith("!");if(i||this.props.disableFullText){a=this.value}else{if((0,f.m)(this.value,w.Open,w.Close)){a=this.value.substring(1,this.value.length-1)}else if(this.value){a=`$fulltext LIKE ${JSON.stringify(this.value)}`}}if(a===this.lastSubmittedValue){return}if(!a){this.props.onChange("",t);return}const{errors:n}=(0,d.M)(a);if(!n.length||i){this.lastSubmittedValue=a;this.props.onChange(a,t)}else if(!this.props.autoSubmit){var r,s;(r=(s=this.props).onParseError)===null||r===void 0?void 0:r.call(s)}};this.aqlMarker=(e,t)=>{if(this.props.disableFullText||(0,f.m)(e,w.Open,w.Close)){const{tokens:a,errors:i}=(0,d.M)(e);for(const e of[...a,...i]){t(e.start,e.stop+1,["aql-token",(0,f.S)(e.type)])}for(let a=0;a<e.length;a++){const i=e[a];if(["{","}","(",")"].includes(i)){t(a,a+1,["aql-token","aql-bracket"])}}}};this.lastSubmittedValue=(t=e.defaultValue)!==null&&t!==void 0?t:"";this.debouncedSubmitChange=s()(this.submitChange,300,{maxWait:600})}handleChange(e){this.value=e;if(this.props.autoSubmit){this.debouncedSubmitChange(undefined)}}render(){const{defaultValue:e,className:t,inputClassName:a,placeholder:i,autoSubmit:n,onKeyDown:r,autofocus:s}=this.props;return c.createElement(v,{className:t},c.createElement(y,{defaultValue:e,marker:this.aqlMarker,onUpdate:this.handleChange,onEnterKeyDown:this.submitChange,onKeyDown:r,placeholder:i,className:a,hasSubmitButton:!n,autofocus:s}),!n&&c.createElement(g,{"data-testid":"searchButton",onClick:this.submitChange}))}};(0,n.gn)([l.LO],C.prototype,"value",void 0);(0,n.gn)([l.aD.bound],C.prototype,"handleChange",null);C=(0,n.gn)([o.Pi],C)},4626:(e,t,a)=>{"use strict";a.d(t,{z:()=>p});var i=a(33948);var n=a.n(i);var r=a(70655);var s=a(22188);var l=a(29323);var o=a(67294);var c=a(39992);var d=a(6625);var u=a(15458);let p=class AQLInput extends o.Component{constructor(){super(...arguments);this.value="";this.lastSubmittedValue="";this.aqlMarker=(e,t)=>{const{tokens:a,errors:i}=(0,c.M)(e);for(const e of[...a,...i]){t(e.start,e.stop+1,["aql-token",(0,u.S)(e.type)])}for(let a=0;a<e.length;a++){const i=e[a];if(["{","}","(",")"].includes(i)){t(a,a+1,["aql-token","aql-bracket"])}}}}render(){const{defaultValue:e,className:t,placeholder:a,testId:i}=this.props;return o.createElement(d.M,{testId:i,className:t,placeholder:a,defaultValue:e,marker:this.aqlMarker,onUpdate:this.handleChange,onEnterKeyDown:this.submit})}submit(){const e=this.value;if(e===this.lastSubmittedValue){return}if(!e){this.props.onSubmit("");return}const{errors:t}=(0,c.M)(e);const a=e.endsWith("!");if(!t.length||a){this.lastSubmittedValue=e;this.props.onSubmit(e)}else{var i,n;(i=(n=this.props).onParseError)===null||i===void 0?void 0:i.call(n)}}handleChange(e){this.value=e}};(0,r.gn)([s.LO],p.prototype,"value",void 0);(0,r.gn)([s.aD.bound],p.prototype,"submit",null);(0,r.gn)([s.aD.bound],p.prototype,"handleChange",null);p=(0,r.gn)([l.Pi],p)},6625:(e,t,a)=>{"use strict";a.d(t,{M:()=>s});var i=a(28329);var n=a(81012);var r;(function(e){e["Bracket"]="rgb(0, 35, 57)";e["Operator"]="rgb(123, 48, 208)";e["System"]="rgb(223, 134, 24)";e["String"]="rgb(164, 65, 133)";e["Number"]="rgb(23, 71, 129)";e["Identifier"]="rgb(47, 134, 210)"})(r||(r={}));const s=(0,n.ZP)(i.U)`
  width: 100%;
  position: relative;

  & .aql-token {
    display: inline-block;
  }

  & .aql-error {
    text-decoration: underline solid ${e=>e.theme.palette.error[5]};
  }

  & .aql-bracket {
    color: ${r.Bracket};
  }

  & .aql-operator {
    color: ${r.Operator};
  }

  & .aql-system {
    color: ${r.System};
  }

  & .aql-string {
    color: ${r.String};
  }

  & .aql-number {
    color: ${r.Number};
  }

  & .aql-identifier {
    color: ${r.Identifier};
  }
`},15458:(e,t,a)=>{"use strict";a.d(t,{m:()=>i,S:()=>n});function i(e,t,a){let i=0;let n,r;for(let s=0;s<e.length;s++){const l=e[s];if(l===t){if(i===0){n=s}i++}else if(l===a){i--;if(i===0){r=s}}}return n===0&&r===e.length-1}function n(e){switch(e){case"AND":case"OR":case"NOT":case"EQ_OPERATOR":case"NE_OPERATOR":case"NUMBER_OPERATOR":case"STRING_OPERATOR":case"AS":case"IN":return"aql-operator";case"NULL":case"TRUE":case"FALSE":return"aql-system";case"IDENTIFIER":case"SYSTEM_IDENTIFIER":case"META_IDENTIFIER":return"aql-identifier";case"NUMBER":return"aql-number";case"STRING":return"aql-string";default:return"aql-error"}}},26387:(e,t,a)=>{"use strict";a.d(t,{C:()=>n});var i=a(81012);const n=i.ZP.span`
  ${e=>e.theme.padding("XS","S")}
  border-radius: 2px;
  background-color: ${e=>e.theme.palette.separate[2]};
  ${e=>e.theme.font.emphasized()}
`;const r=i.ZP.span`
  width: ${e=>e.theme.symbol.spacing.S};
  ${e=>e.hasInnerMargin?e.theme.margin.right("M"):e.theme.margin.right("S")};
`},7214:(e,t,a)=>{"use strict";a.d(t,{z:()=>I});var i=a(33948);var n=a.n(i);var r=a(70655);var s=a(22188);var l=a(29323);var o=a(67294);var c=a(83812);var d=a(29052);var u=a(90476);var p=a(83183);var h=a(22558);var m=a(16887);var v=a(1121);var g=a(29715);var y=a(80828);var f=a(76851);var b=a(87039);var E=a(51923);var w=a(80880);var C=a(27619);var S=a(61745);let I=class EntityArrayEmbeddedViewWrapper extends o.Component{constructor(){super(...arguments);this.listingView=new v._(this.props.detailController.listing);this.handleAddItem=async()=>{const{detailController:e}=this.props;const{entityMetadata:t,listing:a}=e;(0,y.h)(a instanceof m.Z);const i=a.createDraft();const n=i18n({id:"entity.arrayEmbedded.addingItem",defaults:"Adding {0}",values:{0:t.displayName.toLocaleLowerCase()}});const r=await this.modalManager.show(((t,a)=>o.createElement(b.y,{title:n,entityVersion:i,parentController:e,onAccept:t,onDecline:a,showTypeSelect:true,createAnotherCallback:this.handleAddItem})));if(r.accepted){a.ensureItems({force:true})}}}get pageSize(){return this.listingView.request.getPageSize()}get hierarchyModel(){return E.U.create(this.listingView,this.props.listingHierarchy)}get canAddItems(){const{detailController:{listing:e}}=this.props;if(e instanceof m.Z){if(!e.canAddItems){return false}if(e.parent.hasDeleteDraft){return false}if(e.entityMetadata.hasTrait((0,g.O)({editable:{standalone:false}}))){return false}return true}return false}get actions(){var e;const{listing:t}=this.props.detailController;const a=this.canAddItems&&!t.isEmpty?(e=this.props.actionElement)!==null&&e!==void 0?e:o.createElement(w.zx,{"data-testid":"add_button",onClick:this.handleAddItem},i18n({id:"entity.arrayEmbedded.addItem",defaults:"Add {0}",values:{0:this.entityName}})):null;const i=t instanceof m.Z?C.j.create(t):null;const n=i?o.createElement(S.J,{actions:[i]}):null;return o.createElement(w.gF,{gap:"M",alignY:"center"},a,n)}get entityName(){var e;const{renderController:t,customLabels:a}=this.props;return(e=a===null||a===void 0?void 0:a.entityName)!==null&&e!==void 0?e:t.entity.displayName}render(){var e;const{detailController:t,renderController:a,customLabels:i,isNested:n,emptyStateActionElement:r}=this.props;const s=(e=i===null||i===void 0?void 0:i.title)!==null&&e!==void 0?e:a.property.displayName;const{listing:l}=t;if(!l.isLoading&&l.items.length===0){var d;const e=i===null||i===void 0?void 0:i.emptyListTitle;const l=(d=i===null||i===void 0?void 0:i.emptyListDescription)!==null&&d!==void 0?d:i18n({id:"entity.arrayEmbedded.listingEmpty",defaults:"No {0} have been added yet.",values:{0:a.entity.namingStrategy.displayNamePlural.toLocaleLowerCase()}});return o.createElement(w.Zb,{title:s,action:this.actions,isNested:n,testId:`${t.testId}`},o.createElement(u.a,{title:e,description:l},this.canAddItems&&(r!==null&&r!==void 0?r:o.createElement(w.zx,{"data-testid":"add_button",primary:true,onClick:this.handleAddItem},i18n({id:"entity.arrayEmbedded.emptyPlaceholer.addItem",defaults:"Add {0}",values:{0:this.entityName}})))))}const{listingView:h,hierarchyModel:m}=this;return o.createElement(w.Zb,{title:s,action:this.actions,fullWidthContent:true,isNested:n,testId:`${t.testId}_card`,fullHeightContent:true},this.props.children({detailController:t,hierarchyModel:m,isHierarchical:this.props.listingHierarchy.length>1}),o.createElement(p.G,{isLoading:h.listing.isLoading}),o.createElement(c.D,{pagination:h.pagination,variant:"wide"}))}};(0,r.gn)([(0,f.Q)((()=>d.g))],I.prototype,"modalManager",void 0);(0,r.gn)([(0,f.Q)((()=>h.v))],I.prototype,"entityManager",void 0);(0,r.gn)([s.Fl],I.prototype,"hierarchyModel",null);(0,r.gn)([s.Fl],I.prototype,"canAddItems",null);I=(0,r.gn)([l.Pi],I)},29289:(e,t,a)=>{"use strict";a.d(t,{B:()=>b});var i=a(33948);var n=a.n(i);var r=a(70655);var s=a(22188);var l=a(29323);var o=a(67294);var c=a(87625);var d=a(69614);var u=a(61745);var p=a(33031);var h=a(74674);var m=a(76851);var v=a(45151);var g=a(80880);var y=a(61480);var f=a(42514);let b=class ViewItem extends o.Component{constructor(){super(...arguments);this.handleMouseUp=e=>{if(e.button===1){this.executeRowClick(true)}};this.handleRowClick=e=>{this.executeRowClick(e.metaKey||e.ctrlKey)};this.executeRowClick=e=>{if(this.props.onRowClick){return this.props.onRowClick(this.props.item.item,e)}this.context.defaultNavigationActionHandler.handleTarget({kind:"entity",target:this.props.item.item,openInNewTab:e})};this.handleExpandClick=e=>{e.stopPropagation();this.props.item.toggle&&this.props.item.toggle()};this.handleItemClick=e=>{e.stopPropagation();if(this.props.onItemClick){e.preventDefault();return this.props.onItemClick(this.props.item.item,e.ctrlKey||e.metaKey)}}}get actions(){const{item:e,itemActionsFactory:t}=this.props;return t(e.item)}get isRowClickable(){if(this.props.onRowClick){return true}return this.context.defaultNavigationActionHandler.isAvailable({kind:"entity",target:this.props.item.item})}get isItemClickable(){return this.props.onItemClick||(0,v.A)(this.props.item.item._)}render(){const{item:e,beforeNameContent:t,afterNameContent:a,isHierarchical:i,isHighlighted:n,level:r}=this.props;const{item:s,isExpanded:l,toggle:c}=e;return o.createElement(f.W2,{onClick:this.handleRowClick,onMouseUp:this.handleMouseUp,clickable:this.isRowClickable,level:r,withTogglerPadding:!c&&i,"data-testid":`${s._.metadata.property.testId}_item`,entityVersion:s,isHighlighted:n},o.createElement(f.N,null,o.createElement(y.xJ,{entityVersion:s})),o.createElement(f.VY,null,c&&o.createElement(f.b0,{noOverflow:true},o.createElement(g.Mg,{onClick:this.handleExpandClick,icon:o.createElement(p.CCt,{direction:l?"DOWN":"RIGHT"})})),t&&o.createElement(f.b0,null,t),o.createElement(f.b0,null,o.createElement(f.Dx,{bold:i&&r===0},this.isItemClickable?o.createElement(d.x,{testId:"value",target:s._,onClick:this.handleItemClick},s._displayName):o.createElement("span",{"data-testid":"value"},s._displayName))),a&&o.createElement(f.b0,{grow:true},a)),o.createElement(u.J,{actions:this.actions.actions}))}};b.contextType=h.wH;(0,r.gn)([(0,m.Q)((()=>c.g))],b.prototype,"app",void 0);(0,r.gn)([s.Fl],b.prototype,"actions",null);(0,r.gn)([s.Fl],b.prototype,"isRowClickable",null);(0,r.gn)([s.Fl],b.prototype,"isItemClickable",null);b=(0,r.gn)([l.Pi],b)},42514:(e,t,a)=>{"use strict";a.d(t,{VY:()=>o,N:()=>c,b0:()=>d,W2:()=>u,Dx:()=>p,sc:()=>h});var i=a(2227);var n=a(81012);var r=a(21871);var s=a(3754);const l="36px";const o=n.ZP.div`
  display: flex;
  align-items: center;
  width: 100%;
  position: relative;
  min-width: 0;

  :empty {
    display: none;
  }
`;const c=n.ZP.div`
  position: absolute;
  width: ${e=>e.theme.symbol.spacing.L};
  height: 100%;
  left: 0px;
  overflow: hidden;
`;const d=n.ZP.div`
  display: inline-flex;
  ${e=>e.theme.margin.right("M")};
  overflow: hidden;
  flex-shrink: 1;
  ${e=>e.grow&&`flex-grow: 1`};
  ${e=>e.noOverflow&&n.iv`
      overflow: unset;
    `}
`;const u=n.ZP.div`
  position: relative;
  display: flex;
  justify-content: space-between;
  align-items: center;
  min-height: 44px;
  ${e=>e.theme.padding(0,"L")}

  ${e=>e.theme.font.body()};
  color: ${e=>e.theme.palette.display.base};

  ${e=>e.theme.transition.fast("background-color","border")};
  ${e=>e.centered&&`justify-content: center;`}

  border-bottom: 1px solid transparent;

  &:not(:last-child) {
    border-bottom: 1px solid ${e=>e.theme.palette.separate[2]};
  }

  ${e=>(0,r.n)({backgroundColor:e.entityVersion&&(0,s.O)(e.entityVersion,e.theme),clickable:e.clickable,theme:e.theme,isHighlighted:e.isHighlighted})}

  /* Calculates padding-left for hierarchy level */
  ${e=>{let t="0px";if(e.level){t=(0,i.mA)(`${e.theme.symbol.spacing.XL} * ${e.level}`)}if(e.withTogglerPadding){t=(0,i.mA)(`${t} + ${l}`)}return n.iv`
      ${o} {
        padding-left: ${t};
      }
    `}}
`;const p=n.ZP.div`
  ${e=>e.bold?e.theme.font.emphasized():e.theme.font.regular()}
  ${(0,i.LH)()};
`;const h=n.ZP.span`
  cursor: pointer;
  text-decoration: underline;
  color: ${e=>e.theme.palette.display[7]};

  &:hover {
    color: ${e=>e.theme.palette.interaction[5]};
  }
`},61480:(e,t,a)=>{"use strict";a.d(t,{xJ:()=>p});var i=a(70655);var n=a(29323);var r=a(67294);var s=a(69667);var l=a(81012);var o=a(80880);var c=a(84113);const d=l.ZP.div`
  width: ${e=>e.theme.symbol.spacing.L};
  height: 100%;
`;const u=l.ZP.div`
  width: ${e=>e.theme.symbol.spacing.L};
  height: 100%;
`;let p=class DraftTypeTooltip extends r.Component{render(){const{entityVersion:e}=this.props;return!e._.metadata.getEffectiveEntity().hasTrait((0,s.J)())&&r.createElement(o.u,{tooltip:(0,c.Vi)(e),Wrapper:u},r.createElement(d,null))}};p=(0,i.gn)([n.Pi],p)},87039:(e,t,a)=>{"use strict";a.d(t,{y:()=>k});var i=a(86359);var n=a(70655);var r=a(22188);var s=a(29323);var l=a(67294);var o=a(27023);var c=a(71382);var d=a(3629);var u=a(10943);var p=a(17441);var h=a(94975);var m=a(82142);var v=a(37849);var g=a(3997);var y=a(76851);var f=a(99235);var b=a(10651);var E=a(31310);var w=a(80880);var C=a(16949);var S=a(99966);var I=a(85147);var x=a(81012);const T=x.ZP.div`
  display: flex;
  align-items: center;
  justify-content: start;
`;const P=x.ZP.div`
  display: flex;
  align-items: center;
  justify-content: start;
  ${e=>e.theme.margin.left("M")};
  ${e=>e.theme.margin.right("M")};
`;const N=x.ZP.span.attrs({["data-testid"]:"label"})`
  color: ${e=>e.theme.palette.display.base};
  ${e=>e.theme.margin.left("S")};
`;let k=class EditEntityModal extends l.Component{constructor(e){var t;super(e);this.shouldCreateAnother=false;const{entityVersion:a,parentController:i,onAccept:n,createAnotherCallback:r}=e;this.detailController=new b.m(a,[],i);(t=this.detailController.entityVersion)===null||t===void 0?void 0:t._.hooks.afterSave.tap("EditEntityModal",(e=>{n(e.versions.draft);if(r&&this.shouldCreateAnother){r()}}),true)}get property(){return this.detailController.property}get actions(){var e;const t=this.ws.get(I.V,this.property);return(0,S.Sv)(t,this.props.entityVersion,(e=this.props.ctx)!==null&&e!==void 0?e:{})}async componentDidMount(){const{ctx:e,actionContext:t=h.f.Create}=this.props;const a=this.context.wait();try{this.entityWidget=await this.contextFactory.create({...e,widgetType:f.l9.Editor,actionContext:t,renderController:new E.q(this.property,f.l9.Editor),isNested:true}).resolve(this.getEntityWidget())}catch(e){this.emergencyService.handleError(e);this.props.onDecline()}a()}render(){var e,t;const{entityWidget:a,detailController:n,property:r}=this;const{title:s,onDecline:o,createAnotherCallback:c}=this.props;return l.createElement(w.u_,{size:C.C.wide,testId:`${r.testId}_createModal`,onOverlayClick:o,onEscape:this.props.onDecline},l.createElement(w.u_.Header,{onClose:o},s),l.createElement(w.u_.Content,null,a&&l.createElement(p.W,{applyFocus:!this.context.isLoading&&!this.context.isLoadQueued},a({detailController:n}))),l.createElement(w.u_.Footer,null,l.createElement(T,null,l.createElement(u.y,{primaryAction:(e=this.actions.primaryAction)!==null&&e!==void 0?e:undefined,secondaryAction:(t=this.actions.secondaryAction)!==null&&t!==void 0?t:undefined,actions:this.actions.actions}),c&&l.createElement(P,null,l.createElement(w.RH,{initialValue:this.shouldCreateAnother,onChange:e=>this.shouldCreateAnother=e}),l.createElement(N,null,l.createElement(i.Trans,{id:"entity.editModal.createAnother",defaults:"Create another"}))))))}getEntityWidget(){const e=this.property.getConfig(f.Nv).entityEditorWidget;const t=JSON.parse(e);if((t===null||t===void 0?void 0:t._type)==="entity.entity"){t.blacklist=this.props.propertyBlacklist;t.showTypeSelect=this.props.showTypeSelect}const a=this.props.processWidget?this.props.processWidget(t):t;return a}};k.contextType=o.jV;(0,n.gn)([(0,y.Q)((()=>c.q))],k.prototype,"contextFactory",void 0);(0,n.gn)([(0,y.Q)((()=>m.l))],k.prototype,"apiClient",void 0);(0,n.gn)([(0,y.Q)((()=>d.m))],k.prototype,"emergencyService",void 0);(0,n.gn)([(0,y.Q)((()=>g.d))],k.prototype,"mm",void 0);(0,n.gn)([(0,y.Q)((()=>v.c))],k.prototype,"ws",void 0);(0,n.gn)([r.LO],k.prototype,"entityWidget",void 0);(0,n.gn)([r.Fl],k.prototype,"actions",null);k=(0,n.gn)([s.Pi],k)},76159:(e,t,a)=>{"use strict";a.d(t,{Q:()=>c});var i=a(67294);var n=a(73394);var r=a(17923);var s=a(56919);var l=a(80880);var o=a(4001);const c=({entityVersion:e,customLabel:t,showAncestorBreadcrumbs:a})=>{const c=(0,s.M)(e);const d=e=>{c(e);e.stopPropagation()};return i.createElement(o.om,null,i.createElement(l.Kq,{gap:"S"},i.createElement("div",null,t!==null&&t!==void 0?t:e._displayName),a&&i.createElement(n.O,{disabled:true,items:(0,r.Z)(e._)})),i.createElement(o.BS,{onClick:d}))}},36736:(e,t,a)=>{"use strict";a.d(t,{E:()=>f});var i=a(86359);var n=a(70655);var r=a(23279);var s=a.n(r);var l=a(23560);var o=a.n(l);var c=a(22188);var d=a(29323);var u=a(67294);var p=a(62414);var h=a(1121);var m=a(80880);var v=a(76159);var g=a(4001);const y=10;let f=class EntityPicker extends u.Component{constructor(e){super(e);this.entityVersionToListItem=e=>{var t,a,i,n,r;return{value:e._.gid,label:u.createElement(v.Q,{entityVersion:e,showAncestorBreadcrumbs:this.props.showAncestorBreadcrumbs,customLabel:(t=(a=this.props).labelRenderer)===null||t===void 0?void 0:t.call(a,e)}),testValue:e._displayName,disabled:(i=(n=(r=this.props).isItemDisabled)===null||n===void 0?void 0:n.call(r,e))!==null&&i!==void 0?i:false}};this.ensureMoreItems=()=>{const{listing:e}=this.props;e.ensureItems({startIndex:e.items.length,size:y})};this.handleOpen=async()=>{var e,t;(e=(t=this.props).onOpen)===null||e===void 0?void 0:e.call(t);this.listingView.ensureView()};this.handleClose=()=>{var e,t;(e=(t=this.props).onClose)===null||e===void 0?void 0:e.call(t);if(this.listingView.request.getUserFilter()!=null){this.listingView.request.setUserFilter(null)}};this.handleSearchChange=s()((e=>{const t=e.target.value;const a=this.listingView.request.getUserFilter();if(!a||a.value!==t){this.listingView.request.setUserFilter({type:p.iG.Text,value:t});this.listingView.ensureView()}}),300,{maxWait:600});this.handleSelect=e=>{if(!e){return}const t=this.getItem(e);if(t){this.props.onSelect(t)}};this.handleDeselect=e=>{if(this.props.onDeselect&&this.props.listing){const t=this.getItem(e);if(t){this.props.onDeselect(t)}}};this.listingView=new h._(e.listing)}componentDidUpdate(e){if(e.listing!==this.props.listing){this.listingView=new h._(this.props.listing)}}getItem(e){return this.props.listing.filteredItems.find((t=>t._.gid===e))}get items(){var e;return(e=this.props.listing.filteredItems.map(this.entityVersionToListItem))!==null&&e!==void 0?e:[]}get selectedValues(){var e,t;return(e=(t=this.props.selectedItems)===null||t===void 0?void 0:t.map((e=>e._.gid)).filter((e=>e)))!==null&&e!==void 0?e:[]}get itemsLeft(){return this.props.listing.totalCount-this.props.listing.items.length}render(){const{listing:e,multiselect:t,stretchToContent:a,disabled:n,children:r,zIndex:s,className:l,testId:c,footer:d}=this.props;const p=e.isLoading&&!e.hasBeenLoaded;const h=!e.items.length&&this.listingView.request.getUserFilter()==null;return u.createElement(m.Qb,{disabled:n,items:this.items,selectedValues:this.selectedValues,onSelect:this.handleSelect,onDeselect:this.handleDeselect,hasSearch:true,stretchToContent:a,multiselect:t,isLoading:p,isEmpty:h,onOpen:this.handleOpen,onClose:this.handleClose,searchInputRenderer:({onKeyDown:e})=>u.createElement(g.Mj,{placeholder:"Search",onChange:this.handleSearchChange,onKeyDown:e,autoFocus:true}),footer:({onClose:t})=>u.createElement(u.Fragment,null,e.totalCount>this.items.length?u.createElement(g.VO,null,e.isLoading?u.createElement(u.Fragment,null,u.createElement(g.Q,null),u.createElement(i.Trans,{id:"entity.entityPicker.loadingItems",defaults:"Loading Items..."})):u.createElement(g.rU,{onClick:this.ensureMoreItems},u.createElement(i.Trans,{id:"entity.entityPicker.loadMoreItems",defaults:"Load next {0} items",values:{0:this.itemsLeft<y?this.itemsLeft:y}}))):undefined,o()(d)?d({items:this.items,filter:this.listingView.request.getUserFilter(),isEmpty:h,isLoading:p,onClose:t}):d),zIndex:s,className:l,testId:c},r)}};(0,n.gn)([c.Fl],f.prototype,"items",null);(0,n.gn)([c.Fl],f.prototype,"selectedValues",null);f=(0,n.gn)([d.Pi],f)},4001:(e,t,a)=>{"use strict";a.d(t,{Mj:()=>l,BS:()=>c,om:()=>d,rU:()=>u,VO:()=>p,Q:()=>h});var i=a(33031);var n=a(9009);var r=a(80880);var s=a(81012);const l=(0,s.ZP)(r.II)`
  min-width: 250px;
  border: none;
  outline: none;
  box-shadow: none !important; // NOTE: overload src/ui-kit/components/Input.tsx:32 (&&&)
  padding-left: ${e=>`calc(${e.theme.symbol.spacing.M} + ${e.theme.symbol.spacing.S} + 20px)`};
`;const o=s.ZP.div`
  ${e=>e.theme.padding("S","M")};
  display: flex;
  justify-content: center;
`;const c=(0,s.ZP)(i.oG7)`
  color: ${e=>e.theme.palette.display[3]};
  display: none;
`;const d=s.ZP.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
  &:hover {
    ${c} {
      display: block;
    }
  }
`;const u=s.ZP.div`
  text-decoration: underline;
  cursor: pointer;
  color: ${e=>e.theme.palette.display[7]};
  &:hover {
    color: ${e=>e.theme.palette.interaction[5]};
  }
`;const p=s.ZP.div`
  ${e=>e.theme.padding("S")};
  padding-left: calc(${e=>e.theme.symbol.spacing.L} * 2);
  flex: auto;
  display: flex;
  ${e=>e.theme.font.body("medium")};
  background-color: ${e=>e.theme.palette.tertiary[1]};
`;const h=(0,s.ZP)(n.$j)`
  margin-right: ${e=>e.theme.symbol.spacing.M};
`},18350:(e,t,a)=>{"use strict";a.d(t,{V:()=>r});var i=a(67294);var n=a(80880);const r=({required:e,children:t,link:a})=>{const r=a?({children:e})=>i.createElement(n.rJ,{href:a,target:"_blank"},e):n.VR;return i.createElement(r,null,t,e&&i.createElement(n.a7,null))}},98519:(e,t,a)=>{"use strict";a.d(t,{R:()=>d});var i=a(70655);var n=a(29323);var r=a(67294);var s=a(18350);var l=a(80880);var o=a(81012);const c=o.ZP.div`
  display: inline-flex;
`;let d=class PropertyView extends r.Component{get property(){const{detailController:e}=this.props;return e.property}render(){var e;return r.createElement(l.Md,{"data-testid":`${this.property.testId}_property`},r.createElement(s.V,null,r.createElement(c,null,(e=this.props.displayName)!==null&&e!==void 0?e:this.property.displayName,this.props.tooltip&&r.createElement(l.pf,null,r.createElement(l.u,{tooltip:this.props.tooltip})))),r.createElement(l.OI,null,this.props.children))}};d=(0,i.gn)([n.Pi],d)},45772:(e,t,a)=>{"use strict";a.d(t,{x:()=>g});var i=a(70655);var n=a(95639);var r=a(29323);var s=a(67294);var l=a(34688);var o=a(60678);var c=a(48336);var d=a(35537);var u=a(80880);var p=a(90529);const h=e=>e;const m="••••••••";const v="Empty";let g=class ScalarView extends s.Component{get draft(){const{detailController:e}=this.props;return e.activeVersion!==null?""+e.activeVersion:""}render(){const{detailController:e,transformValue:t=h,disableEmpty:a}=this.props;const i=e.property;const r=this.draft;let g;if(!r&&!a){g=s.createElement("span",{"data-testid":"value"},s.createElement(u.vb,null,v))}else if(r){if(i.dataType instanceof l.V){g=(0,d.u)(t(r))}else if(i.dataType instanceof c.j){g=(0,n.default)(new Date(t(r)),p.Mh)}else{g=t(r)}}if(i.dataType instanceof o.j){g=m}if(!g){return null}return s.createElement("span",null,g)}};g=(0,i.gn)([r.Pi],g)},60328:(e,t,a)=>{"use strict";a.d(t,{h:()=>EntityDefaultValues});var i=a(33948);var n=a.n(i);var r=a(70655);var s=a(41609);var l=a.n(s);var o=a(36968);var c=a.n(o);var d=a(14017);var u=a(3997);var p=a(45234);var h=a(76851);var m=a(56999);var v=a(53536);class EntityDefaultValues{constructor(e){this.entityValueProviders=[];(0,m.Bc)(e.getAllProperties(),{scalar:(e,t)=>{e.valueProviderConfigs.filter((e=>e.type===v.GN.Default)).forEach((e=>{this.entityValueProviders.push({name:e.name,propertyPath:t,fillInCurrentEntity:t.findIndex((e=>e instanceof p.V))===-1})}))}})}ensureAll(){const e=this.entityValueProviders.filter((({name:e})=>!this.valueProvidersService.valueProviders[e].hasBeenLoaded)).map((({name:e})=>this.valueProvidersService.valueProviders[e].ensureItems()));return Promise.all(e)}async getDefaultValues(){await this.ensureAll();const e={};this.entityValueProviders.forEach((t=>{if(t.fillInCurrentEntity){var a;c()(e,t.propertyPath.map((e=>e.name)),(a=this.valueProvidersService.valueProviders[t.name].items[0])===null||a===void 0?void 0:a.value)}}));if(!l()(e)){return e}}}(0,r.gn)([(0,h.Q)((()=>u.d))],EntityDefaultValues.prototype,"metadataManager",void 0);(0,r.gn)([(0,h.Q)((()=>d.s))],EntityDefaultValues.prototype,"valueProvidersService",void 0)},31310:(e,t,a)=>{"use strict";a.d(t,{q:()=>EntityRenderController});var i=a(70655);var n=a(22188);var r=a(27295);var s=a(7367);var l=a(9770);var o=a(99235);const c=r.T.widget({detailController:r.T.instanceOf(l.T)});class EntityRenderController{constructor(e,t,a=0){this.property=e;this.widgetType=t;this.embeddingLevel=a;this.renderers={};this.labels={};this.usedRenderers=[]}get entity(){return this.property.entity}assignRenderers(e){Object.assign(this.renderers,e)}getRenderer(e,t){if(!(e in this.renderers)){const a=this.entity.getPropertyByName(e);if(a){const i=a.getConfig(o.Nv).getWidget(this.widgetType);this.renderers[e]=i===null?null:this.resolveRendererNode(i,e,t)}}return this.renderers[e]}markPropertyAsUsed(e){if(!this.usedRenderers.includes(e)){this.usedRenderers.push(e)}}resolveRendererNode(e,t,a){return c.resolve(e,a.createChild(t).fork({...a.variables,renderController:this.getControllerForProperty(t)}))}getControllerForProperty(e){const t=this.entity.getPropertyByName(e);if(t!==null&&t!==void 0&&t.containsEmbeddedEntity()){return new EntityRenderController(t,this.widgetType,this.embeddingLevel+1)}else{return this}}setLabelForProperty(e,t){this.labels[e]=t}getLabelForProperty(e){return this.labels[e]}}(0,i.gn)([n.LO],EntityRenderController.prototype,"usedRenderers",void 0);(0,i.gn)([s.H],EntityRenderController.prototype,"getControllerForProperty",null)},51923:(e,t,a)=>{"use strict";a.d(t,{U:()=>HierarchyListingModel,Q:()=>s});var i=a(70655);var n=a(22188);var r=a(16887);class IncrementalListing{constructor(e,t){this.listing=e;this.incrementSize=t;this.loadMore=()=>this.listing.ensureItems({startIndex:this.listing.items.length,size:this.incrementSize});this.loadMore()}get hasMore(){return this.listing.totalCount>this.listing.items.length}get items(){return this.listing.items}get isLoading(){return this.listing.isLoading}}(0,i.gn)([n.Fl],IncrementalListing.prototype,"hasMore",null);(0,i.gn)([n.Fl],IncrementalListing.prototype,"items",null);(0,i.gn)([n.Fl],IncrementalListing.prototype,"isLoading",null);function s(e){return e.item===undefined}class HierarchyListingModel{constructor(e,t,a){this.listing=e;this.level=t;this.config=a;this.hierarchyNodes=n.LO.map()}static create(e,t){return new HierarchyListingModel(e,0,t)}get items(){const{listing:e}=this;const t={items:[],level:this.level,isLoading:e instanceof IncrementalListing?e.isLoading:e.listing.isLoading};const a=this.currentLevelConfig;e.items.forEach((e=>{const i=this.hierarchyNodes.get(e);t.items.push({item:e,isExpanded:!!i&&i.isExpanded,level:this.level,toggle:a&&a.childPath?()=>this.toggle(e):undefined,beforeNameContentRenderer:a?a.beforeNameContentRenderer:undefined,afterNameContentRenderer:a?a.afterNameContentRenderer:undefined});if(i!==null&&i!==void 0&&i.isExpanded){t.items.push(i.hierarchy.items)}}));if(e instanceof IncrementalListing&&e.hasMore){t.loadMore=e.loadMore}return t}toggle(e){if(!this.childListingPropName){return}const t=this.hierarchyNodes.get(e);if(t){t.isExpanded=!t.isExpanded}else{this.appendNew(e)}}get currentLevelConfig(){var e;return(e=this.config)===null||e===void 0?void 0:e[this.level]}get childListingPropName(){var e;return(e=this.currentLevelConfig)===null||e===void 0?void 0:e.childPath}appendNew(e){if(!this.childListingPropName){return}const t=e[this.childListingPropName];if(t&&(0,r.N)(t)){this.hierarchyNodes.set(e,{isExpanded:true,hierarchy:new HierarchyListingModel(new IncrementalListing(t._,10),this.level+1,this.config)})}else{throw new Error(`Missing array embedded property ${this.childListingPropName} on entity ${e._.metadata.entity.displayName}`)}}}(0,i.gn)([n.LO],HierarchyListingModel.prototype,"hierarchyNodes",void 0);(0,i.gn)([n.Fl],HierarchyListingModel.prototype,"items",null);(0,i.gn)([n.aD],HierarchyListingModel.prototype,"toggle",null);(0,i.gn)([n.aD],HierarchyListingModel.prototype,"appendNew",null)},77740:(e,t,a)=>{"use strict";a.d(t,{P:()=>PropertyEditorController});var i=a(33948);var n=a.n(i);var r=a(70655);var s=a(23279);var l=a.n(s);var o=a(18446);var c=a.n(o);var d=a(22188);var u=a(42971);var p=a(7367);var h=a(10651);var m=a(62070);var v=a(48661);class PropertyEditorController{constructor(e,t=(e=>e)){var a;this.handleEditorChange=e=>{this.editorValue=e;this.debouncedProcess()};this.process=async()=>{this.touched=true;const e=this.editorValue;const t=this.validate(e);if(t.value!==undefined){this.propertyDetailController.update(t.value);if(this.hasBEOnlyConstraints||this.hasNodePropertyConstraints){const e=this.parentDetailController;if(e instanceof h.m){var a;(a=e.entityVersion)===null||a===void 0?void 0:a._.traits.withTrait(m.c,(e=>e.validate()))}}}if(t.errors){this.clientConstraintViolations=t.errors}else if(this.clientConstraintViolations.length){this.clientConstraintViolations=[]}};this.debouncedProcess=l()(this.process,300,{maxWait:600});this.propertyDetailController=e;this.editorValue=t(e.activeVersion);this.clientConstraintViolations=this.validate(this.editorValue).errors||[];this.touched=Boolean(this.editorValue)||((a=e.parentController.entityVersion)===null||a===void 0?void 0:a._gid)!=null||false}get constraintViolations(){const e=[];const t=this.propertyDetailController.constraintViolations;const a=[...this.constraints,...this.nodePropertyConstraints];for(const i of a){const a=this.clientConstraintViolations.find((e=>e.constraint===i));if(a){e.push(a)}else if(!(0,u.Zy)(i)){const a=t.find((e=>c()(e.constraint,i)));if(a){e.push(a)}}}return e.map((e=>({...e,message:e.constraint.formatMessage(e)})))}get hasConstraintViolation(){return!!this.constraintViolations.length}get showError(){return this.touched&&this.hasConstraintViolation}get constraints(){return this.propertyDetailController.property.constraints}get hasBEOnlyConstraints(){return this.constraints.some((e=>!(0,u.Zy)(e)))}get parentDetailController(){return(0,v.B)(this.propertyDetailController.parentController,(e=>{var t;return e instanceof h.m?Boolean((t=e.entityVersion)===null||t===void 0?void 0:t._parentGid):false}))}get nodePropertyConstraints(){var e,t;const a=(e=this.parentDetailController)===null||e===void 0?void 0:e.entityMetadata;return(t=a===null||a===void 0?void 0:a.constraints.filter(u.rj).filter((({properties:e})=>e.includes(this.propertyDetailController.property.name))))!==null&&t!==void 0?t:[]}get hasNodePropertyConstraints(){return Boolean(this.nodePropertyConstraints.length>0)}get validate(){return(0,u.A3)(this.constraints)}}(0,r.gn)([d.LO],PropertyEditorController.prototype,"editorValue",void 0);(0,r.gn)([d.LO],PropertyEditorController.prototype,"touched",void 0);(0,r.gn)([d.LO],PropertyEditorController.prototype,"clientConstraintViolations",void 0);(0,r.gn)([d.aD],PropertyEditorController.prototype,"handleEditorChange",void 0);(0,r.gn)([d.Fl],PropertyEditorController.prototype,"constraintViolations",null);(0,r.gn)([d.Fl],PropertyEditorController.prototype,"hasConstraintViolation",null);(0,r.gn)([d.Fl],PropertyEditorController.prototype,"showError",null);(0,r.gn)([d.aD],PropertyEditorController.prototype,"process",void 0);(0,r.gn)([p.H],PropertyEditorController.prototype,"validate",null)},93097:(e,t,a)=>{"use strict";a.d(t,{l:()=>s});var i=a(25542);var n=a(3997);var r=a(45548);const s=(e,t,a)=>{const s=r.n.get(n.d);const{property:l,parent:o}=e;return{routeName:i.N.property(l.parent.name,l.name,l.entity.name).create,params:{gid:s.root===l.parent?undefined:o===null||o===void 0?void 0:o.gid,subtype:t,defaultValues:JSON.stringify(a)}}}},48661:(e,t,a)=>{"use strict";a.d(t,{B:()=>i});function i(e,t){if(t(e)){return e}if(!e.parentController){return null}return i(e.parentController,t)}},3754:(e,t,a)=>{"use strict";a.d(t,{O:()=>r});var i=a(53536);var n=a(69667);function r(e,t){if(!e._.metadata.getEffectiveEntity().hasTrait((0,n.J)())){const a=e._draftType;switch(a){case i.dP.New:return t.palette.success;case i.dP.Change:return t.palette.warning;case i.dP.Delete:return t.palette.error;default:if(e._.hasDeepDraft){return t.palette.warning}}}}},25143:(e,t,a)=>{"use strict";a.d(t,{u:()=>r});var i=a(18029);var n=a.n(i);const r=(e,t)=>{const a=e.namingStrategy.displayNamePlural;const i=i18n({id:"entity.emptyState.title",defaults:"No {0}",values:{0:n()(a)}});let r=i18n({id:"entity.emptyState.description.withoutAdd",defaults:"No {0} have been added yet.",values:{0:a.toLocaleLowerCase()}});if(t){r=i18n({id:"entity.emptyState.description.withAdd",defaults:"No {0} have been added yet, add one to get started.",values:{0:a.toLocaleLowerCase()}})}const s=i18n({id:"entity.emptyState.addNewLabel",defaults:"Add {0}",values:{0:n()(e.displayName)}});return{title:i,description:r,addNewLabel:s}}},13242:(e,t,a)=>{"use strict";a.d(t,{p:()=>l,d:()=>o});var i=a(29052);var n=a(22558);var r=a(45548);var s=a(39820);const l=i18n({id:"confirmDeleteModal.title",defaults:"Delete"});async function o(e,t){const a=r.n.get(n.v);const o=r.n.get(i.g);if(await o.confirm({title:l,content:t!==null&&t!==void 0?t:(0,s.M)(e._)?i18n({id:"confirmDeleteModal.message",defaults:"Are you sure you want to delete {0}?",values:{0:e._displayName}}):i18n({id:"confirmDeleteModal.deleteDraft.message",defaults:"The following entity exists only in the draft state. By deleting the draft, you will remove it entirely. Do you want to delete it?"}),confirmButtonLabel:l})){return a.deleteEntities([e._])}}},87204:(e,t,a)=>{"use strict";a.d(t,{o:()=>l});var i=a(97325);var n=a(37849);var r=a(45548);var s=a(47614);const l=e=>t=>{var a;const l=r.n.get(i._f);const o=r.n.get(n.c);const{actions:c=[],secondaryAction:d}=o.get(s.V,t._.metadata.property);return{actions:l.createActionWithConfig(c,t,e),secondaryAction:(a=d&&l.createActionWithConfig(d,t,e))!==null&&a!==void 0?a:undefined}}},40413:(e,t,a)=>{"use strict";a.d(t,{s:()=>EntityAccessManager});var i=a(86359);var n=a(70655);var r=a(67294);var s=a(68311);var l=a(39272);var o=a(29052);var c=a(33031);var d=a(97354);var u=a(3997);var p=a(86676);var h=a(76851);var m=a(57030);var v=a(27078);var g=a(80880);var y=a(16583);var f=a(43642);var b=a(90692);var E=a(1659);var w=a(18446);var C=a.n(w);var S=a(22558);var I=a(73791);var x=a(21610);class EntityAccessManager{constructor(e,t){this.entity=e;this.unassignRole=async(e,t)=>{const a=await this.modalManager.confirm({title:i18n({id:"access.remove.title",defaults:"Remove"}),content:i18n({id:"access.remove.content",defaults:"Remove {0} from {1}?",values:{0:(0,v.O2)(e),1:t.displayName}}),confirmButtonLabel:i18n({id:"access.remove.button",defaults:"Remove"})});const i=(0,v.tN)(e)?{users:[e]}:{roles:[e]};if(a){await this.manageAccess.processAssignment(false,{capabilities:[t],grantingStrategy:m.xp.GRANT,...i})}};this.revokeRole=async(e,t)=>{let a="";const i=this.manageAccess.assignedRoleIdentities.find((t=>(0,v.Bf)(e,t.identity)));if(i){const e=this.metadataManager.getEntityMetadataForNodePath(i.source.nodePath);if(e){a=i18n({id:"access.role.inheritedFrom",defaults:"from {0}",values:{0:e.namingStrategy.displayName}})}}if(a){a=` ${a}`}const n=await this.modalManager.confirm({title:i18n({id:"access.revoke.title",defaults:"Revoke"}),content:i18n({id:"access.revoke.content",defaults:"{0} inherited {1} role{inheritanceInfo}. Do you want to revoke it for this item?",values:{0:(0,v.O2)(e),1:t.displayName,inheritanceInfo:a}}),confirmButtonLabel:i18n({id:"access.revoke.button",defaults:"Revoke"})});const r=(0,v.tN)(e)?{users:[e]}:{roles:[e]};if(n){await this.manageAccess.processAssignment(true,{capabilities:[t],grantingStrategy:m.xp.REVOKE,...r})}};this.restoreRole=async(e,t)=>{const a=await this.modalManager.confirm({title:i18n({id:"access.restore.title",defaults:"Restore access"}),content:i18n({id:"access.restore.content",defaults:"Restore access of {0} for {1}?",values:{0:(0,v.O2)(e),1:t.displayName}}),confirmButtonLabel:i18n({id:"access.restore.button",defaults:"Restore"})});const i=(0,v.tN)(e)?{users:[e]}:{roles:[e]};if(a){await this.manageAccess.processAssignment(false,{capabilities:[t],grantingStrategy:m.xp.REVOKE,...i})}};this.manageAccess=t||this.entity.traits.withTrait(m.X6,(e=>e))}get canManageAccess(){return this.entity.permissions.canEntity(p.f.ManageAccessSettings)}getSuperPropertyNameByNodePath(e){const t=this.metadataManager.getEntityMetadataForNodePath(e);return t?t.namingStrategy.displayName:null}getInheritedIcon(e){const{source:t}=e;const a=this.getSuperPropertyNameByNodePath(t.nodePath);if(a){const e=r.createElement(i.Trans,{render:"span",id:"access.role.inherited",defaults:"This role is inherited from <0>{superPropertyName}</0>.",values:{superPropertyName:a},components:[r.createElement("strong",null)]});return r.createElement(g.u,{delay:0,placement:y.Iw.top,tooltip:e},r.createElement(f.JO,null,r.createElement(c.A8v,null)))}return null}isOwnerAndCurrentUser(e){var t,a;const i=`USER:${(t=this.currentUserProvider.currentUser)===null||t===void 0?void 0:t.id}`;return e.capability.operationSets.some((({name:e})=>e==="owner"))&&((0,v.Zg)(e.identity)&&((a=this.currentUserProvider.currentUser)===null||a===void 0?void 0:a.roles.includes(e.identity.name))||(0,v.tN)(e.identity)&&e.identity.id===i)}shouldPreventUnassign(e){if(!this.isOwnerAndCurrentUser(e)){return false}const t=this.manageAccess.assignedRoleIdentities.some((t=>!C()(e,t)&&this.isOwnerAndCurrentUser(t)));return!t}getRoleAction(e,t,a,i){if(!this.canManageAccess||!t.capability){return r.createElement(f.aH,null)}const{identity:n,capability:s}=t;if(e){return r.createElement(r.Fragment,null,(i===null||i===void 0?void 0:i.source.gid)==this.entity.gid?r.createElement(g.hU,{"data-testid":"restoreRoleButton",onClick:e=>{e.stopPropagation();this.restoreRole(n,s)}},r.createElement(d.t,null)):r.createElement(g.u,{delay:0,placement:y.Iw.top,tooltip:i18n({id:"access.restore.prohibit",defaults:'You can restore access only on a parent entity "{0}"',values:{0:i&&this.getSuperPropertyNameByNodePath(i.source.nodePath)}})},r.createElement(f.JO,{disabled:true},r.createElement(d.t,null))))}const l=this.shouldPreventUnassign(t);if(!a&&!l){return r.createElement(g.hU,{"data-testid":"unassignRoleButton",onClick:e=>{e.stopPropagation();this.unassignRole(n,s)}},r.createElement(c.XSZ,null))}}getAvatar(e,t){const{identity:a}=t;return e?r.createElement(f.lY,null):(0,v.tN)(a)?r.createElement(s.Y,{user:a,showInitials:true}):r.createElement(f.NS,{type:f.t_.Role})}getRoleItem(e){var t;const{identity:a,capability:n,source:s}=e;const l=(0,v.FB)(s,(t=this.entity.gid)!==null&&t!==void 0?t:"");const o=this.manageAccess.assignedRoleIdentities.find((e=>n.id===e.capability.id&&"name"in e.identity&&"name"in a&&a.name===e.identity.name&&e.grantingStrategy===m.xp.REVOKE));const c=Boolean(o);const d=(0,v.e5)(a);return r.createElement(g.u,{disabled:!c,key:`${(0,v.e5)(a)}-${n.id}-${s.gid}`,delay:0,placement:y.Iw.bottom,tooltip:i18n({id:"access.revoked",defaults:"The access for this item was revoked. Originally, {0} inherited {1} role from {2}. ",values:{0:(0,v.O2)(a),1:n.displayName,2:this.getSuperPropertyNameByNodePath(s.nodePath)}})},r.createElement(f.cG,{key:`${d}-${n.id}`,"data-testid":`${d}_roleItem`,isRevoked:c},r.createElement(f.mw,null,this.getAvatar(c,e)),r.createElement(f.Hp,null,r.createElement(f.GW,null,(0,v.O2)(a,true,this.authService.currentUser)),r.createElement(g.u,{delay:0,placement:y.Iw.bottom,tooltip:n.description,Wrapper:f.c4},r.createElement(f.Fq,null,r.createElement(i.Trans,{id:"access.capabilityName.as",defaults:"as {0}",values:{0:n.displayName}})))),l&&r.createElement(f.VJ,null,this.getInheritedIcon(e)),r.createElement(f.ol,null,r.createElement(f.A$,null,this.getRoleAction(c,e,l,o)))))}getCapabilityOptions(e,t){return(0,b.S)(this.manageAccess.capabilities,e).map((e=>({value:e,label:r.createElement(g.gF,{flexGrow:true,gap:"M"},r.createElement(g.tp,{flexGrow:true},r.createElement(g.xv,null,e.displayName)),r.createElement(c.aUG,null)),disabled:t.id===e.id,tooltip:e.description})))}getSidebarRoleItem(e,t){var a;const{identity:n,capability:s,source:l}=e;const o=(0,v.FB)(l,(a=this.entity.gid)!==null&&a!==void 0?a:"");const d=this.manageAccess.assignedRoleIdentities.find((e=>s.id===e.capability.id&&"name"in e.identity&&"name"in n&&n.name===e.identity.name&&e.grantingStrategy===m.xp.REVOKE));const u=async()=>{if((0,v.Zg)(e.identity)){const t=await this.entityManager.getEntityVersion("role",e.identity.gid);this.sidebarManager.push(new I.K(t))}};const p=Boolean(d);const h=(0,v.e5)(n);return r.createElement(g.u,{disabled:!p,key:`${(0,v.e5)(n)}-${s.id}`,delay:0,placement:y.Iw.bottom,tooltip:i18n({id:"access.revoked",defaults:"The access for this item was revoked. Originally, {0} inherited {1} role from {2}. ",values:{0:(0,v.O2)(n),1:s.displayName,2:this.getSuperPropertyNameByNodePath(l.nodePath)}})},r.createElement(f.cG,{key:`${h}-${s.id}`,"data-testid":`${h}_roleItem`,isRevoked:p,onClick:u,isAccionable:(0,v.Zg)(e.identity)},r.createElement(f.mw,null,this.getAvatar(p,e)),r.createElement(f.Hp,null,r.createElement(f.GW,null,(0,v.O2)(n,true,this.authService.currentUser)),this.shouldPreventUnassign(e)?r.createElement(i.Trans,{id:"access.capabilityName.as",defaults:"as {0}",values:{0:s.displayName}}):r.createElement(g.Qb,{items:this.getCapabilityOptions(t,s),multiselect:false,selectedValues:[],onSelect:e=>{this.manageAccess.unassignSingleIdentity(n,s);this.manageAccess.assignSingleIdentity(n,e)},stretchToContent:true,onClick:e=>{e.stopPropagation()}},r.createElement(f.Ac,null,r.createElement(g.gF,{gap:"S"},r.createElement(i.Trans,{id:"access.capabilityName.as",defaults:"as {0}",values:{0:s.displayName}}),r.createElement(c.BDo,null))))),o&&r.createElement(f.VJ,null,this.getInheritedIcon(e)),r.createElement(f.ol,null,r.createElement(f.A$,null,this.getRoleAction(p,e,o,d)))))}}(0,n.gn)([(0,h.Q)((()=>o.g))],EntityAccessManager.prototype,"modalManager",void 0);(0,n.gn)([(0,h.Q)((()=>u.d))],EntityAccessManager.prototype,"metadataManager",void 0);(0,n.gn)([(0,h.Q)((()=>S.v))],EntityAccessManager.prototype,"entityManager",void 0);(0,n.gn)([(0,h.Q)((()=>x.E))],EntityAccessManager.prototype,"sidebarManager",void 0);(0,n.gn)([(0,h.Q)((()=>l.e))],EntityAccessManager.prototype,"authService",void 0);(0,n.gn)([(0,h.Q)((()=>E.M))],EntityAccessManager.prototype,"currentUserProvider",void 0)},43468:(e,t,a)=>{"use strict";a.d(t,{O:()=>c});var i=a(67294);var n=a(80880);var r=a(81012);const s=r.ZP.div`
  ${n.Cl};
  display: flex;
  height: 40px;
`;const l=r.ZP.input`
  ${n.r$};
  width: 100%;
  min-width: 0;
  border: none;
  margin: 0;
  ${e=>e.theme.padding(0,"XS",0,0)};

  outline: none;
`;const o=r.ZP.div`
  width: fit-content;
  ${e=>e.theme.font.body()};
  color: ${e=>e.theme.palette.display[3]};
  padding-left: 0;
  white-space: nowrap;
  display: flex;
  align-items: center;
`;const c=({units:e,hasError:t,disabled:a,testId:n,...r})=>i.createElement(s,{disabled:a,hasError:t},i.createElement(l,Object.assign({disabled:a,"data-testid":n},r)),e&&i.createElement(o,null,e))},16603:(e,t,a)=>{"use strict";a.d(t,{f:()=>AddTerm});var i=a(67294);var n=a(33031);var r=a(21471);var s=a(81012);const l=s.ZP.div`
  ${e=>e.theme.padding("XXS","S")};
  border: 1px solid ${e=>e.theme.palette.separate[2]};
  border-radius: 2px;
  display: inline-flex;
  align-items: center;
  color: ${e=>e.theme.palette.display.base};
  cursor: ${e=>e.disabled?"not-allowed":"pointer"};
`;const o=(0,s.ZP)(n.TVD)`
  ${e=>e.theme.margin("-XXS","XS","-XXS","-XS")}
  color: ${e=>e.theme.palette.display.base};
`;class AddTerm extends i.Component{render(){const{disabled:e}=this.props;return i.createElement(l,{disabled:e,"data-testid":"term_add"},i.createElement(o,null),i.createElement(r.Q$,null,this.props.children||"Add"))}}},4141:(e,t,a)=>{"use strict";a.d(t,{q:()=>u});var i=a(33948);var n=a.n(i);var r=a(70655);var s=a(29323);var l=a(67294);var o=a(4600);var c=a(13242);var d=a(77924);let u=class TermInstance extends l.Component{constructor(){super(...arguments);this.handleRemoveTerm=()=>{if(this.props.onRemove){return this.props.onRemove(this.props.termInstance)}(0,c.d)(this.props.termInstance)}}render(){const{termInstance:e,onClick:t,isRemovable:a}=this.props;return l.createElement(d.O,{term:e.target,isDeleteDraft:e._draftType===o.d.Delete,onClick:t,onRemove:a?this.handleRemoveTerm:undefined})}};u=(0,r.gn)([s.Pi],u)},17828:(e,t,a)=>{"use strict";a.d(t,{Y:()=>B});var i=a(33948);var n=a(15306);var r=a(70655);var s=a(86359);var l=a(22188);var o=a(29323);var c=a(67294);var d=a(21610);var u=a(22558);var p=a(77544);var h=a(3997);var m=a(4600);var v=a(80828);var g=a(76851);var y=a(71052);var f=a(36736);var b=a(60328);var E=a(13242);var w=a(204);var C=a(16603);var S=a(81012);var I=a(80880);var x=a(33031);const T=S.ZP.button`
  width: 100%;
  ${e=>e.theme.font.body("medium")};
  cursor: pointer;
  ${e=>e.theme.margin("S",0)};

  :hover {
    background-color: ${e=>e.theme.palette.separate[1]};
  }
`;const P=(0,S.ZP)(x.N_R)`
  display: block;
  color: ${e=>e.theme.palette.display[3]};
`;const N=({name:e,onClick:t})=>c.createElement(T,{onClick:t},c.createElement(I.xu,{padding:"M",paddingY:"S"},c.createElement(I.gF,{alignY:"center",gap:"S"},c.createElement(P,null),e?c.createElement(s.Trans,{id:"glossary.CreateTerm.create",defaults:"Create"}):c.createElement(s.Trans,{id:"glossary.CreateTerm.create.noName",defaults:"Create new term"}),e&&c.createElement(I.Vp,{label:e}))));var k=a(4141);var D=a(2500);var L=a(50516);var M=a(92708);var V=a(74274);async function $(e){var t;const a=(t=e.target)===null||t===void 0?void 0:t._displayName;await(0,E.d)(e,i18n({id:"DeleteProfilingTermInstanceModal.message",defaults:'Are you sure you want to delete {termName}? Deleting detected term will turn off automatic detection of term "{termName}" on this attribute',values:{termName:a}}))}var A=a(21471);const F=S.ZP.div`
  display: flex;
  flex-wrap: wrap;
  align-items: center;

  & > * {
    ${e=>e.theme.margin("XS",0)};
  }

  & > ${A.W2}:not(:last-child) {
    margin-right: ${A.ES}px;
  }
`;const R=S.ZP.div`
  ${e=>e.theme.margin.right("S")};
`;const _=S.ZP.span`
  ${e=>e.theme.font.regular()};
  color: ${e=>e.theme.palette.display[3]};
`;var O=a(25108);let B=class TermInstancesTags extends c.Component{constructor(){super(...arguments);this.reactKeys=new w.U;this.pickerListing=(()=>{var e;const t=(e=this.props.termInstances._.property.entity.getPropertyByName("target"))===null||e===void 0?void 0:e.entity;(0,v.h)(t);return this.entityManager.createMultiParentListing(t,{version:p.XH.LatestPublished})})();this.handleAddTerm=async(e,t)=>{const a=this.props.termInstances._.appendNewItem({target:e,suggestion:t});const i=t?V.BO:V.Nr;const n=this.metadataManager.getEntityMetadataByName(i);O.assert(n,`Entity ${i} was expected to exist`);if(n){a._.metadata.setEntity(n)}await this.entityManager.saveEntity(this.props.termInstances._.parent);if(t&&this.props.termSuggestions){await this.props.termSuggestions._.ensureItems()}};this.handleRemoveTermInstance=e=>{this.props.termInstances._.filteredItems.filter((t=>t.target._.gid===e._.gid)).forEach((e=>(0,E.d)(e)))};this.handleOnHideTerm=async e=>{var t;if(((t=e._.metadata.entity)===null||t===void 0?void 0:t.name)!==V.uE){return(0,E.d)(e)}(0,v.h)(this.props.hiddenTermInstances,"hiddenTermInstances property missing");await $(e);if(e._draftType!==m.d.Delete){return}this.props.hiddenTermInstances._.appendNewItem(e);await this.entityManager.saveEntity(this.props.hiddenTermInstances._.parent)};this.fetchMoreTerms=()=>{const{termInstances:e,termSuggestions:t}=this.props;if(this.moreTermInstancesCount>0){e._.ensureItems({startIndex:e.length,size:10})}if(t&&this.moreTermSuggestionsCount>0){t._.ensureItems({startIndex:t.length,size:10})}};this.handleTermCreated=async e=>{await this.entityManager.publishEntity(e._);this.sidebarManager.pop();this.handleAddTerm(e)};this.handleCreateTerm=async(e,t)=>{if(this.props.disabled||!this.props.allowCreatingTerms){return}const a=await this.entityManager.getEntity("metadata",h.d.rootGid,{fetchRules:[{pattern:`./*`,enabled:false},{pattern:`./terms`}]});const i=a.metadata.getPropertyByName("terms");const n=a.createChildDraft(i);const r=n._;const s=r.metadata.getEffectiveEntity();const l=await new b.h(s).getDefaultValues();if(l){r.update(l)}if(t!=null){r.updateAt(["name"],t)}e();return this.sidebarManager.push((0,y.w)(n,this.handleTermCreated))}}get moreTermInstancesCount(){const{termInstances:e}=this.props;return e._.totalCount-e.length}get moreTermSuggestionsCount(){const{termSuggestions:e}=this.props;return e?e._.totalCount-e.length:0}get moreTermsCount(){return this.moreTermInstancesCount+this.moreTermSuggestionsCount}get selectedTerms(){var e;return[...this.props.termInstances._.allItems,...((e=this.props.termSuggestions)===null||e===void 0?void 0:e._.allItems)||[]].map((e=>e.target)).filter(Boolean)}get activeTermNodes(){return this.props.termInstances._.allItems.map((e=>({term:e.target,node:c.createElement(k.q,{key:this.reactKeys.keyFor(e),termInstance:e,isRemovable:!this.props.disabled,onRemove:this.props.hiddenTermInstances?this.handleOnHideTerm:undefined})})))}get activeTermSuggestionNodes(){const e=this.props.termSuggestions?this.props.termSuggestions._.filteredItems.filter((e=>e.status===M.S.Pending&&!!e.target.name)):[];return(!this.props.disabled||this.props.forcedAllowSuggestion)&&e.length>0?e.map((e=>({term:e.target,node:c.createElement(M.o,{key:this.reactKeys.keyFor(e),termSuggestion:e,onApprove:this.handleAddTerm}),suggestion:true}))):[]}render(){const{termInstances:e,termSuggestions:t,allowCreatingTerms:a,disabled:i}=this.props;if(this.props.showEmptyState&&this.props.disabled&&this.selectedTerms.length===0){return c.createElement(_,null,c.createElement(s.Trans,{id:"glossary.termInstances.empty",defaults:"No terms assigned"}))}return this.props.oneRow?c.createElement(L.z,{isTableCell:this.props.isTableCell,termNodes:[...this.activeTermNodes,...this.activeTermSuggestionNodes],totalCount:e._.totalCount+(t&&t._.totalCount>0?t._.totalCount:0),forceFirstTermVisible:this.props.forceFirstTermVisible,onLoadMore:this.fetchMoreTerms}):c.createElement(F,null,this.activeTermNodes.map((e=>e.node)),this.activeTermSuggestionNodes.map((e=>e.node)),this.moreTermsCount>0&&c.createElement(R,null,c.createElement(D.y,{shownTermsBefore:false,termNumber:this.moreTermsCount,onClick:this.fetchMoreTerms})),!this.props.disabled&&c.createElement(f.E,{listing:this.pickerListing,selectedItems:this.selectedTerms,multiselect:true,onSelect:this.handleAddTerm,onDeselect:this.handleRemoveTermInstance,stretchToContent:true,footer:({filter:e,isEmpty:t,onClose:n})=>{if(!i&&a){if(e!=null){const t=e.value.replace(/^[^"]*"([^"]+)".*/g,"$1");return c.createElement(N,{onClick:()=>this.handleCreateTerm(n,t),name:t})}else if(t){return c.createElement(N,{onClick:()=>this.handleCreateTerm(n)})}}}},c.createElement(C.f,null,c.createElement(s.Trans,{id:"glossary.termInstances.add",defaults:"Add Term"}))))}};(0,r.gn)([(0,g.Q)((()=>h.d))],B.prototype,"metadataManager",void 0);(0,r.gn)([(0,g.Q)((()=>u.v))],B.prototype,"entityManager",void 0);(0,r.gn)([(0,g.Q)((()=>d.E))],B.prototype,"sidebarManager",void 0);(0,r.gn)([l.Fl],B.prototype,"moreTermInstancesCount",null);(0,r.gn)([l.Fl],B.prototype,"moreTermSuggestionsCount",null);(0,r.gn)([l.Fl],B.prototype,"moreTermsCount",null);(0,r.gn)([l.Fl],B.prototype,"selectedTerms",null);(0,r.gn)([l.aD],B.prototype,"handleAddTerm",void 0);(0,r.gn)([l.aD],B.prototype,"handleOnHideTerm",void 0);(0,r.gn)([l.Fl],B.prototype,"activeTermNodes",null);(0,r.gn)([l.Fl],B.prototype,"activeTermSuggestionNodes",null);B=(0,r.gn)([o.Pi],B)},2500:(e,t,a)=>{"use strict";a.d(t,{y:()=>TermNumberBadge});var i=a(67294);var n=a(91577);var r=a(81012);const s=r.ZP.div`
  display: inline-flex;
  align-items: center;
  border-radius: 16px;
  border: ${e=>e.theme.border.separate};
  padding: 2px 8px;
  ${e=>e.theme.font.captionMedium()};
  color: ${e=>e.theme.palette.display.base};
  font-weight: 500;
  background: ${e=>e.theme.palette.tertiary.base};
  white-space: nowrap;
  ${e=>e.hasMarginLeft&&e.theme.margin.left("S")}
  cursor: pointer;
`;const l=r.ZP.div`
  ${e=>e.theme.margin.left("XS")};
  display: flex;
`;class TermNumberBadge extends i.Component{render(){const{termNumber:e,colors:t=[],shownTermsBefore:a=false,onClick:r}=this.props;return i.createElement(s,{hasMarginLeft:a,onClick:r},i.createElement("div",null,`+ ${e}`),t.map(((e,t)=>i.createElement(l,{key:`${e}_${t}`},i.createElement(n.o,{color:e})))))}}},50516:(e,t,a)=>{"use strict";a.d(t,{z:()=>f});var i=a(33948);var n=a.n(i);var r=a(70655);var s=a(22188);var l=a(29323);var o=a(67294);var c=a(91033);var d=a(2500);var u=a(21471);var p=a(83786);var h=a(81012);var m=a(16583);var v=a(88217);const g=57;let y=class TermsOverflowInner extends o.Component{constructor(){super(...arguments);this.parentContainerRef=o.createRef();this.termsContainerRef=o.createRef();this.shownTerms=[...this.props.termNodes];this.hiddenTerms=[];this.oldContainerWidth=0;this.firstTermDidntFit=false;this.overflowState="init";this.termInstanceElementsWidth=new WeakMap;this.splitTerms=()=>{if(this.parentContainerRef.current){this.overflowState="pending";const{forceFirstTermVisible:e,termNodes:t,isTableCell:a,maxWidth:i}=this.props;this.shownTerms=[];this.hiddenTerms=[];const n=a?i:this.parentContainerRef.current.offsetWidth;const r=n-(t.length>1?g:0);let s=0;t.forEach(((n,l)=>{s+=l===t.length-1?this.termInstanceElementsWidth.get(n):this.termInstanceElementsWidth.get(n)+u.ES;const o=a?s<=r&&s<=i:s<=r;if(o){this.shownTerms.push(n)}else{if(e&&l===0){this.shownTerms.push(n);this.firstTermDidntFit=true}else{this.hiddenTerms.push(n)}}}))}};this.calculateTermInstanceElementsWidth=()=>{var e;const{termNodes:t}=this.props;const a=(e=this.termsContainerRef.current)===null||e===void 0?void 0:e.children;t.forEach(((e,t)=>{var i,n,r;const s=a===null||a===void 0?void 0:a[t];if(!s){return}this.termInstanceElementsWidth.set(e,(i=s===null||s===void 0?void 0:(n=s.children)===null||n===void 0?void 0:(r=n[0])===null||r===void 0?void 0:r.offsetWidth)!==null&&i!==void 0?i:0)}))};this.handlePopupClick=e=>e.stopPropagation()}cutShownTerm(){const e=!this.props.forceFirstTermVisible;if(this.shownTerms.length>(e?0:1)){this.hiddenTerms.push(this.shownTerms.pop())}}get termsColors(){const e=[];for(const t of this.hiddenTerms){const a=!t.suggestion?(0,p.q)(t.term):h.KQ.palette.display[3];if(a&&!e.includes(a)){e.push(a)}if(e.length===3){break}}return e.sort()}equilibriumReached(){const{clientWidth:e,scrollWidth:t}=this.termsContainerRef.current;return t<=e+1||this.shownTerms.length===0}componentDidMount(){this.resizeObserver=new c.Z((()=>{window.requestAnimationFrame((()=>{this.calculateTermInstanceElementsWidth();this.splitTerms()}))}));this.resizeObserver.observe(this.parentContainerRef.current)}componentWillUnmount(){this.resizeObserver.disconnect()}componentDidUpdate(e){const t=this.termsContainerRef.current.offsetWidth;if(e.termNodes!==this.props.termNodes||this.overflowState=="equilibrium"&&this.oldContainerWidth!=t){this.shownTerms=[...this.props.termNodes];this.firstTermDidntFit=false;this.overflowState="init"}else if(this.overflowState==="init"){this.calculateTermInstanceElementsWidth();this.splitTerms()}else if(this.overflowState==="pending"){if(this.equilibriumReached()){this.oldContainerWidth=t;this.overflowState="equilibrium"}else{this.cutShownTerm()}}}render(){const{termNodes:e,totalCount:t,onLoadMore:a,forceFirstTermVisible:i,align:n,displayOverflownColors:r=true}=this.props;const s=i&&this.firstTermDidntFit;const l=o.createElement(v.GI,{onClick:this.handlePopupClick},this.hiddenTerms&&this.hiddenTerms.map((e=>o.createElement(v.RT,{key:e.term._gid},e.node))),t-e.length>0&&o.createElement(d.y,{termNumber:t-e.length,onClick:a}));return o.createElement(v.W2,{ref:this.parentContainerRef,align:n,hidden:this.overflowState!=="equilibrium"},o.createElement(v.XD,{ref:this.termsContainerRef,firstTermForced:s,align:n},this.shownTerms.map((e=>o.createElement(o.Fragment,{key:e.term._gid},e.node)))),this.hiddenTerms.length>0&&o.createElement(m.GI,{popup:l,placement:m.Iw.bottomStart,Wrapper:v.l},o.createElement(d.y,{shownTermsBefore:this.shownTerms.length>0,termNumber:t-this.shownTerms.length,colors:r?this.termsColors:[]})))}};y.defaultProps={maxWidth:400};(0,r.gn)([s.LO],y.prototype,"shownTerms",void 0);(0,r.gn)([s.LO],y.prototype,"hiddenTerms",void 0);(0,r.gn)([s.LO],y.prototype,"oldContainerWidth",void 0);(0,r.gn)([s.LO],y.prototype,"firstTermDidntFit",void 0);(0,r.gn)([s.LO],y.prototype,"overflowState",void 0);(0,r.gn)([s.aD],y.prototype,"splitTerms",void 0);(0,r.gn)([s.aD],y.prototype,"cutShownTerm",null);(0,r.gn)([s.Fl],y.prototype,"termsColors",null);(0,r.gn)([s.aD],y.prototype,"componentDidMount",null);(0,r.gn)([s.aD],y.prototype,"componentDidUpdate",null);y=(0,r.gn)([l.Pi],y);let f=class TermsOverflow extends o.Component{render(){return o.createElement(v.Sx,{isTableCell:this.props.isTableCell},o.createElement(y,Object.assign({},this.props,{termNodes:this.props.termNodes})))}};f=(0,r.gn)([l.Pi],f)},88217:(e,t,a)=>{"use strict";a.d(t,{Sx:()=>l,W2:()=>o,XD:()=>c,l:()=>u,GI:()=>p,RT:()=>h});var i=a(81012);var n=a(21471);var r=a(4141);var s=a(2227);const l=i.ZP.div`
  display: flex;
  width: 100%;
  padding-right: ${e=>e.isTableCell&&"50px"};
`;const o=i.ZP.div`
  display: flex;
  align-items: center;
  position: relative;
  width: 100%;
  ${e=>e.hidden&&`visibility: hidden`};
  ${e=>e.align==="right"&&`justify-content: flex-end`};
`;const c=i.ZP.div`
  flex: auto;
  display: inline-flex;
  flex-wrap: nowrap;
  justify-content: ${e=>e.align==="right"?"flex-end":"flex-start"};
  align-items: center;
  ${e=>e.firstTermForced&&`flex-grow: 1`};

  & > * {
    ${e=>e.theme.margin("XS",0)};
  }

  & > ${n.W2}:not(:last-child) {
    margin-right: ${n.ES}px;
  }

  ${e=>e.firstTermForced&&i.iv`
      & > ${n.W2}:first-child {
        flex-grow: 1;
        justify-content: flex-end;
        width: 0;
        max-width: fit-content;
        min-width: 50px;
        & > ${n.VY}:first-child {
          ${(0,s.LH)()}
        }
      }
    `}
`;const d=null&&styled(TermInstanceComponent)``;const u=i.ZP.div`
  display: inline-block;
`;const p=i.ZP.div`
  ${e=>e.theme.padding(0,"M")};
  border: ${e=>e.theme.border.separate};
  border-radius: 4px;
  overflow-y: auto;
  max-height: 160px;
`;const h=i.ZP.div`
  ${e=>e.theme.margin("S",0)}
`},74274:(e,t,a)=>{"use strict";a.d(t,{Nr:()=>r,uE:()=>s,BO:()=>l,$w:()=>o});const i="term";const n="termInstance";const r="manualTermInstance";const s="profilingTermInstance";const l="suggestedTermInstance";const o="metadataTermInstance"},9190:(e,t,a)=>{"use strict";a.d(t,{Pf:()=>n,Y5:()=>r,d0:()=>s,gK:()=>l,or:()=>o,r4:()=>c,OK:()=>d,HX:()=>u});var i=a(77711);const n="LATEST_PARTITION";const r=["BINARY","ARRAY","MAP","STRUCT","GENERIC"];const s=["INTEGER","FLOAT","LONG"];const l=["STRING"];const o=[i.pq.Full,i.pq.Sample,i.pq.Partition,i.pq.SamplePartition];var c;(function(e){e["DISCOVER"]="DISCOVER";e["PROFILE"]="PROFILE"})(c||(c={}));const d=i18n({id:"profileAnomalyDetectionEnabledView.description",defaults:"Anomaly detection will help you identify any potential corruptions in your data by\nflagging attributes with, e.g., unexpected length (string) or null count (numeric).\nThis detection will occur each time you profile your dataset."});const u=i18n({id:"profileSampleLimits.description",defaults:"Define how many records should be included in sample profiling. Rows will be selected randomly\nif database supports this functionality. Otherwise, the set number of rows will be selected from the top."})},78017:(e,t,a)=>{"use strict";a.d(t,{h:()=>r});var i=a(33032);var n=a.n(i);function r(e,t){return e.add({document:n(),variables:t})}},51979:e=>{var t={kind:"Document",definitions:[{kind:"OperationDefinition",operation:"query",name:{kind:"Name",value:"SearchStatus"},variableDefinitions:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"_searchStatus"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"status"},arguments:[],directives:[]}]}}]}}],loc:{start:0,end:56}};t.loc.source={body:"query SearchStatus {\n  _searchStatus {\n    status\n  }\n}\n",name:"GraphQL request",locationOffset:{line:1,column:1}};var a={};function i(e){return e.filter((function(e){if(e.kind!=="FragmentDefinition")return true;var t=e.name.value;if(a[t]){return false}else{a[t]=true;return true}}))}function n(e,t){if(e.kind==="FragmentSpread"){t.add(e.name.value)}else if(e.kind==="VariableDefinition"){var a=e.type;if(a.kind==="NamedType"){t.add(a.name.value)}}if(e.selectionSet){e.selectionSet.selections.forEach((function(e){n(e,t)}))}if(e.variableDefinitions){e.variableDefinitions.forEach((function(e){n(e,t)}))}if(e.definitions){e.definitions.forEach((function(e){n(e,t)}))}}var r={};(function e(){t.definitions.forEach((function(e){if(e.name){var t=new Set;n(e,t);r[e.name.value]=t}}))})();function s(e,t){for(var a=0;a<e.definitions.length;a++){var i=e.definitions[a];if(i.name&&i.name.value==t){return i}}}function l(e,t){var a={kind:e.kind,definitions:[s(e,t)]};if(e.hasOwnProperty("loc")){a.loc=e.loc}var i=r[t]||new Set;var n=new Set;var l=new Set;i.forEach((function(e){l.add(e)}));while(l.size>0){var o=l;l=new Set;o.forEach((function(e){if(!n.has(e)){n.add(e);var t=r[e]||new Set;t.forEach((function(e){l.add(e)}))}}))}n.forEach((function(t){var i=s(e,t);if(i){a.definitions.push(i)}}));return a}e.exports=t;e.exports.SearchStatus=l(t,"SearchStatus")},80673:e=>{var t={kind:"Document",definitions:[{kind:"OperationDefinition",operation:"query",name:{kind:"Name",value:"CatalogItemDataPreview"},variableDefinitions:[{kind:"VariableDefinition",variable:{kind:"Variable",name:{kind:"Name",value:"gid"}},type:{kind:"NonNullType",type:{kind:"NamedType",name:{kind:"Name",value:"GID"}}},directives:[]},{kind:"VariableDefinition",variable:{kind:"Variable",name:{kind:"Name",value:"credentialsSelector"}},type:{kind:"NamedType",name:{kind:"Name",value:"EntityVersionSelector"}},directives:[]},{kind:"VariableDefinition",variable:{kind:"Variable",name:{kind:"Name",value:"defaultCredential"}},type:{kind:"NamedType",name:{kind:"Name",value:"Boolean"}},directives:[]},{kind:"VariableDefinition",variable:{kind:"Variable",name:{kind:"Name",value:"newCredential"}},type:{kind:"NamedType",name:{kind:"Name",value:"AllCredentialInputObject"}},directives:[]},{kind:"VariableDefinition",variable:{kind:"Variable",name:{kind:"Name",value:"limit"}},type:{kind:"NamedType",name:{kind:"Name",value:"Int"}},directives:[]}],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"catalogItem"},arguments:[{kind:"Argument",name:{kind:"Name",value:"gid"},value:{kind:"Variable",name:{kind:"Name",value:"gid"}}}],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"preview"},arguments:[{kind:"Argument",name:{kind:"Name",value:"defaultCredential"},value:{kind:"Variable",name:{kind:"Name",value:"defaultCredential"}}},{kind:"Argument",name:{kind:"Name",value:"credentialsSelector"},value:{kind:"Variable",name:{kind:"Name",value:"credentialsSelector"}}},{kind:"Argument",name:{kind:"Name",value:"newCredential"},value:{kind:"Variable",name:{kind:"Name",value:"newCredential"}}},{kind:"Argument",name:{kind:"Name",value:"limit"},value:{kind:"Variable",name:{kind:"Name",value:"limit"}}}],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"headers"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"name"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"dataType"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"dataPolicy"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"item"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"InlineFragment",typeCondition:{kind:"NamedType",name:{kind:"Name",value:"DatabaseColumnBrowserItem"}},directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"primaryKey"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"foreignKey"},arguments:[],directives:[]}]}}]}}]}},{kind:"Field",name:{kind:"Name",value:"data"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"records"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"value"},arguments:[],directives:[]}]}}]}},{kind:"Field",name:{kind:"Name",value:"type"},arguments:[],directives:[]}]}}]}}]}}],loc:{start:0,end:665}};t.loc.source={body:"query CatalogItemDataPreview(\n  $gid: GID!\n  $credentialsSelector: EntityVersionSelector\n  $defaultCredential: Boolean\n  $newCredential: AllCredentialInputObject\n  $limit: Int\n) {\n  catalogItem(gid: $gid) {\n    preview(\n      defaultCredential: $defaultCredential\n      credentialsSelector: $credentialsSelector\n      newCredential: $newCredential\n      limit: $limit\n    ) {\n      headers {\n        name\n        dataType\n        dataPolicy\n        item {\n          ... on DatabaseColumnBrowserItem {\n            primaryKey\n            foreignKey\n          }\n        }\n      }\n      data {\n        records {\n          value\n        }\n      }\n      type\n    }\n  }\n}\n",name:"GraphQL request",locationOffset:{line:1,column:1}};var a={};function i(e){return e.filter((function(e){if(e.kind!=="FragmentDefinition")return true;var t=e.name.value;if(a[t]){return false}else{a[t]=true;return true}}))}function n(e,t){if(e.kind==="FragmentSpread"){t.add(e.name.value)}else if(e.kind==="VariableDefinition"){var a=e.type;if(a.kind==="NamedType"){t.add(a.name.value)}}if(e.selectionSet){e.selectionSet.selections.forEach((function(e){n(e,t)}))}if(e.variableDefinitions){e.variableDefinitions.forEach((function(e){n(e,t)}))}if(e.definitions){e.definitions.forEach((function(e){n(e,t)}))}}var r={};(function e(){t.definitions.forEach((function(e){if(e.name){var t=new Set;n(e,t);r[e.name.value]=t}}))})();function s(e,t){for(var a=0;a<e.definitions.length;a++){var i=e.definitions[a];if(i.name&&i.name.value==t){return i}}}function l(e,t){var a={kind:e.kind,definitions:[s(e,t)]};if(e.hasOwnProperty("loc")){a.loc=e.loc}var i=r[t]||new Set;var n=new Set;var l=new Set;i.forEach((function(e){l.add(e)}));while(l.size>0){var o=l;l=new Set;o.forEach((function(e){if(!n.has(e)){n.add(e);var t=r[e]||new Set;t.forEach((function(e){l.add(e)}))}}))}n.forEach((function(t){var i=s(e,t);if(i){a.definitions.push(i)}}));return a}e.exports=t;e.exports.CatalogItemDataPreview=l(t,"CatalogItemDataPreview")},33032:e=>{var t={kind:"Document",definitions:[{kind:"OperationDefinition",operation:"query",name:{kind:"Name",value:"PartitionsInfo"},variableDefinitions:[{kind:"VariableDefinition",variable:{kind:"Variable",name:{kind:"Name",value:"catalogItemId"}},type:{kind:"NonNullType",type:{kind:"NamedType",name:{kind:"Name",value:"GID"}}},directives:[]},{kind:"VariableDefinition",variable:{kind:"Variable",name:{kind:"Name",value:"newCredential"}},type:{kind:"NamedType",name:{kind:"Name",value:"AllCredentialInputObject"}},directives:[]},{kind:"VariableDefinition",variable:{kind:"Variable",name:{kind:"Name",value:"credentialsSelector"}},type:{kind:"NamedType",name:{kind:"Name",value:"EntityVersionSelector"}},directives:[]},{kind:"VariableDefinition",variable:{kind:"Variable",name:{kind:"Name",value:"defaultCredential"}},type:{kind:"NamedType",name:{kind:"Name",value:"Boolean"}},directives:[]}],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"catalogItem"},arguments:[{kind:"Argument",name:{kind:"Name",value:"gid"},value:{kind:"Variable",name:{kind:"Name",value:"catalogItemId"}}}],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"gid"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"partitionsInfo"},arguments:[{kind:"Argument",name:{kind:"Name",value:"defaultCredential"},value:{kind:"Variable",name:{kind:"Name",value:"defaultCredential"}}},{kind:"Argument",name:{kind:"Name",value:"credentialsSelector"},value:{kind:"Variable",name:{kind:"Name",value:"credentialsSelector"}}},{kind:"Argument",name:{kind:"Name",value:"newCredential"},value:{kind:"Variable",name:{kind:"Name",value:"newCredential"}}}],directives:[]}]}}]}}],loc:{start:0,end:377}};t.loc.source={body:"query PartitionsInfo (\n  $catalogItemId: GID!,\n  $newCredential: AllCredentialInputObject,\n  $credentialsSelector: EntityVersionSelector,\n  $defaultCredential: Boolean\n) {\n  catalogItem(gid: $catalogItemId) {\n    gid\n    partitionsInfo(\n      defaultCredential: $defaultCredential\n      credentialsSelector: $credentialsSelector\n      newCredential: $newCredential\n    )\n  }\n}\n",name:"GraphQL request",locationOffset:{line:1,column:1}};var a={};function i(e){return e.filter((function(e){if(e.kind!=="FragmentDefinition")return true;var t=e.name.value;if(a[t]){return false}else{a[t]=true;return true}}))}function n(e,t){if(e.kind==="FragmentSpread"){t.add(e.name.value)}else if(e.kind==="VariableDefinition"){var a=e.type;if(a.kind==="NamedType"){t.add(a.name.value)}}if(e.selectionSet){e.selectionSet.selections.forEach((function(e){n(e,t)}))}if(e.variableDefinitions){e.variableDefinitions.forEach((function(e){n(e,t)}))}if(e.definitions){e.definitions.forEach((function(e){n(e,t)}))}}var r={};(function e(){t.definitions.forEach((function(e){if(e.name){var t=new Set;n(e,t);r[e.name.value]=t}}))})();function s(e,t){for(var a=0;a<e.definitions.length;a++){var i=e.definitions[a];if(i.name&&i.name.value==t){return i}}}function l(e,t){var a={kind:e.kind,definitions:[s(e,t)]};if(e.hasOwnProperty("loc")){a.loc=e.loc}var i=r[t]||new Set;var n=new Set;var l=new Set;i.forEach((function(e){l.add(e)}));while(l.size>0){var o=l;l=new Set;o.forEach((function(e){if(!n.has(e)){n.add(e);var t=r[e]||new Set;t.forEach((function(e){l.add(e)}))}}))}n.forEach((function(t){var i=s(e,t);if(i){a.definitions.push(i)}}));return a}e.exports=t;e.exports.PartitionsInfo=l(t,"PartitionsInfo")}}]);
//# sourceMappingURL=widgets.1e88c428d1f825366997.js.map