select t.$tId$                        as "id_i",
       t.$tId$                        as "parent_id_i",
    $path('/terms/dqEvalTermAggr')$ as "path_i",
    $type()$      as "type_i",
    t.$tFrom$                        as from_h,
       COALESCE(validColor, 'green') as "validColor",
       COALESCE(invalidColor, 'red') as "invalidColor",
       COALESCE(attributeCount, 0)   as "attributeCount",
       COALESCE(ruleCount, 0)        as "ruleCount",
       COALESCE(catalogItemCount, 0) as "catalogItemCount",
       COALESCE(recordCount, 0)      as "recordCount",
       COALESCE(validCount, 0)       as "validCount",
       COALESCE(invalidCount, 0)     as "invalidCount",
       COALESCE(lastFrom, 0)         as "lastFrom"
from $t$ t
         left join (
    select termId                      as termId,
           sum(validCount)             as validCount,
           max(validColor)             as validColor,
           sum(invalidCount)           as invalidCount,
           max(invalidColor)           as invalidColor,
           count(distinct catalogItem) as catalogItemCount,
           sum(recordCount)            as recordCount,
           sum(attributeCount)         as attributeCount,
           sum(ruleCount)              as ruleCount,
           max(lastFrom)               as lastFrom
    from (
             select attribute.$aParentId$        as catalogItem,
                    max(valid.color_s)           as validColor,
                    sum(valid."resultCount_s")   as validCount,
                    max(invalid.color_s)         as invalidColor,
                    sum(invalid."resultCount_s") as invalidCount,
                    termAggr.term_ri             as termId,
                    sum(termAggr."ruleCount_s")  as ruleCount,
                    max(dq."recordCount_s")      as recordCount,
                    max(termAggr.$termAggrFrom$)         as lastFrom,
                    count(attribute)             as attributeCount
             from $a$ attribute
                      left join $dq$ dq on dq.$dqParentId$ = attribute.$aId$
                      left join $termAggr$ termAggr on termAggr.$termAggrParentId$ = dq.$dqId$
                      left join (select dqdar.$dqdarParentId$     as parent_id_i,
                                        dqdar."resultCount_s" as "resultCount_s",
                                        dqresult.color_s      as color_s
                                 from $dqdar$ dqdar
                                          left join $dqdr$ dqresult on dqresult.$dqdrId$ = dqdar.result_ri
                                 where (dqresult.name_s = 'Valid')) valid on (valid.parent_id_i = termAggr.$termAggrId$)
                      left join (select dqdar.$dqdarParentId$     as parent_id_i,
                                        dqdar."resultCount_s" as "resultCount_s",
                                        dqresult.color_s      as color_s
                                 from $dqdar$ dqdar
                                          left join $dqdr$ dqresult on dqresult.$dqdrId$ = dqdar.result_ri
                                 where (dqresult.name_s = 'Invalid')) invalid
                                on (invalid.parent_id_i = termAggr.$termAggrId$)
                     inner join $ti$ ti on ti.target_ri = termAggr.term_ri and ti.parent_id_i = attribute.id_i
             group by (termAggr.term_ri, attribute.$aParentId$)
         ) results
    group by (termId)) results on t.id_i = results.termId
