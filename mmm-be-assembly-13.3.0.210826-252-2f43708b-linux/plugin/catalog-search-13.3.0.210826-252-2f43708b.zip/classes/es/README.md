# Evolution of whole Elasticsearch configuration easily and reliable across all instances

Evolution executes versioned migration change sets reliable and persists the execution state in an internal Elasticsearch index.
Successful executed migration change sets will not be executed again.

Here is and example which indicates the ordering: 1.0.1 < 1.1 < 1.2.1 < (2.0.0 == 2).
In this example version 1.0.1 is the smallest version and is executed first, after that version 1.1, 1.2.1
and in the end 2. 2 is the same as 2.0 or 2.0.0 - so leading zeros will be trimed.

## Only last and full set versioning

* it is strictly versioned based upon version file = CHANGELOG.md descriptor
    * it is necessary to strictly adhere structure of descriptor, **it is automatically processed by application itself**
    * for each version it is possible to define what should be done after upgrade to the version (necessary action to complete migration)
    * for each type of action the application can execute appropriate action
        * currently allowed action: NOOP (change is fully compatible), REINDEX, MIGRATE
        * it is possible to define scopes of action -> meta information that will be taken into account
        * for example which types of entities should be re-indexed
    * *example*:

PARSED BY APPLICATION, see README.MD

Version | Necessary action to complete migration| Notes |
---     |:---:                                  |:---|
2.0.3   |NOOP                                   |Search template change
2.0.2   |REINDEX[catalogItem]                   |Reindexing
2.0.1   |REINDEX[catalogItem,term]              |Reindexing
2.0.0   |MIGRATE                                |Migration
1.0.0   |MIGRATE                                |Initialization

* current implementation is to hold only last and full set of all artifacts to be created in ES
    * only current state of all artifacts are hold (versioned)
        * e.g. if some artifact has removed it has to be removed manually
