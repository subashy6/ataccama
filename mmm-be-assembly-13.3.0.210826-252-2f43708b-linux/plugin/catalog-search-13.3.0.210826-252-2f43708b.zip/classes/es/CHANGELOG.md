# PARSED BY APPLICATION, see README.MD
Version | Necessary action to complete migration| Notes |
---     |:---:                                  |:---|
1.0.0   |MIGRATE                                |Initialization of global search.
1.0.1   |NOOP                                   |Change of search string tokenizer.
1.0.2   |MIGRATE                                |Switch templates to global search approach. MIGRATE because new fields are indexed.
1.0.3   |MIGRATE                                |Change of search string - short tokenizer. All data in this field must be reindexed.
1.0.4   |NOOP                                   |Add exact match to search template. No data operation needed.
