 select
    item.$itemId$ as "id_i",
    item.$itemPid$ as "parent_id_i",
    item.$itemFrom$ as "from_h",
    item."target_ri" as "catalogItem",
    (select count(dqCheck.$dqId$) from $dqCheck$ dqCheck 
        join "_MmdDictionary" mdPath on mdPath.id = dqCheck.$dqCheckPath$
        where mdPath."name" not like '%/hiddenDqChecks' and dqCheck.$dqPid$ = item.$itemId$) as "dqCheckCount",
    (select count(strAtt.$strAttId$) from $strAtt$ strAtt where strAtt.$strAttPid$ = strCheck.$strCheckId$) as "structureCheckCount",
    (select count(anomalyCheck.$anomalyCheckId$) from $anomalyCheck$ anomalyCheck where anomalyCheck.$anomalyCheckPid$ = item.$itemId$ and anomalyCheck."enabled_s" = true) as "anomalyCheckCount",
    (select count(attribute.$attId$) from $attribute$ attribute where attribute.$attPid$ = item."target_ri") as "attributeCount",
    $path('/monitoringProjects/configuration/projectStats')$ as "path_i",
    $type()$ as "type_i"
from $item$ item
    left join $strCheck$ strCheck on strCheck.$strCheckPid$ = item.$itemId$
    where item."change_type_d" != 'DELETE'
